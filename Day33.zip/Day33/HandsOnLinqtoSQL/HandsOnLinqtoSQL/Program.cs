﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnLinqtoSQL
{
    class Program
    {
        static void Main(string[] args)
        {
            //using(CTSDBDataClassesDataContext db=new CTSDBDataClassesDataContext())
            //{
            //    //fetch all employees
            //    List<Employee> list = (from l in db.Employees select l).ToList();
            //    foreach(var item in list)
            //    {
            //        Console.WriteLine("{0} {1} {2}", item.Ename, item.Desig, item.JoinDate);
            //    }
            //}
            ProductRep obj = new ProductRep();
           // obj.DeleteProduct(10);//deleting
            //Product p = new Product() { Pid = 4, Pname = "xyz", Price = 100, Stock = 10 };
            //obj.AddProduct(p);
            //Product p = obj.GetProductById(100);
            //if (p != null)
            //{
            //    Console.WriteLine(p.Pname);
            //}
            //else
            //    Console.WriteLine("Invalid Product");
            Product p = obj.GetProductById(1);
            p.Price = 200;
            obj.EditProduct(p.Pid, p);
            Console.ReadKey();
        }
    }
}
