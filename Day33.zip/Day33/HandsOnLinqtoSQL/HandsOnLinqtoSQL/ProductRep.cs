﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnLinqtoSQL
{
    class ProductRep
    {
        CTSDBDataClassesDataContext db = new CTSDBDataClassesDataContext();
        //fetch all produts
        public List<Product> GetProducts()
        {
            return db.Products.ToList();
        }
        //fetch product by Id
        public Product GetProductById(int pid)
        {
            Product p = db.Products.SingleOrDefault(i => i.Pid == pid);
            return p;
        }
        public void AddProduct(Product p)
        {
            db.Products.InsertOnSubmit(p); //record inserted
            db.SubmitChanges();
        }
        public void DeleteProduct(int pid)
        {
            Product p = db.Products.SingleOrDefault(i => i.Pid == pid);
            db.Products.DeleteOnSubmit(p);//record deleted
            db.SubmitChanges();
        }
        public void EditProduct(int pid,Product newObj)
        {
            Product p = db.Products.SingleOrDefault(i => i.Pid == pid);
            p.Price = newObj.Price;
            p.Stock = newObj.Stock;
            db.SubmitChanges();//asyncronusly proudct is updated.
        }
    }
}
