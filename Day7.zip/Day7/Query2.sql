select * from Department
insert into Department(DeptNo,Dname,Location) select
2,'IT','Information' union
select 3,'CF','CampusFource'
select * from Employee
insert into Employee(EmpNo,EmpName,Salary,DeptNo)
select 1,'Rajan',12000,1 union
select 2,'Karan',12000,2 union
select 3,'Suren',22000,3 union
select 4,'Suraj',22000,1 union
select 5,'Monica',32000,2 union
select 6,'Jeson',22000,3 union
select 7,'Rahul',32000,1 union
select 8,'Sachin',12000,2 union
select 9,'Komal',22000,3 union
select 10,'Varun',32000,1 