select * from Employee
select EmpName,Salary,RANK() over(order by salary desc) as Rank from Employee
select e.EmpName,d.Dname,e.Salary,
DENSE_RANK() over(partition by e.Deptno order by e.Salary desc) as Rank 
from Employee e join
Department d on
e.DeptNo=d.DeptNo
 