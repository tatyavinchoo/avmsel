select *,Row_number() over (Order by Pname) as RowNumber from product
select * from Customers
select CustomerId,ContactName,Country,ROW_NUMBER() over(Order by Country) as Row from Customers
select CustomerId,ContactName,Country,RANK() over(Order by Country) as Row from Customers
select CustomerId,ContactName,Country,Dense_RANK() over(Order by Country) as Row from Customers
select CustomerId,ContactName,Country,
ROW_NUMBER() over(Partition by Country Order by Country) as Row 
from Customers