CREATE TABLE [dbo].[Department] (
    [DeptNo]   INT          NOT NULL,
    [Dname]    VARCHAR (50) NOT NULL,
    [Location] VARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([DeptNo] ASC)
);
 
CREATE TABLE [dbo].[Employee] (
    [EmpNo]   INT          NOT NULL,
    [EmpName] VARCHAR (50) NOT NULL,
    [Salary]  INT          NOT NULL,
    [DeptNo]  INT          NOT NULL,
    PRIMARY KEY CLUSTERED ([EmpNo] ASC),
    FOREIGN KEY ([DeptNo]) REFERENCES [dbo].[Department] ([DeptNo])
);
 
CREATE TABLE [dbo].[EmployeeInfo] (
    [EmpNo]       INT          IDENTITY (1, 1) NOT NULL,
    [EmpName]     VARCHAR (50) NOT NULL,
    [Salary]      DECIMAL (18) NOT NULL,
    [DeptName]    VARCHAR (50) NOT NULL,
    [Designation] VARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([EmpNo] ASC)
);