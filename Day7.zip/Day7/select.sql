select * from employee
select * from employee
select eid,ename from employee
select did from employee
select distinct(did) from employee
select distinct * from employee
select * from employee where did=1
select * from employee where salary>20000
select * from employee where salary>10000 and salary<20000
select * from employee where eid=1000
select * from employee where salary>10000 or did=1
select * from employee where salary>10000 and did=1
select * from employee where desig!='TeamLeader'
select * from employee where desig<>'TeamLeader'
select * from employee where salary between 10000 and 15000
select * from employee where creationdate between '12.2.2010' and getdate()
select * from employee where eid in(102,106,105)
select * from employee where ename in('rohan','jeson','karan')
--pattern
select * from employee where ename like 'r%'
select * from employee where ename like '%n'
select * from employee where ename like '%a%'
select * from employee where ename like '_o%'