﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnEFUsingDBFirst
{
    class Program
    {
        static void Main(string[] args)
        {
            using(CTSDBEntities db=new CTSDBEntities())
            {
                //List<Employee> list = db.Employees.ToList();//return in List<EMployee> object
                //foreach(var item in list)
                //{
                //    Console.WriteLine("{0} {1} {2}", item.Ename, item.Desig, item.JoinDate);
                //}
                var list = from e in db.Employees
                           join
                           d in db.Depts
                           on e.Did equals d.Did
                           select new {e.Eid,e.Ename,e.Desig,d.Dname };
                foreach(var item in list)
                {
                    Console.WriteLine("{0} {1} {2} {3}", item.Eid, item.Desig, item.Ename, item.Dname);
                }
                Console.ReadKey();
            }
        }
    }
}
