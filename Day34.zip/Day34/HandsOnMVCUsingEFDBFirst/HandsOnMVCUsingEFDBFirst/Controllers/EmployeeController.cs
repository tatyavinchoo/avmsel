﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HandsOnMVCUsingEFDBFirst.Models;
namespace HandsOnMVCUsingEFDBFirst.Controllers
{
    public class EmployeeController : Controller
    {
        //
        // GET: /Employee/
        EmployeeDAO db = new EmployeeDAO();
        public ActionResult Index()
        {
            return View(db.GetAllEmployees());
        }
        public ActionResult Create()
        {
            List<Dept> list = db.GetDepts();
            
            ViewData["dept"] = new SelectList(list,"Did","Dname");
            return View();
        }
        [HttpPost]
        public ActionResult Create(Employee e)
        {
            if (ModelState.IsValid)
            {
                db.AddEmployee(e);
                return RedirectToAction("Index");
            }
            else
                return View();
        }
        public ActionResult Details(int id)
        {
            Employee e = db.GetEmpById(id);
            return View(e);
        }
        public ActionResult Delete(int id)
        {
            db.DeleteEmp(id);
            return RedirectToAction("Index");
        }
        public ActionResult Edit(int id)
        {
            Employee e = db.GetEmpById(id);
            return View(e);
        }
        [HttpPost]
        public ActionResult Edit(int Eid,Employee obj)
        {
            db.EditEmp(Eid, obj);
            return RedirectToAction("Index");
        }

    }
}
