﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HandsOnMVCUsingEFDBFirst.Models
{
    public class EmployeeDAO
    {
        CTSDBEntities db = new CTSDBEntities();
        public List<Employee> GetAllEmployees()
        {
            return db.Employees.ToList();
        }
        public List<Dept> GetDepts()
        {
            return db.Depts.ToList();
        }
        public Employee GetEmpById(int Eid)
        {
            return db.Employees.Find(Eid);
        }
        public void AddEmployee(Employee obj)
        {
            db.Employees.Add(obj);//insert employee
            db.SaveChanges(); //modify dbcontext
        }
        public void DeleteEmp(int Eid)
        {
            Employee e = db.Employees.Find(Eid);
            db.Employees.Remove(e);
            db.SaveChanges();
        }
        public void EditEmp(int Eid,Employee newObj)
        {
            Employee e = db.Employees.Find(Eid);
            //e = newObj; update all prop values
            e.Salary = newObj.Salary;
            db.SaveChanges();
        }
    }
}