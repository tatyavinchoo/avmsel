Use master
GO

IF  EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = 'DBFXCalculation')
DROP DATABASE DBFXCalculation
GO

CREATE DATABASE DBFXCalculation
GO

Use DBFXCalculation
GO
CREATE SCHEMA SBA
GO

CREATE TABLE SBA.Trade_Details (
TradeID varchar(5) Not Null, 
ISIN  varchar(7),
TradeDate   datetime,
MaturityDate      datetime,
SchemeName  varchar(100),
TradeType   varchar(50),
Currency    varchar(3),
Amount            numeric(18, 0)
)

CREATE TABLE SBA.FX_Rate (
TradeID           varchar(5) Not Null,
Currency    varchar(3),
Amount            numeric(18, 0),
AppliedFXRate     float,
CalculatedFXRate float

)

GO

select * from SBA.FX_Rate
select * from SBA.Trade_Details

delete from SBA.FX_Rate
delete from SBA.Trade_Details