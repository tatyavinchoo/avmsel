﻿using NUnit.Framework;
using FXCalculation;
using System;
using System.Collections.Generic;
using System.IO;
using System.Data.SqlClient;
using System.Data;

namespace NUnit.FXCalculationTestProject
{
    [TestFixture]
    public class Nunit_FXCalculatorTest
    {
        SqlConnection sqlConnectionString = ConnectionFactory.GetConnection();
        FXCalculator f = new FXCalculator();
        string errorLogFilePath = @"C:\Users\626437\Downloads\FXCalculation\ErrorLog\";      
        string sourcePathWithFileName = @"C:\Users\626437\Downloads\FXCalculation\Input file\TradeOrders_032013.txt"; // TODO: Initialize to an appropriate value
        string targetPathWithFileName = @"C:\Users\626437\Downloads\FXCalculation\Archive\TradeDetails_032013_Processed.txt"; // TODO: Initialize to an appropriate value            
        string backupPathWithFileName = @"C:\Users\626437\Downloads\FXCalculation\Backup\TradeOrders_032013.txt";
        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }
        //Implement your test case here.

        // <summary>
        //A test for SaveFXRate
        //</summary>
        [Test]
        public void SaveFXRateTest_FC()
        {
            //Implement your logic here
            List<FXRate> p = f.CalculateFXRate();
            DeleteSavedValuesFromFXRate();
            f.SaveFXRate(p);

            List<FXRate> l = GetSavedValuesFromFXRateTable();
            CompareFXRate c = new CompareFXRate();
            bool actual=c.compareMethod(p, l);
            Assert.AreEqual(true, actual);
        }     


        // <summary>
        //A test for SaveInvalidRecordsToLogFile
        //</summary>
        [Test]
        public void SaveInvalidRecordsToLogFileTest_FC()
        {
            //Implement your logic here
            List<Trade> l = f.ReadAllDataFromInputFile(@"C:\Users\626437\Downloads\FXCalculation\Input file\", "TradeOrders_032013.txt");
            List<Trade> valid = f.PickValidTradeDetails(l, @"C: \Users\626437\Downloads\FXCalculation\ErrorLog\", "InvalidRecords_032013.txt");
            List<Trade> invalid = new List<Trade>();
            foreach(var item in l)
            {
                if(l.Contains(item)!=valid.Contains(item))
                {
                    invalid.Add(item);
                }
            }
            bool actual = f.SaveInvalidRecordsToLogFile(invalid, errorLogFilePath, "InvalidRecords_032013.txt");
            if(File.Exists(errorLogFilePath+ "InvalidRecords_032013.txt"))
            {
                actual = true;
            }
            Assert.AreEqual(true, actual);
        }

        //<summary>
        //A test for CopyToArchive
        //</summary>
        [Test]
        public void CopyToArchiveTest_FC()
        {
            //Implement your logic here
            string c = @"\";
            int i = backupPathWithFileName.LastIndexOf(c);
            string dir = backupPathWithFileName.Substring(0, i);
            if(!Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
            }
            f.CopyToArchive(sourcePathWithFileName, targetPathWithFileName);
            f.CopyToArchive(sourcePathWithFileName, backupPathWithFileName);
            int res = 0;
            string[] a = File.ReadAllLines(targetPathWithFileName);
            string[] b = File.ReadAllLines(backupPathWithFileName);
            if (a.Length == b.Length)
            {
                for (int j = 0; j < a.Length; j++)
                {
                    if (a[j] != b[j])
                    {
                        res++;
                    }
                }
            }
            else
                res++;
                Assert.AreEqual(res, 0);
            }
        

        //Helper methods
        //Use Helper methods if applicable
        public List<FXRate> GetSavedValuesFromFXRateTable()
        {
            List<FXRate> fxrates = new List<FXRate>();
            DataTable datatable = new DataTable();

            SqlCommand command = new SqlCommand("Select TradeId,Currency,Amount,AppliedFXRate,CalculatedFXRate from SBA.FX_Rate", sqlConnectionString);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            sqlConnectionString.Open();
            adapter.Fill(datatable);
            sqlConnectionString.Close();

            foreach (DataRow dr in datatable.Rows)
            {
                fxrates.Add(new FXRate()
                {
                    TradeId = Convert.ToString(dr[0]),
                    Currency = Convert.ToString(dr[1]),
                    Amount = Convert.ToString(dr[2]),
                    AppliedFXRate = Convert.ToString(dr[3]),
                    CalculatedFXRate = Convert.ToString(dr[4])
                });
            }
            return fxrates;
        }

        //DeleteSavedValuesFromDB
        public bool DeleteSavedValuesFromDB(List<Trade> trades)
        {

            //Do your logic here to upload to DB table
            foreach (var trade in trades)
            {
                SqlCommand command = new SqlCommand("Delete from SBA.Trade_Details", sqlConnectionString);
                sqlConnectionString.Open();
                command.ExecuteNonQuery();
                sqlConnectionString.Close();
            }
            return true;
        }

        public void DeleteSavedValuesFromFXRate()
        {

            //Do your logic here to upload to DB table            
            SqlCommand command = new SqlCommand("Delete from SBA.FX_Rate", sqlConnectionString);
            sqlConnectionString.Open();
            command.ExecuteNonQuery();
            sqlConnectionString.Close();
        }

        public void DeleteSavedValuesFromTradeDetails()
        {

            //Do your logic here to upload to DB table            
            SqlCommand command = new SqlCommand("Delete from SBA.Trade_Details", sqlConnectionString);
            sqlConnectionString.Open();
            command.ExecuteNonQuery();
            sqlConnectionString.Close();

        }

    }
}
