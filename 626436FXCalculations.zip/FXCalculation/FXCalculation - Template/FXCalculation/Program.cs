﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace FXCalculation
{
    public class Program
    {
        
        static void Main(string[] args)
        {            
         
            FXCalculator fxcalculatorobj = new FXCalculator();
            fxcalculatorobj.ProcessData(@"C:\Users\626437\Downloads\FXCalculation\Input file\", "TradeOrders_032013.txt",
                @"C:\Users\626437\Downloads\FXCalculation\ErrorLog\", "InvalidRecords_032013.txt", @"C:\Users\626437\Downloads\FXCalculation\Archive\", "TradeDetails_032013_Processed.txt");

           /*
           * Pass the file path, file names and connection string in this method alone. 
           * Do not hardcode in any other methods
           */ 
        }
    }
}
