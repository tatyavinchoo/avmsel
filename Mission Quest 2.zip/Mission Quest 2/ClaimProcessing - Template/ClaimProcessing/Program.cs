﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace ClaimProcessing
{
    public class Program
    {
        static void Main(string[] args)
        {
            SqlConnection connection = new SqlConnection(@"Data Source=PCNAME\SQLEXPRESS;Initial Catalog=DBClaimProcessing;Integrated Security=True");
            ClaimProcessor cpobject = new ClaimProcessor();
            cpobject.ProcessData(@"D:\Dotnetcaassessment\ClaimProcessing\Input File\",
                                @"D:\Dotnetcaassessment\ClaimProcessing\Report\",
                                "ReportOfRejectedClaims.txt", connection, @"D:\Dotnetcaassessment\ClaimProcessing\Archive\");

        }
    }
}
