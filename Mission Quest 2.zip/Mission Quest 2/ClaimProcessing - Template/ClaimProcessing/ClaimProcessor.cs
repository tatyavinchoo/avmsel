﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Data.Linq;

namespace ClaimProcessing
{
    public class ClaimProcessor
    {
        public void ProcessData(string inputFilePath,string reportFilePath, string reportFileName, SqlConnection connection,string archivePath)
        {
            //Do your logic here
            
            //ReadAllDataFromInputFiles

            //UpdateStatusFlag

            //SaveClaimsToDatabase
          
            //GetRejectedClaimsFromDatabase

            //SaveReportAsTextFile

            //MoveToArchive
        }
        /*
         * Do not modify the method signatures
         * */
        public List<Claim> ReadAllDataFromInputFiles(string inputFilePath)
        {
            //Return list with all the data from the input files
            return null;
        }
        public List<Claim> UpdateStatusFlag(List<Claim> claims)
        {
            //return list with updated status flag
            return null;
        }
        
        public void SaveClaimsToDatabase(List<Claim> claims, SqlConnection sqlConnectionString)
        {
            //Save the claim details to database with the updated status flag
        }
        public List<Claim> GetRejectedClaimsFromDatabase(SqlConnection connectionString)
        {
            //Get the rejected claim details from the DB using Linq Concept
            return null;
        }
        public void SaveReportAsTextFile(List<Claim> claims, string reportFilePath, string reportFileName)
        {
           //Save the rejected claims as text file.
        }    
        public void MoveToArchive(string inputFilePath, string archiveFilePath)
        {
           //Create a copy of the input files to archive folder
        }
    }
}
