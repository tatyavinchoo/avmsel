Use master
GO

IF  EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = 'DBClaimProcessing')
DROP DATABASE DBClaimProcessing
GO

CREATE DATABASE DBClaimProcessing
GO

Use DBClaimProcessing
Go
CREATE SCHEMA SBA
GO


CREATE TABLE [SBA].[Claim_Requests](
ClaimId	Varchar(5) Not null,
ClaimDate	DateTime,
InsuredDate	DateTime,
InsuredAmountPerYear	float,
EmailId	Varchar(100),
ClaimAmount	float,
DateOfAdmission	DateTime,
DateOfDischarge	DateTime,
BoardingCharges	float,
SurgeonFees	float,
Othercharges	     float,
ClaimStatus	     Varchar(10)

)
GO