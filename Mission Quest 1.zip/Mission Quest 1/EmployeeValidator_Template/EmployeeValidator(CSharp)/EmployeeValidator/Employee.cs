﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeValidation
{
    public class Employee
    {
        /*
        * Do not modify the return types of the below properties
        * 
        */

        public string EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string EmailId { get; set; }
        public string DateOfJoining { get; set; }
    }

    // Do not add new constructors
}
