﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Collections;

namespace EmployeeValidation
{
    public class EmployeeValidator
    {
        /*
        * Do not remove the attached TestProject. It is meant for auto evaluation of your source code.
        * Do not attach any test classess to the attached test project.
        * Do not attach any new test projects.
        * You are not required to write any automated test cases. You are supposed to write only the code.
        */
        #region "ProcessData"
        //process the xml data
        //Parameters are  xmlFilePath, xmlFileName, connection
        public void ProcessData(string xmlFilePath, string xmlFileName, SqlConnection connection)
        {
            //Do your logic here
            //Step 1           
            //ReadAllEmployeesFromXmlFile
            //Step 2           
            //PickValidEmployees
            //Step 3
            //SaveValidEmployeesToDataBase           

        }
        #endregion

        #region "ReadAllEmployeesFromXmlFile"
        //Read all the employees in XML File
        //xmlFilePath and xmlFileName are passed as parameter
        public List<Employee> ReadAllEmployeesFromXmlFile(string xmlFilePath, string xmlFileName)
        {
            //Read the employee details from the xml file and return it in List collection
            //Do not hardcode the filename and the file path here
            
            //Do not return the date with time appended to it.

            return null;
        }
        #endregion
       
        #region "PickValidEmployees" 
        // Pick the vaild employees from given employee List
        //Employee List passed as Parameter 
        public List<Employee> PickValidEmployees(List<Employee> employees)
        {
            //Pick the valid employees from the List collection
            //Return the valid employees in a List
            
            return null;//Return only valid employees in List
        }
        #endregion
        
        #region "SaveValidEmployeesToDB"
        // Save the valid employee in database
        //parameter List of employees and connection object
        public void SaveValidEmployeesToDB(List<Employee> employees, SqlConnection connection)
        {
            //Do not Prefix Database name in the SQL Query. Query should be "Insert into SBA.TableName"
            //Should not be "Insert into DatabaseName.SBA.TableName"
            //Do not hardcode the connection string here
        }
        #endregion

        #region "SortEmployeebyEmployeeName"
        // Sort the EmployeeName from Employee List
        public void SortEmployeebyEmployeeName()
        {
            Employee e1 = new Employee { EmployeeId = "101", EmployeeName = "John", EmailId = "John@hotmail.com", DateOfJoining = "8/2/2011" };
            Employee e2 = new Employee { EmployeeId = "102", EmployeeName = "Preethi", EmailId = "Preethi@gmail.com", DateOfJoining = "10/6/2008" };
            Employee e3 = new Employee { EmployeeId = "103", EmployeeName = "Jenifer", EmailId = "Jenifer@yahoo.com", DateOfJoining = "6/10/2004" };

            // Add the employee details in the employee List 
            //sort the employee details by EmployeeName
        }
        #endregion

    }
}
