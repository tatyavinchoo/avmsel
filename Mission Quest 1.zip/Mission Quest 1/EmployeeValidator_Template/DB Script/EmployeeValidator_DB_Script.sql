Use master
GO

IF  EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = 'DBEmployeeValidation')
DROP DATABASE DBEmployeeValidation
GO

CREATE DATABASE DBEmployeeValidation
GO

Use DBEmployeeValidation
GO
CREATE SCHEMA SBA
GO

CREATE TABLE SBA.Employees (
EmployeeId	Numeric(18,0) Not null Primary Key,
EmployeeName	Varchar(50),
EmailId	Varchar(100),
DateOfJoining	DateTime
)
GO
