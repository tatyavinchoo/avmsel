﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnMethodParameterModifiers
{
    class Demo2
    {
        public static int Sum(params int[] a)
        {
            int r = 0;
            foreach (int k in a)
            {
                r = r + k;
            }
            return r;
          
        }
        public static void M(int i, params int[] a)
        {

        }
        static void Main()
        {
            int k = Sum(new int[]{12,23,3,4});
            Console.WriteLine(k);
            Console.WriteLine(Sum(12, 23, 34));
            Console.WriteLine(Sum(34, 45));
            string s = "Hello World";
            string[] s1 = s.Split(',', ' ');
            M(10, 12, 3, 4, 56);
            Console.WriteLine()
        }
    }
}
