﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnMethodParameterModifiers
{
    class Demo
    {
        public void Sum(int a, int b, out int c)
        {
            c = a + b;
        }
        static void Main()
        {
            Demo obj = new Demo();
            int a = 10, b = 30, c=0;
            obj.Sum(a, b, out c);
            Console.WriteLine(c);
        }
    }
}
