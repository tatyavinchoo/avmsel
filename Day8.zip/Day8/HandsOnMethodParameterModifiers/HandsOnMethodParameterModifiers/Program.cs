﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnMethodParameterModifiers
{
    class Program
    {
        public  void M(int i)
        {
            i = i * i;
        }
        public void M1(ref int i)
        {
            i = i * i;
        }
        static void Main(string[] args)
        {
            int i=10;//local variable
            Program obj = new Program();
            obj.M(i);
            Console.WriteLine(i);
            obj.M1(ref i);//passing reference of i
            Console.WriteLine(i);
        }
    }
}
