﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnStructures
{
    struct Emp
    {
        public int Eid;
        public string Ename;
        public static double Bonous = 9000;
        public Emp(int id, string name)
        {
            Eid = id;
            Ename = name;
        }
        //public Emp()
        //{
        //}
        public void Details()
        {
            Console.WriteLine("Eid " + Eid);
            Console.WriteLine("Ename " + Ename);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //Instantiate object
            Emp e1 = new Emp(100,"David");
            e1.Details();
            Emp e2;
            e2.Eid = 101;
            e2.Ename = "Suren";
            e2.Details();
        }
    }
}
