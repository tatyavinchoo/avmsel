﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnProperties
{
    class Program
    {
        static void Main(string[] args)
        {
            Student s = new Student();
            s.Sid = 100;
            s.Sname = "Rohan";
            s.Age = 21;
            s.details();
           
        }
    }
}
