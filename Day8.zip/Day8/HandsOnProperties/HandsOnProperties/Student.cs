﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnProperties
{
    class Student
    {
        private int sid;
        private string sname;
        private int age;
        public int Sid
        {
            get { return sid; }
            set { sid = value; }
        }
        public string Sname
        {
            get { return sname; }
            set { sname = value; }
        }
        public int Age
        {
            get { return age; }
            set
            {
                if (value >= 10 && value <= 15)
                {
                    age = value;
                }
                else
                    Console.WriteLine("Error:Age between 10 to 15");
            }
        }

        public void details()
        {
            Console.WriteLine("Sid={0}\nSname={1}\nAge={2}", sid, sname,age);
        }
    }
}
