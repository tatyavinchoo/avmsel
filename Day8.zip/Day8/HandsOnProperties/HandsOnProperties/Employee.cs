﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnProperties
{
    class Employee
    {
        private int Eid;
        private string Ename;
        private string Designation;
        private static double sal;
        public Employee(int id, string name)
        {
            Eid = id;
            Ename = name;
           
        }
        public int EID //read-only property
        {
            get { return Eid; }
        }
        public string Desig //write-only property
        {
            set
            {
                Designation = value;
            }
        }
        public static double Salary
        {
            get { return sal; }
            set
            {
                sal = value;
            }
        }
    }
    class Test_Employee
    {
        static void Main()
        {
            Employee obj = new Employee(1,"Rohan");
            obj.Desig = "Programme";
            Employee.Salary = 12000;
            Console.WriteLine("ID: "+obj.EID);

        }
    }
}
