﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnConstructors
{
    class Circle
    {
        double r;
        static double Pi;
        public Circle(double r)
        {
            this.r = r;
        }
        //static constructor
        static Circle()
        {
            Pi = 3.14;
            Console.WriteLine("I am a Static Constructor");
        }
        public void Area()
        {
        
            Console.WriteLine("Area of Circle " + Pi * r * r);
        }
    }
    class Test_Circle
    {
        static void Main()
        {
            Circle []c=new Circle[3];
            c[0] = new Circle(12.3);
            c[1] = new Circle(23.4);
            Circle obj = new Circle(90);
            c[2] = obj;
            foreach (Circle ob in c)
            {
                ob.Area();
            }
        }
    }
}
