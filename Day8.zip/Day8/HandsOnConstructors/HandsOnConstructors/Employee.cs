﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnConstructors
{
    class Employee
    {
        public int Eid;
        public string Ename;
        public string Desig;
        public Employee()//default constructor
        {
            Eid = 100;
            Ename = "Rohan";
            Desig = "Programmer";
        }
        public Employee(int id, string name, string desig)//parametarized constructor
        {
            Eid = id;
            Ename = name;
            Desig = desig;
        }
        public void Details()
        {
            Console.WriteLine("Eid={0}\nEname={1}\nDesignation={2}\n", 
                Eid, Ename, Desig);
        }
    }
    class Test_Employee
    {
        static void Main()
        {
            Employee obj = new Employee();
            obj.Details();
            Employee e1 = new Employee();
            e1.Details();
            Employee e2 = new Employee(101, "karan", "Programmer");
            Employee e3 = new Employee(102, "suren", "TeamLeader");
            e2.Details();
            e3.Details();
        }
    }
}
