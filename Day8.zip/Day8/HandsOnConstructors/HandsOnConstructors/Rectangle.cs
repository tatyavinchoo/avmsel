﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnConstructors
{
    class Rectangle
    {
        int l, w;
        public Rectangle(int l, int w)
        {
            this.l = l;
            this.w = w;
        }
        public Rectangle(Rectangle obj) //copy constructor
        {
            this.l = obj.l;
            this.w = obj.w;
        }
        public void Area()
        {
            Console.WriteLine("Area of Rectangle " + (l * w));
        }
    }
    class Test_Rectangle
    {
        static void Main()
        {
            Rectangle r = new Rectangle(11,23);
            Rectangle r1 = new Rectangle(10, 10);
            Rectangle r2 = new Rectangle(r);
            r.Area();
            r1.Area();
            r2.Area();

        }
    }
}
