﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnInhertitance
{
    class Demo
    {
        public int i;
        private int j;
        internal int k;
        protected int l;
        protected internal int m;
    }
    class Demo1 : Demo
    {
        public void f()
        {
            i = 10;
            k = 12;
            l = 23;
            m = 45;
        }
    }
    class Demo2
    {
        static void Main()
        {
            Demo1 obj = new Demo1();
            obj.i = 10;
            obj.k = 23;
            obj.m = 24;
        }
    }
}
