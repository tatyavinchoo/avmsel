﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnInhertitance
{
    class Product
    {
        public virtual void Print()
        {
        }
    }
    class Order:Product
    {
        public sealed override void Print()
        {
            base.Print();
        }
    }
    class Supplier:Order
    {
        public override void Print()
        {
            base.Print();
        }
    }
}
