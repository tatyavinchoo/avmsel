﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnInhertitance
{
    class Employee
    {
        public int Eid;
        public string Ename;
        public string Desig;
        public double Salary;
        public void Show()
        {
            Console.WriteLine("Eid " + Eid);
            Console.WriteLine("Ename " + Ename);
            Console.WriteLine("Designation " + Desig);
            Console.WriteLine("Salary " + Salary);
        }
    }
    class Manager:Employee
    {
        public string Level;
       new  public void Show()
        {
            base.Show(); 
           Console.WriteLine("Level " +Level);
          
        }
        public void AssingProject()
        {
            
        }
        public void MapEmployee()
        {

        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Manager m = new Manager();
            m.Eid = 100;
            m.Ename = "Rohan";
            m.Desig = "Project Manager";
            m.Salary = 45000;
            m.Level = "Level1";
            m.Show();
           // Console.WriteLine("Level " + m.Level);
            m.MapEmployee();
            m.AssingProject();
            Employee e1 = new Employee();
            Employee e2 = new Manager();
            
            Object o1 = new Employee();
        }
    }
}
