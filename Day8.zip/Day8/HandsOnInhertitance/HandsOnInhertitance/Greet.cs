﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnInhertitance
{
    class Greet
    {
        string name;
        public Greet(string name)
        {
            this.name = name;
        }
        public override string ToString()
        {
            return "Hello " + name;
        }
    }
    class Test_Greet
    {
        static void Main()
        {
            Greet obj = new Greet("Sachin");
           Console.WriteLine(obj.ToString());
        }
    }
}
