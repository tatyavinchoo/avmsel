﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnInhertitance1
{
    class Employee
    {
        public int Eid;
        public string Ename;
        public string Desig;
        public double Salary;
        public virtual void Show()
        {
            Console.WriteLine("Eid " + Eid);
            Console.WriteLine("Ename " + Ename);
            Console.WriteLine("Designation " + Desig);
            Console.WriteLine("Salary " + Salary);
        }
    }
    class Manager : Employee
    {
        public string Level;
        public Manager(int id, string name, string desig, double salary, string level)
        {
            Eid = id;
            Ename = name;
            Desig = desig;
            Salary = salary;
            Level = level;
        }
        public override void Show()
        {
            base.Show();
            Console.WriteLine("Level " + Level);
        }
        static void Main()
        {
            Manager m = new Manager(100, "Suren", "TeamLeader", 56000, "Level2");
            m.Show();
            Employee e = new Manager(101, "Karan", "TeamLeader", 56000, "Level1");
            e.Show();//invoke manager show()
        }
    }
}
