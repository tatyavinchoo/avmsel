﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnInhertitance
{
    class Student
    {
        protected int sid;
        protected string sname;
        public Student(int id, string name)
        {
            sid = id;
            sname = name;
        }
        public Student()
        {
            Console.WriteLine("Student Created");
        }
    }
    class Enroll:Student
    {
        private string cname;
        public Enroll()
        {
            Console.WriteLine("Student is Enrolled");
        }
        public Enroll(int id, string name, string cname):base(id,name)
        {
            this.cname = cname;
        }
        public void details()
        {
            Console.WriteLine("Sid " + sid);
            Console.WriteLine("Sname " + sname);
            Console.WriteLine("Course Name " + cname);
        }

    }
    class StudentEnroll
    {
        static void Main()
        {
            //Enroll obj = new Enroll();
            Enroll e1 = new Enroll(100, "Rohan", "C#.net");
           
            e1.details();
            Console.ReadKey();
        }
    }
}
