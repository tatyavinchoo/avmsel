﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HandsOnMVCUsingModels.Models;
namespace HandsOnMVCUsingModels.Controllers
{
    public class InventoryController : Controller
    {
        //
        // GET: /Inventory/

        public ActionResult Index()//display prouduct list
        {
            ProductRep repObj = new ProductRep();
            List<Product> list = repObj.GetList();
            return View(list);
        }
        public ActionResult Login()
        {
            return View();
        }
        public ActionResult Validate(Login login)
        {
            LoginRep repObj = new LoginRep();
            Login obj=repObj.Validate(login.Uname, login.Pwd);
            if(obj==null)
            {
                TempData["err"] = "Invalid User";
            }
            else if(obj.Role=="Manager")
            {
                TempData["user"] = obj.Uname;
                return RedirectToAction("Create");
            }
            else if(obj.Role=="Admin")
            {
                TempData["user"] = obj.Uname;
                return RedirectToAction("Index");
            }
            return RedirectToAction("Login");
        }
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(Product p)
        {
            ProductRep repObj = new ProductRep();
            repObj.AddProduct(p);
            return View();//Redirect to Create Template
        }

    }
}
