﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HandsOnMVCUsingModels.Models
{
    public class ProductRep
    {
        static List<Product> list = new List<Product>();
        public List<Product> GetList()
        {
            return list;
        }
        public void AddProduct(Product p)
        {
            list.Add(p);
        }
    }

}
