﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HandsOnMVCUsingModels.Models
{
    public class LoginRep
    {
        static List<Login> login = new List<Login>()
        {
            new Login(){Uname="Rohan",Pwd="12345",Role="Admin"},
            new Login(){Uname="Karan",Pwd="12345",Role="Manager"},
            new Login(){Uname="Jeson",Pwd="12345",Role="Manager"},
            new Login(){Uname="Suren",Pwd="12345",Role="Admin"},
        };
        public Login Validate(string uname,string pwd)
        {
            Login l = login.SingleOrDefault(i => i.Uname == uname && i.Pwd == pwd);
            return l;
        }
    }
}