﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HandsOnViews.Controllers
{
    public class DemoController : Controller
    {
        //
        // GET: /Demo/

        //public string Index()
        //{
        //    return "Hello World";
        //}
        public ActionResult Index()
        {
            return View("View1"); //pass viewname to viewmethod
        }
        public ActionResult Details()
        {
            return View();
        }
        public ActionResult Greet(string name)
        {
            //set value in ViewData
            ViewData["un"] = name;
            return View();
        }
        public ActionResult GetFullname(string fname,string lname,int ite)
        {
            //set value
            ViewData["fn"] = fname;
            ViewData["ln"] = lname;
            ViewData["ite"] = ite;
            return View();
        }
        public ActionResult Square(int i)
        {
            ViewBag.Sqaure = i * i;
            return View();
        }
        public ActionResult GetFlowers()
        {
            List<string> list = new List<string>()
            {
                "Rose",
                "Lilly",
                "Marigold",
                "Jasmine",
                "Tulips",
                "Dafodil"
            };
           // ViewBag.List = list;
            ViewData["List"] = list;
            return View();
        }
        public ActionResult View2()
        {
            return View();
        }

    }
}
