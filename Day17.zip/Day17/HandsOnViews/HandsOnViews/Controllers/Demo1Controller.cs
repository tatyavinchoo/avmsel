﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HandsOnViews.Controllers
{
    public class Demo1Controller : Controller
    {
        //
        // GET: /Demo1/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult View1(string name)
        {
            TempData["msg"] = "GoodMorning User";
            TempData["un"] = name;
           // return RedirectToAction("View2");//Redirect to View2
            return RedirectToAction("View2", "Demo");
        }
        public ActionResult View2()
        {
            return View();
        }
    }
}
