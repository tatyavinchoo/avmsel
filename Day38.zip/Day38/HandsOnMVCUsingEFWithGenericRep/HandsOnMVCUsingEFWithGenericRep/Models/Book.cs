﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace HandsOnMVCUsingEFWithGenericRep.Models
{
    [Table("tblBooks")]
    public class Book
    {
        [Key]
        public int Bid { get; set; }
        public string Bname { get; set; }
        public int Price { get; set; }
    }
}