﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HandsOnMVCUsingEFWithGenericRep.Models;
using HandsOnMVCUsingEFWithGenericRep.Repositoty;
namespace HandsOnMVCUsingEFWithGenericRep.Controllers
{
    public class ProductController : Controller
    {
        //
        // GET: /Product/
        private GenericRepositoty<Product> dbproduct = null;
        public ProductController()
        {
            dbproduct = new GenericRepositoty<Product>();
        }
        public ActionResult Index()
        {
            return View(dbproduct.GetAll());
        }
        public ActionResult Details(int id)
        {
            return View(dbproduct.GetById(id));
        }
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(Product p)
        {
            if (ModelState.IsValid)
            {
                dbproduct.Add(p);
                dbproduct.Save();
                return RedirectToAction("Index");
            }
            else
                return View();
        }
        public ActionResult Delete(int Id)
        {
            dbproduct.Delete(Id);
            dbproduct.Save();
            return RedirectToAction("Index");
        }
        public ActionResult Edit(int Id)
        {
            return View(dbproduct.GetById(Id));
        }
        [HttpPost]
        public ActionResult Edit(Product p)
        {
            dbproduct.Update(p);
            dbproduct.Save();
            return RedirectToAction("Index");
        }
    }
}
