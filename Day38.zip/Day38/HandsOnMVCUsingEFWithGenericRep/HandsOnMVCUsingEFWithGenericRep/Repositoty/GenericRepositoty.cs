﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.Data;
namespace HandsOnMVCUsingEFWithGenericRep.Repositoty
{
    public class GenericRepositoty<T>:IGenericRepositoty<T> where T:class
    {

        private GenericRepContext db = null;
        private DbSet<T> table = null;
        public GenericRepositoty()
        {
            db = new GenericRepContext();
            table = db.Set<T>();
        }
        public GenericRepositoty(GenericRepContext db)
        {
            this.db = db;
            table = db.Set<T>();
        }
        public List<T> GetAll()
        {
            if (table != null)
                return table.ToList();
            else
                return null;
        }

        public T GetById(object id)
        {
            return table.Find(id);
        }

        public void Add(T obj)
        {
             table.Add(obj);
        }

        public void Delete(object id)
        {
            T obj = table.Find(id);
            table.Remove(obj);
        }

        public void Update(T obj)
        {
            table.Attach(obj);
            db.Entry<T>(obj).State = EntityState.Modified;
        }
        public void Save()
        {
            db.SaveChanges();
        }
    }
}