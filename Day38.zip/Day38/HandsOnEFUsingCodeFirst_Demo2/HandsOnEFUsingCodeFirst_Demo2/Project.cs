﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace HandsOnEFUsingCodeFirst_Demo2
{
    [Table("tblProject")]
    class Project
    {
        [Key()]
        [DatabaseGenerated(DatabaseGeneratedOption.None)] //disable identity
        public int Pid { get; set; }
        public string Pname { get; set; }
    }
}
