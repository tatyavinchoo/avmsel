﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnEFUsingCodeFirst_Demo2
{
    class Program
    {
        static void Main(string[] args)
        {
            MyContext db = new MyContext();
            ////Dept d = new Dept() { DId = 3, Dname = "IT" };
            ////db.Set<Dept>().Add(d);
            ////db.SaveChanges();
            //Employee e = new Employee() { Eid = 100, Ename = "Rohan", Desig = "Programmer", Salary = 10000, Email="rohan@gmail.com", Joindate = DateTime.Now, Did = 3 };
            //db.Set<Employee>().Add(e);
            //db.SaveChanges();
            Project p = new Project() { Pid = 1239, Pname = "HealthCare" };
            db.Set<Project>().Add(p);
            db.SaveChanges();
        }
    }
}
