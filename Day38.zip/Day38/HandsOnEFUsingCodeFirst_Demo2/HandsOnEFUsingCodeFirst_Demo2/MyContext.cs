﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
namespace HandsOnEFUsingCodeFirst_Demo2
{
    class MyContext:DbContext
    {
        public MyContext()
            : base("name=EmpManagementConn")
        {

        }
        //Entity Set
        //public DbSet<Dept> Depts { get; set; }
        //public DbSet<Employee> Employees { get; set; }
        public DbSet<Project> Projects { get; set; }
    }
}
