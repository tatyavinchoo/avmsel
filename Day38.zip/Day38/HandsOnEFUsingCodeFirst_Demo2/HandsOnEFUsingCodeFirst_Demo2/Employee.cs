﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace HandsOnEFUsingCodeFirst_Demo2
{
    [Table("tblEmployee")]
    class Employee
    {
        [Key()]
        [DatabaseGenerated(DatabaseGeneratedOption.None)] //disable identity
        [Required]
        public int Eid { get; set; }
        [StringLength(30)]
        public string Ename { get; set; }
        [StringLength(30)]
        public string Desig { get; set; }
        [StringLength(30)]
        public string Email { get; set; }
        public int Salary { get; set; }
        public DateTime Joindate { get; set; }
        public int Did { get; set; }
        //Navigation Prop
        [ForeignKey("Did")]
        public Dept Depts { get; set; }
    }
}
