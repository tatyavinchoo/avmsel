﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace HandsOnEFUsingCodeFirst_Demo2
{
    [Table("tblDept")]
    class Dept
    {
        [Key]
        public int DId { get; set; }
        [StringLength(20)]
        [Column("Dname",TypeName="Char")]
        public string Dname { get; set; }
        public virtual ICollection<Employee> Employees { get; set; }
    }
}
