﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HandsOnMVCUsingPartialViews.Models;
namespace HandsOnMVCUsingPartialViews.Controllers
{
    public class EmpController : Controller
    {
        //
        // GET: /Emp/
        EmployeeRep db = new EmployeeRep();
        public ActionResult Index()
        {
            return View(db.GetAllEmployees());
        }
        public ActionResult GetByDesig(string desig)
        {
            return View(db.GetEmpByDesig(desig));
        }
        public ActionResult GetBySal(int sal)
        {
            return View(db.GetEmpBySal(sal));
        }
        public ActionResult GetById(int Id)
        {
            return View(db.GetEmpById(Id));
        }

    }
}
