﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HandsOnMVCUsingPartialViews.Controllers
{
    public class EmployeeController : Controller
    {
        //
        // GET: /Employee/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Login(string name)
        {
            Session["un"] = name;
            return RedirectToAction("Details");
        }
        public ActionResult Details()
        {
            return View();
        }

    }
}
