﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HandsOnMVCUsingPartialViews.Models
{
    public class EmployeeRep
    {
        List<Employee> db = new List<Employee>()
        {
            new  Employee(){Eid=1,Ename="Rohan",Desig="Progammer",Salary=10000},
             new  Employee(){Eid=2,Ename="Jeson",Desig="TL",Salary=40000},
              new  Employee(){Eid=3,Ename="Raman",Desig="Progammer",Salary=11000},
               new  Employee(){Eid=4,Ename="Krishna",Desig="TL",Salary=40000},
                new  Employee(){Eid=5,Ename="Suren",Desig="Progammer",Salary=10000},
                 new  Employee(){Eid=6,Ename="Karan",Desig="TL",Salary=40000},
                  new  Employee(){Eid=7,Ename="David",Desig="Progammer",Salary=14000},
                   new  Employee(){Eid=8,Ename="Monica",Desig="TL",Salary=10000},
                   new  Employee(){Eid=9,Ename="Roy",Desig="Progammer",Salary=12000},
                new  Employee(){Eid=10,Ename="Roshan",Desig="TL",Salary=40000},
        };
        public List<Employee> GetAllEmployees()
        {
            return db;
        }
        public List<Employee> GetEmpByDesig(string desig)
        {
            List<Employee> list = (from d in db where 
                                       d.Desig == desig 
                                   select d).ToList();
            return list;
        }
        public List<Employee> GetEmpBySal(double sal)
        {
            List<Employee> list = (from d in db
                                   where
                                       d.Salary == sal
                                   select d).ToList();
            return list;
        }
        public Employee GetEmpById(int Id)
        {
            return (from f in db 
                    where f.Eid == Id 
                    select f).SingleOrDefault();
        }
    }
}