﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DemoOnHtmlStandardHelpers.Models
{
    public class User
    {
        public string Fname{get;set;}
        public string Lname { get; set; }
        public string Email { get; set; }
        public string Country { get; set; }
        public string Uname { get; set; }
        public string Pwd { get; set; }
    }
}