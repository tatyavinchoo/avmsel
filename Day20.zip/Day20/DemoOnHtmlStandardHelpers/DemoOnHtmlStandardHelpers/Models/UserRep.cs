﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DemoOnHtmlStandardHelpers.Models
{
    public class UserRep
    {
        static List<User> db = new List<User>();
        public void Register(User user)
        {
            db.Add(user);
        }
        public User Validate(string uname,string pwd)
        {
            User user=(from t in db
                           where t.Uname==uname && t.Pwd==pwd select t).SingleOrDefault();
            return user;
        }
       
    }
}