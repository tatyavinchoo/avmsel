﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DemoOnHtmlStandardHelpers.Models;
namespace DemoOnHtmlStandardHelpers.Controllers
{
    public class UserController : Controller
    {
        //
        // GET: /User/
        UserRep db = new UserRep();
        public ActionResult Login()
        {
            return View();
        }
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(User obj)
        {
            db.Register(obj);
            return RedirectToAction("Login");
        }
        public ActionResult Validate(string uname,string pwd)
        {
            User obj=db.Validate(uname, pwd);
            if (obj != null)
            {
                return View("Details", obj);
                
            }
            else if (uname == "Admin" && pwd == "12344")
            {
                return RedirectToAction("Admin");
            }
            else
            {
                TempData["err"] = "Invalid User Credentials";
                return RedirectToAction("Login");
            }
                
        }
        public ActionResult Details(User obj)
        {
            return View(obj);
        }


    }
}
