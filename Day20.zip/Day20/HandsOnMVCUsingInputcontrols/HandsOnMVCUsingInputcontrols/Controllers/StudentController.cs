﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HandsOnMVCUsingInputcontrols.Models;
using HandsOnMVCUsingInputcontrols.Models.Entity;
namespace HandsOnMVCUsingInputcontrols.Controllers
{
    public class StudentController : Controller
    {
        //
        // GET: /Student/
        StudentRep db = new StudentRep();
        public ActionResult Index() //return all students
        {
           // List<Student> list = db.GetStudents();
            return View(db.GetStudents());
        }
        public ActionResult Create()
        {
            return View();
        }
        public ActionResult NewStudent(Student obj)
        {
            string msg;
            db.Add(obj, out msg);
            if (msg == "")
                return RedirectToAction("Index");
            else
            {
                TempData["err"] = msg;
                return View("Create");
            }
        }
    }
}
