﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HandsOnMVCUsingInputcontrols.Models.Entity;
namespace HandsOnMVCUsingInputcontrols.Models
{
    public class StudentRep
    {
        static List<Student> db = new List<Student>()
        {
            new Student(){Sid=1,Sname="Rohan",Age=10},
            new Student(){Sid=2,Sname="Karan",Age=11}
        };
        public List<Student> GetStudents() //Return data sorted order of Name
        {
            return db.OrderBy(i => i.Sname).ToList();
        }
        public void Add(Student s,out string msg)
        {
            msg = string.Empty;//out parameter should be initialized
            Student ob = db.SingleOrDefault(i => i.Sid == s.Sid);
            if (ob == null)
                db.Add(s);
            else
                msg = "Id exist";

        }
    }
}