package testng;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


public class paramtertxml {
	WebDriver driver;
	@Test
	@Parameters({ "sUsername", "sPassword" })
	
	
	 
	  public void test(String sUsername, String sPassword) {
	 
		System.setProperty("webdriver.ie.driver", "D:\\software\\Selenium Softwares\\IEDriverServer_Win32_2.53.0\\IEDriverServer.exe");
		driver=new InternetExplorerDriver();
		driver.get("https://api.checklist.com/login");
		 driver.findElement(By.name("j_username")).sendKeys(sUsername);
			driver.findElement(By.name("j_password")).sendKeys(sPassword);
	      driver.quit();
	 
	  }
	 
	}

