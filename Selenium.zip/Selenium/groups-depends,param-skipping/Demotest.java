package testng;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Demotest {
	WebDriver driver;
	@BeforeTest
	public void intialise() throws InterruptedException
	{
		System.setProperty("webdriver.ie.driver", "D:\\software\\Selenium Softwares\\IEDriverServer_Win32_2.53.0\\IEDriverServer.exe");
		driver=new InternetExplorerDriver();
		driver.get("https://api.checklist.com/login");
		Thread.sleep(2000);
		System.out.println(driver.getTitle());
		
		//assertEquals("apichekclist",driver.getTitle());
	}
  @Test
  public void Login() {
	  driver.findElement(By.name("j_username")).sendKeys("nishammu1990@gmail.com");
		driver.findElement(By.name("j_password")).sendKeys("nisha123");
		driver.findElement(By.xpath("//*[@id='loginForm']/div[3]/button")).click();
  }
  
  @Test(dependsOnMethods="Login")
  public void application()
  {
	assertEquals("https://api.checklist.com/account/#",driver.getCurrentUrl());
  }
}
