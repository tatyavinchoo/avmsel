package testng;

import org.testng.annotations.Test;

public class Testgroups {
  @Test(groups="odd")
  public void Test1() {
	  
	  System.out.println("odd");
  }
  
  @Test(groups="even")
  public void Test2() {
	  
	  System.out.println("even");
  }
  
  
  
  @Test(groups="odd")
  public void Test3() {
	  System.out.println("odd");
  }
	  
  @Test(groups="even")
	  public void Test4() {
		  
		  System.out.println("even");
	  }
	  
	  
  }
  
  

