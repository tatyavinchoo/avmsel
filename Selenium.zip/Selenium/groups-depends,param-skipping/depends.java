package testng;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.Test;

public class depends {
	
	
	
  @Test
  public void login() {
	  System.out.println("logged in successfully");
	 assertEquals("a", "b");
  }
  
  @Test(dependsOnMethods="login")
  public void application() {
	  System.out.println("application ");
  }
  
  
  @Test(dependsOnMethods="application")
  public void logout() {
	  System.out.println("logout successful");
  }
}
