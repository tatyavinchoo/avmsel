import java.io.File;
import java.io.IOException;

import jxl.JXLException;
import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;


public class Sample_pro {
	public static void main(String[] args) throws Exception
	{
		Workbook wb=Workbook.getWorkbook(new File("C:\\Users\\616813\\Desktop\\MFRP_data.xls"));
	Sheet s1=wb.getSheet(0);
	System.setProperty("webdriver.ie.driver","D:\\softwares\\selenium IDE\\2.9.0\\32-Bit\\IEDriverServer.exe");
	WebDriver driver=new InternetExplorerDriver();
		
		for(int j=0;j<(s1.getColumns()-1);j++)
		{
		for(int i=0;i<s1.getRows();i++)
		{
			driver.get("http://ctsc00849530701:9000/Pharma");
		driver.findElement(By.name("username")).sendKeys(s1.getCell(j, i).getContents());
		System.out.println(s1.getCell(j, i).getContents());
		driver.findElement(By.name("password")).sendKeys(s1.getCell(j+1,i).getContents());
		System.out.println(s1.getCell(j+1,i).getContents());
		Thread.sleep(1000);
		driver.findElement(By.xpath("./html/body/div[2]/form/table/tbody/tr[3]/td/input")).click();
		
		//driver.close();
	}
	}
		driver.findElement(By.xpath("./html/body/div[2]/div/a[1]")).click();
	}
}
