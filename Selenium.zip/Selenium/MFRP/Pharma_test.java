package testng;

import org.junit.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Pharma_test {
	
  @Test(priority=1)
  public void f() {
	  Pharma_Data.config();
	  Pharma_Data.login();
  }
  @Test(priority=2)
  public void l()
  {
	  Pharma_Data.links();
  }
@Test(priority=3)
public void s()
{
	Pharma_Data.search();
}
@Test(priority=4)
public void u()
{
	Pharma_Data.update();
}

@Test(priority=5)
public void d()
{
	Pharma_Data.delete();
}
@Test(priority=6)
public void lo()
{
	Pharma_Data.logout();
}
}
