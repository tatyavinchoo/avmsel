package testng;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Iterator;

import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.apache.poi.ss.usermodel.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;



public class Pharma_Data {
	static WebDriver driver;
	static FileInputStream excelFile;
	static XSSFWorkbook workbook;
	public static void config()
	{

		System.setProperty("webdriver.ie.driver","D:\\IEDriver\\IEDriverServer.exe");
		 driver=new InternetExplorerDriver();
		
	}
public static void login()
{

	try {
		excelFile = new FileInputStream(new File("D:\\cdNew\\Pharma_Test\\Pharma.xlsx"));
		workbook = new XSSFWorkbook(excelFile);
		XSSFSheet s1 = (XSSFSheet) workbook.getSheetAt(0);
		 Iterator<Row> iterator = s1.iterator();
		 driver.get("http://ctsc00849530701:9000/Pharma");
         while (iterator.hasNext()) {
        	 int k=0;
             Row currentRow = iterator.next();
             Iterator<Cell> cellIterator = currentRow.iterator();
            
             while (cellIterator.hasNext()) {

                 Cell currentCell = cellIterator.next();
                 if(k==0)
                 {driver.findElement(By.name("username")).sendKeys((currentCell.getStringCellValue()));
                 k++;
                 }
                 else if(k==1){
                	 driver.findElement(By.name("password")).sendKeys((currentCell.getStringCellValue()));
                	 k--;
                 }
                 
             }
             Thread.sleep(1000);
     		driver.findElement(By.xpath("./html/body/div[2]/form/table/tbody/tr[3]/td/input")).click();
     		Thread.sleep(1000);
		
	}} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    }
public static void links()
{
	try {
for(int i=1;i<6;i++)
{
	driver.findElement(By.xpath("/html/body/div[1]/div[2]/a["+i+"]")).click();
	
		Thread.sleep(2000);
	
}

XSSFSheet sh = (XSSFSheet) workbook.getSheetAt(1);
Iterator<Row> iterator = sh.iterator();

while (iterator.hasNext()) {
	 
    Row currentRow = iterator.next();
    Iterator<Cell> cellIterator = currentRow.iterator();
    driver.findElement(By.xpath("/html/body/div[1]/div[2]/a[2]")).click();
    while (cellIterator.hasNext()) {

    Cell currentCell = cellIterator.next();
driver.findElement(By.xpath("//*[@id='batchcode']")).clear();
driver.findElement(By.xpath("//*[@id='batchcode']")).sendKeys(String.valueOf((int)currentCell.getNumericCellValue()));

System.out.println(currentCell.getNumericCellValue());

if(String.valueOf((int)currentCell.getNumericCellValue()).length()>6)
{
WebDriverWait wait = new WebDriverWait(driver,3);
wait.until(ExpectedConditions.alertIsPresent());

driver.switchTo().alert().accept();
Thread.sleep(2000);
driver.findElement(By.xpath("/html/body/div[1]/div[2]/a[2]")).click();
}
currentCell = cellIterator.next();
/*if(ExpectedConditions.alertIsPresent() != null)
{
	Alert a= driver.switchTo().alert();
	a.accept();
}*/

Thread.sleep(1000);
WebElement e= driver.findElement(By.xpath("//*[@id='medicinecode']"));
Select s=new Select(e);
s.selectByIndex(2);

/*if(ExpectedConditions.alertIsPresent() != null)
{
	Alert a1= driver.switchTo().alert();
	Thread.sleep(1000);
	a1.accept();
}*/

Thread.sleep(1000);
driver.findElement(By.xpath("//*[@id='weight']")).clear();
driver.findElement(By.xpath("//*[@id='weight']")).sendKeys(String.valueOf((int)currentCell.getNumericCellValue()));
if(String.valueOf((int)currentCell.getNumericCellValue()).length()>6)
{
WebDriverWait wait2 = new WebDriverWait(driver,3);
wait2.until(ExpectedConditions.alertIsPresent());

driver.switchTo().alert().accept();
Thread.sleep(2000);
driver.findElement(By.xpath("/html/body/div[1]/div[2]/a[2]")).click();
}
/*if(ExpectedConditions.alertIsPresent() != null)
{
	Alert a2= driver.switchTo().alert();
	Thread.sleep(1000);
	a2.accept();
}*/
System.out.println(currentCell.getNumericCellValue());
currentCell = cellIterator.next();


Thread.sleep(1000);
driver.findElement(By.xpath("//*[@id='price']")).clear();
driver.findElement(By.xpath("//*[@id='price']")).sendKeys(String.valueOf((int)currentCell.getNumericCellValue()));
if(String.valueOf((int)currentCell.getNumericCellValue()).length()>6)
{
WebDriverWait wait3 = new WebDriverWait(driver,3);
wait3.until(ExpectedConditions.alertIsPresent());

driver.switchTo().alert().accept();
Thread.sleep(2000);
driver.findElement(By.xpath("/html/body/div[1]/div[2]/a[2]")).click();
}
/*if(ExpectedConditions.alertIsPresent() != null)
{
	Alert a4= driver.switchTo().alert();
	Thread.sleep(1000);
	a4.accept();
}*/
System.out.println(currentCell.getNumericCellValue());

Thread.sleep(1000);
WebElement e1=driver.findElement(By.xpath("/html/body/div[2]/div/form/table/tbody/tr[6]/td/select"));
Select s1=new Select(e1);
s1.selectByIndex(1);
Thread.sleep(1000);
driver.findElement(By.xpath("/html/body/div[2]/div/form/table/tbody/tr[7]/td")).click();
Thread.sleep(1000);
driver.findElement(By.xpath("/html/body/div[2]/div/form/table/tbody/tr[8]/td/input")).click();
/*WebDriverWait wait4 = new WebDriverWait(driver,30);
wait4.until(ExpectedConditions.alertIsPresent());

driver.switchTo().alert().accept();
if(ExpectedConditions.alertIsPresent() != null)
{
	Alert a3= driver.switchTo().alert();
	Thread.sleep(1000);
	a3.accept();
	
}*/

Thread.sleep(1000);
 
    }
}
    
} catch (InterruptedException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
}


public static void search()
{  
	try{
		XSSFSheet sh = (XSSFSheet) workbook.getSheetAt(2);
		Iterator<Row> iterator = sh.iterator();

		while (iterator.hasNext()) {
			
		    Row currentRow = iterator.next();
		    Iterator<Cell> cellIterator = currentRow.iterator();
		    
		    while (cellIterator.hasNext()) {
		    	Cell currentCell = cellIterator.next();
		    	driver.findElement(By.xpath("html/body/div[1]/div[2]/a[3]")).click();
		    	driver.findElement(By.xpath(".//*[@id='batchcode']")).sendKeys(String.valueOf((int)currentCell.getNumericCellValue()));
		    	driver.findElement(By.xpath(".//*[@id='batchtable']/tbody/tr[3]/td/input")).click();
		    	Thread.sleep(1000);
		    	driver.findElement(By.xpath(".//*[@id='batchcode']")).clear();
	
		    }
		}
	}catch(Exception e)
	{
	e.printStackTrace();
	}
}
public static void update()
{
	try{
		XSSFSheet sh = (XSSFSheet) workbook.getSheetAt(3);
		Iterator<Row> iterator = sh.iterator();

		while (iterator.hasNext()) {
			
		    Row currentRow = iterator.next();
		    Iterator<Cell> cellIterator = currentRow.iterator();
		    
		    while (cellIterator.hasNext()) {
		    	Cell currentCell = cellIterator.next();
		
		WebElement e= driver.findElement(By.xpath("//*[@id='medicinecode']"));
		Select s=new Select(e);
		s.selectByIndex(3);
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id='weight']")).clear();
		driver.findElement(By.xpath("//*[@id='weight']")).sendKeys(String.valueOf((int)currentCell.getNumericCellValue()));
		
		currentCell = cellIterator.next();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id='price']")).clear();
		driver.findElement(By.xpath("//*[@id='price']")).sendKeys(String.valueOf((int)currentCell.getNumericCellValue()));
		
		Thread.sleep(1000);
		WebElement e1=driver.findElement(By.xpath("/html/body/div[2]/div/form/table/tbody/tr[6]/td/select"));
		Select s1=new Select(e1);
		s1.selectByIndex(2);
		Thread.sleep(1000);
		driver.findElement(By.xpath("html/body/div[2]/div/form/table/tbody/tr[8]/td/input")).click();
		Thread.sleep(2000);
		    }
		}
	}catch(Exception e)
	{
	e.printStackTrace();
	}
	
	
}
public static void delete()
{
	try{
		
		XSSFSheet sh = (XSSFSheet) workbook.getSheetAt(3);
		Iterator<Row> iterator = sh.iterator();

		while (iterator.hasNext()) {
			
		    Row currentRow = iterator.next();
		    Iterator<Cell> cellIterator = currentRow.iterator();
		    
		    while (cellIterator.hasNext()) {
		    	Cell currentCell = cellIterator.next();
		driver.findElement(By.xpath("html/body/div[1]/div[2]/a[4]")).click();
	
		driver.findElement(By.xpath(".//*[@id='batchcode']")).sendKeys(String.valueOf((int)currentCell.getNumericCellValue()));
		Thread.sleep(2000);
		driver.findElement(By.xpath(".//*[@id='batchtable']/tbody/tr[3]/td/input")).click();
		Thread.sleep(2000);
		    }
		}
	
	}catch(Exception e)
	{
	e.printStackTrace();
	}
}
public static void logout()
{
	try {
		Thread.sleep(3000);
		driver.findElement(By.xpath("html/body/div[1]/div[2]/a[6]")).click();
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
}
	



