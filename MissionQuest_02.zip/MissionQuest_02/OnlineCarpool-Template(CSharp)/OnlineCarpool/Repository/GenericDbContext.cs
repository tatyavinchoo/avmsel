﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using OnlineCarpool.Models;

namespace OnlineCarpool.Repository
{
    public class GenericRepoContext : DbContext
    {
        public GenericRepoContext() : base("CarpoolContext") { }

        public DbSet<Users> Users { get; set; }
        public DbSet<Vehicles> Vehicles { get; set; }
        public DbSet<Bookings> Bookings { get; set; }
        public DbSet<Distance> Distance { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {

        }
    }
}