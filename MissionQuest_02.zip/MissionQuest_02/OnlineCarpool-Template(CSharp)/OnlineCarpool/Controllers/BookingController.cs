﻿using OnlineCarpool.Models;
using OnlineCarpool.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OnlineCarpool.Controllers
{
    public class BookingController : Controller
    {
        private IGenericRepository<BookingViewModel> repository = null;
        private IGenericRepository<Bookings> carRepo = null;
        private IGenericRepository<Vehicles> vehicleRepo = null;
        private IGenericRepository<Distance> distanceRepo = null;

        public BookingController()
        {
            this.repository = new GenericRepository<BookingViewModel>();
            this.carRepo = new GenericRepository<Bookings>();
            this.vehicleRepo = new GenericRepository<Vehicles>();
            this.distanceRepo = new GenericRepository<Distance>();
        }

        public ActionResult Index()
        {
            //Implement Requirement 3 here.
            return View();
        }

        public ActionResult Booking(string vehicleID)
        {
            if (Session["UserID"] == null)
            {
                return RedirectToAction("Login", "Login");
            }
            var booking = GenerateData(vehicleID, Session["UserID"].ToString());
            booking.book.OriginCity = booking.dist.Select(x => x.OriginCity).First();
            booking.book.DestinationCity = booking.dist.Select(x => x.DestinationCity).First();
            return View(booking);
        }

        [HttpGet]
        public PartialViewResult Calculate(string oCity, string dCity, string vID)
        {
            var booking = GenerateData(vID, Session["UserID"].ToString());
            booking.book.OriginCity = oCity;
            booking.book.DestinationCity = dCity;
            return PartialView("_Calculate", booking);
        }

        public BookingViewModel GenerateData(string vID, string username)
        {
            var booking = new BookingViewModel();
            var vehicle = from d in vehicleRepo.SelectAll()
                          where d.VehicleID == vID
                          select d;
            var dist = from d in distanceRepo.SelectAll()
                       select d;
            var book = new Bookings();
            book.Username = username;
            book.VehicleID = vID;
            book.BookingDate = DateTime.Now.Date;
            book.ReturnDate = DateTime.Now.Date;
            book.TravelDate = DateTime.Now.Date;

            booking.book = book;
            booking.vehicle = vehicle;
            booking.dist = dist;
            return booking;
        }

        [HttpPost]
        public ActionResult Booking(BookingViewModel SaveBookingDetails)
        {
            Bookings data = new Bookings();
            data = SaveBookingDetails.book;
            if (ModelState.IsValid)
            {
                carRepo.Insert(data);
                carRepo.Save();
                Session["Message"] = "Thank you for booking a car with us. Your request has been submitted successfully. Please wait for our call.";
                return RedirectToAction("Index");
            }
            SaveBookingDetails.dist = GenerateData(SaveBookingDetails.book.VehicleID,SaveBookingDetails.book.Username).dist;
            SaveBookingDetails.vehicle = GenerateData(SaveBookingDetails.book.VehicleID, SaveBookingDetails.book.Username).vehicle;
            return View(SaveBookingDetails);
        }
    }
}
