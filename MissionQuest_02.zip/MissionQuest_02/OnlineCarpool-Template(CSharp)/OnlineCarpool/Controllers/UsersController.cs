﻿using OnlineCarpool.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OnlineCarpool.Models;

namespace OnlineCarpool.Controllers
{
    public class UsersController : Controller
    {

        private IGenericRepository<Users> repository = null;
        public UsersController()
        {
            this.repository = new GenericRepository<Users>();
        }
        public ActionResult Index()
        {
            if (Session["UserID"] == null)
            {
                return RedirectToAction("Login", "Login");
            }
            var User = repository.SelectAll().ToList();
            return View(User);
        }



        public ActionResult Details(string uname)
        {
            if (Session["UserID"] == null)
            {
                return RedirectToAction("Login", "Login");
            }
            var User = repository.SelectByID(uname);
            return View(User);
        }


        public ActionResult Create()
        {
            if (Session["UserID"] == null)
            {
                return RedirectToAction("Login", "Login");
            }
            return View();
        }

        //Requirment1

    }
}
