﻿using OnlineCarpool.Models;
using OnlineCarpool.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OnlineCarpool.Controllers
{
    public class SearchCarController : Controller
    {
        //
        // GET: /SearchCar/
        private IGenericRepository<Vehicles> repository = null;
        public SearchCarController()
        {
            this.repository = new GenericRepository<Vehicles>();
        }
        public ActionResult Index()
        {
            if (Session["UserID"] == null)
            {
                return RedirectToAction("Login", "Login");
            }
            SearchFilter data = new SearchFilter();
            List<ACList> ACList = new List<Models.ACList>();
            List<TypeList> TypeList = new List<Models.TypeList>();

            var list = (from b in repository.SelectAll()
                        orderby b.VehicleID
                        select b.Type).Distinct().ToList();
            foreach (string cType in list)
            {
                TypeList tl = new Models.TypeList();
                tl.Type = cType;
                TypeList.Add(tl);
            }

            list = (from b in repository.SelectAll()
                        orderby b.VehicleID
                        select b.IsAC).Distinct().ToList();
            foreach (string cType in list)
            {
                ACList al = new Models.ACList();
                al.IsAC = cType;
                ACList.Add(al);
            }

            data.ACList = ACList;
            data.TypeList = TypeList;
            return View(data);
        }

        //Implement Requirement 2 here. Add action method to return the partial view
    }
}
