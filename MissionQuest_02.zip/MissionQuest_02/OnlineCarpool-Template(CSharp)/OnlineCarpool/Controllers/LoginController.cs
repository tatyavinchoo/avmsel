﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OnlineCarpool.Models;
using OnlineCarpool.Repository;

namespace OnlineCarpool.Controllers
{
    public class LoginController : Controller
    {
        private IGenericRepository<Users> repository = null;
        public LoginController() {
            this.repository = new GenericRepository<Users>();
        }
        public ActionResult Login()
        {
            if (Session["UserID"] == null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Index", "SearchCar");
            }
        }
        [HttpPost]
        public ActionResult Login(Login user)
        {
            //var log = repository.SelectByID(user.Username.ToString());
            var log = repository.SelectAll();
            if (ModelState.IsValid && log != null)
            {
                foreach (Users usr in log)
                {
                    if (usr.Username == user.Username && usr.Password == user.Password)
                    {
                        Session["UserID"] = usr.Username.ToString();
                        if (Session["UserID"].ToString().ToLower() == "admin")
                        {
                            return RedirectToAction("Index", "Users");
                        }
                        else
                        {
                            return RedirectToAction("Index", "SearchCar");
                        }
                    }
                        
                }
            }
           ModelState.AddModelError("", "The user name or password provided is incorrect.");
           return View();
        }
        public ActionResult LogOff()
        {
            Session.Abandon();
            return RedirectToAction("Index", "Home");
        }
        public ActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Register(Users user)
        {
            if (ModelState.IsValid)
            {
                repository.Insert(user);
                repository.Save();
                Session["Message"] = "Thank you for your Registration. Your details have been submitted successfully.";
                return RedirectToAction("Login", "Login");
            }
            else
            {
                ModelState.AddModelError("", "The details provided by you are incorrect.");
                return View();
            }
        }
    }
}
