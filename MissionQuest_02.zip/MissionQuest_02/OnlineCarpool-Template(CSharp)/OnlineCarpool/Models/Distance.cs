﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace OnlineCarpool.Models
{
    [Table("tblDistance")]
    public class Distance
    {
        [Key]
        [DisplayName("Route ID")]
        public int RouteID { get; set; }
        [DisplayName("Origin City")]
        public string OriginCity { get; set; }
        [DisplayName("Destination City")]
        public string DestinationCity { get; set; }
        [DisplayName("Distance (In KMs)")]
        [Column("Distance")]
        public int Dist { get; set; }
    }
}