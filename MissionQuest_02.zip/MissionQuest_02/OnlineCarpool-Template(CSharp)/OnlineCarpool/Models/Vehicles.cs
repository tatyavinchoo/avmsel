﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace OnlineCarpool.Models
{
    [Table("tblVehicles")]
    public class Vehicles
    {
        [Key]
        [DisplayName("Vehicle ID")]
        public string VehicleID { get; set; }
        [DisplayName("Vehicle Name")]
        public string VehicleName { get; set; }
        [DisplayName("Passengers Allowed")]
        public int PassengersAllowed { get; set; }
        [DisplayName("Rate/KM (in ₹)")]
        public int Rate { get; set; }
        [DisplayName("Is AC")]
        public string IsAC { get; set; }
        [DisplayName("Vehicle Type")]
        public string Type { get; set; }
    }
    public class TypeList {
        public string Type { get; set; }
    }
    public class ACList
    {
        public string IsAC { get; set; }
    }
    public class SearchFilter
    {
        [DisplayName("Is AC")]
        public IEnumerable<ACList> ACList { get; set; }

        [DisplayName("Vehicle Type")]
        public IEnumerable<TypeList> TypeList { get; set; }
    }
}