﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OnlineCarpool.Models
{
    public class BookingViewModel
    {
        public Bookings book { get; set; }
        public IEnumerable<Distance> dist { get; set; }
        public IEnumerable<Vehicles> vehicle { get; set; }
    }
   
}