﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace OnlineCarpool.Models
{
    [Table("tblUsers")]
    public class Users
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Required(ErrorMessage = "Enter Username")]
        [DisplayName("Username")]
        [StringLength(10, ErrorMessage = "Max. 10 characters")]
        public string Username { get; set; }

        [Required(ErrorMessage = "Enter Password")]
        [DisplayName("Password")]
        [RegularExpression("^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{6,10}$", ErrorMessage = "Password must be 6-10 characters long and a combination of numbers & alphabets")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Enter Contact No.")]
        [DisplayName("Contact No")]
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter a 10 digit contact number")]
        public string ContactNo { get; set; }

        [Required(ErrorMessage = "Enter Email Address")]
        [DisplayName("Email ID")]
        [RegularExpression(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$", ErrorMessage = "Enter a valid Email address")]
        public string Email { get; set; }
    }

}