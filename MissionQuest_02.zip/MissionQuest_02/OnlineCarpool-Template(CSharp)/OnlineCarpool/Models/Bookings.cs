﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace OnlineCarpool.Models
{
    //Implement Requirement 4 here
    [Table("tblBookings")]
    public class Bookings
    {
        
        public int BookingID { get; set; }
        [DisplayName("Vehicle ID")]
        public string VehicleID { get; set; }
        [DisplayName("Origin City")]
        public string OriginCity { get; set; }
        [DisplayName("Destination City")]
        public string DestinationCity { get; set; }
        [DisplayName("Distance (in KMs)")]
        public int Distance { get; set; }
        [DisplayName("Fare (in ₹)")]
        public int Fare { get; set; }

        [DisplayName("Booking Date")]
      
        public DateTime BookingDate { get; set; }

        [DisplayName("Travel Date")]
        public DateTime TravelDate { get; set; }
        [DisplayName("Return Date")]
        public DateTime ReturnDate { get; set; }
        [DisplayName("Username")]
        public string Username { get; set; }
    }

    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class CurrentDateAttribute : ValidationAttribute
    {

        protected override ValidationResult IsValid(object value, ValidationContext context)
        {
            if (value != null)
            {
                var dt = Convert.ToDateTime(value);
                if (dt >= DateTime.Now.Date)
                {
                    return ValidationResult.Success;
                }

            }
            return new ValidationResult("Travel Date and Return Date must be after or equal to current date");
        }
    }

    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class DateGreaterThanAttribute : ValidationAttribute
    {
        private string DateToCompareToFieldName { get; set; }
        public DateGreaterThanAttribute(string dateToCompareToFieldName)
        {
            DateToCompareToFieldName = dateToCompareToFieldName;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value != null)
            {
                Bookings obj = (Bookings)validationContext.ObjectInstance;
                DateTime earlierDate = (DateTime)obj.TravelDate;
                DateTime laterDate = (DateTime)obj.ReturnDate;

                if (laterDate >= earlierDate)
                {
                    return ValidationResult.Success;
                }
                else
                {
                    return new ValidationResult("Return Date must be same or later than the Travel Date");
                }
            }
            else
            {
                return new ValidationResult("Return Date must be same or later than the Travel Date");
            }
        }
    }
}