﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnLinq
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = { 12, 23, 34, 54, 34, 22, 10, 56, 45 };
            var res = from i in a where i > 20 select i;
            //Console.WriteLine(res);
            a[1] = 9;
            //return no's >20 and even 
            var res1 = from int i in a where i > 20 && i % 2 == 0 select i;
            //return square of array no's
            var res2 = from j in a select j * j;
            //return square of array no's >100 and <1000
            var res3 = from j in a
                       let l = j * j
                       where l > 100 && l < 1000
                       select l;
            //sort array elements in asc
            var res4 = from j in a
                       orderby j ascending
                       select j;
            //sort elements in desc
            var res5 = from j in a
                       where j%2!=0
                       orderby j descending
                       select j;
            foreach (var k in res5)
            {
                Console.WriteLine(k);
            }
            Console.ReadKey();

        }
    }
}
