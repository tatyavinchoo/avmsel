﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnLinq
{
    class Student
    {
        public int Sid;
        public string Sname;
    }
    class Enroll
    {
        public int Sid;
        public string Cname;
        public DateTime EnrollDate;
    }
    class Demo3
    {
        static void Main()
        {
            List<Student> student = new List<Student>()
            {
                new Student(){Sid=1,Sname="Rohan"},
                new Student(){Sid=2,Sname="Karan"},
                new Student(){Sid=3,Sname="Jeson"},
                new Student(){Sid=4,Sname="Sachin"},
            };
            List<Enroll> enroll = new List<Enroll>()
            {
                new Enroll(){Sid=1,Cname="C#",EnrollDate=DateTime.Now},
                new Enroll(){Sid=1,Cname="SqlServer",EnrollDate=DateTime.Now},
                new Enroll(){Sid=2,Cname="C#",EnrollDate=DateTime.Now},
                new Enroll(){Sid=3,Cname="C#",EnrollDate=DateTime.Now},
                new Enroll(){Sid=4,Cname="C#",EnrollDate=DateTime.Now},
            };
            //joining two datasources
            var join = from s in student
                       join
                       e in enroll
                       on s.Sid equals e.Sid
                       where e.Cname=="SqlServer"
                       select new {s.Sid,s.Sname,e.Cname,e.EnrollDate };
            foreach (var j in join)
            {
                Console.WriteLine("{0} {1} {2} {3}", j.Sid, j.Sname, j.Cname, j.EnrollDate);
            }
        }
    }
}
