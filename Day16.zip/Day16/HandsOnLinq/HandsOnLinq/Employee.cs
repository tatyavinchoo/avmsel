﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnLinq
{
    class Employee
    {
        public int Eid { get; set; }
        public string Ename { get; set; }
        public string Desig { get; set; }
        public double Salary { get; set; }
    }
    class Demo2
    {
        static void Main()
        {
            List<Employee> list = new List<Employee>()
            {
                new Employee(){Eid=1,Ename="Karan",Desig="Programmer",Salary=12000},
                new Employee(){Eid=2,Ename="Roshan",Desig="Programmer",Salary=12000},
                new Employee(){Eid=3,Ename="Rohan",Desig="TeamLeader",Salary=32000},
                new Employee(){Eid=4,Ename="Jeson",Desig="Programmer",Salary=12000},
                new Employee(){Eid=5,Ename="Monica",Desig="Programmer",Salary=12000},
                new Employee(){Eid=6,Ename="Karan",Desig="TeamLeader",Salary=32000},
                new Employee(){Eid=7,Ename="Sachin",Desig="Programmer",Salary=12000},
                new Employee(){Eid=8,Ename="Rahul",Desig="Programmer",Salary=12000}
            };
            var r = from l in list
                    //where l.Ename == "Jeson"
                    //where l.Desig=="Programmer"
                    where l.Salary>20000
                    select l;
            //return only enames
            var r1 = from l in list
                     select l.Ename;
            //return eid,ename
            var r2 = from l in list
                     where l.Salary>15000
                     orderby l.Ename ascending
                     select new {l.Eid,l.Ename };

            foreach (var k in r2)
            {
                Console.WriteLine("{0} {1}", k.Eid,k.Ename);
            }
            Console.Clear();//clear console 
            //display group enames by desig
            var r3 = from l in list
                     group  new {l.Eid,l.Ename}  by l.Desig;
            foreach (var k in r3)
            {
                Console.WriteLine("Employees working as {0}", k.Key);
                foreach (var s in k)
                    Console.WriteLine(s.Eid+" "+s.Ename);
                
            }
          
        }
    }
}
