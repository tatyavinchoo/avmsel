﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnLinq
{
    class Demo4
    {
        static void Main()
        {
            int[] a = { 12, 23, 34, 54, 34, 22, 10, 56, 45 };
            //return even values from array
            var res = a.Where(i => i % 2 == 0).Select(i => i);
            //return even values >50
            var res1 = a.Where(i => i % 2 == 0).Where(i => i > 50);
            res1 = a.Where(i => i % 2 == 0 && i > 50);
            //sort data in asc
            var res2 = a.OrderBy(k => k);
            //sort data in desc
            var res3 = a.OrderByDescending(k => k);
            int sum = a.Sum(i => i);
            Console.WriteLine("sum " + sum);
            foreach (var i in res1)
                Console.WriteLine(i);
            Console.Clear();
            Console.WriteLine(a.Count());
        }
    }
}
