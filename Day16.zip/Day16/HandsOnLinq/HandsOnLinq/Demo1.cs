﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnLinq
{
    class Demo1
    {
        static void Main()
        {
            string[] email = { "yahoo.com","yahoo.co.in","gmail.com","msn.in","msn.com"};
           var obj = from s in email
                     where s.EndsWith(".in")
                     orderby s ascending
                     select s;
            foreach (var k in obj)
                Console.WriteLine(k);
        }
    }
}
