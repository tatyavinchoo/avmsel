﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnNewFeatures
{
    class Student 
    {
        //Automatic Properties
        public int Sid
        {
            get;
            set;
        }
        public string Sname { get; set; }
        public int Age { get; set; }
        static void Main()
        {
            Student s = new Student();
            s.Sid = 100;
            s.Sname = "Roshan";
            s.Age = 12;
            //ObjectInitializers
            Student s1 = new Student() { Sid=101,Sname="Karan",Age=10};
            List<Student> l = new List<Student>();
            l.Add(s);
            l.Add(s1);
            //CollectionInitializer
            List<Student> list = new List<Student>()
            {
                new Student() { Sid=101,Sname="Karan",Age=10},
                new Student() { Sid=102,Sname="Suren",Age=10},
                new Student() { Sid=103,Sname="Jeson",Age=10},
                new Student() { Sid=104,Sname="Karan",Age=10},
                new Student() { Sid=105,Sname="Karan",Age=10}
            };
            foreach (var ob in list)
            {
                Console.WriteLine(ob.Sname);
            }
        }

    }
    class Program
    {
        
        static void Main(string[] args)
        {
            //implicitly typed local variable
            var i = 12;
            Console.WriteLine(i.GetType());
            var s = "hello";
            Console.WriteLine(s.GetType());
            var obj = new Student();
            //error
            //var k;
            //k = 123;
        }
    }
}
