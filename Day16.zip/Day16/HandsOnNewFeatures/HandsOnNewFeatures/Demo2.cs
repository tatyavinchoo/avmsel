﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnNewFeatures
{
    class Demo2
    {
        public static void Sum(int a, int b=10)
        {
            Console.WriteLine(a + b);
        }
        public static string Greet(string name = "undefined")
        {
            return "Hello " + name;
        }
        static void Main()
        {
            Sum(12, 23);
            Sum(19);
            Greet("Sachin");
            Greet();
            //named parameters
            Sum(a: 12, b: 34);
            Sum(b: 22, a: 11);
            Greet(name: "Rohan");
            int k = 23424;
            Console.WriteLine(k.Sqaure());
        }
    }
}
