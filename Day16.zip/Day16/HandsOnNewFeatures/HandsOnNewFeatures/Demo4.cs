﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnNewFeatures
{
    class Demo4
    {
        static void Main()
        {
            int i = 10;
            string s = "Hello";
            Console.WriteLine(s.ToUpper());
            Console.WriteLine(i.Sqaure());
            Console.WriteLine(i.IsEven() ? "Even" : "Odd");
            string str = null;
            Console.WriteLine(str.IsNull());
            
        }
    }
    public static class MyExtensionMethods
    {
        public static int Sqaure(this int i)
        {
            return i * i;
        }
        public static bool IsEven(this int i)
        {
            if (i % 2 == 0)
                return true;
            else
                return false;
        }
        public static bool IsNull(this string s)
        {
            if (s == null)
                return true;
            else
                return false;
        }

    }
}
