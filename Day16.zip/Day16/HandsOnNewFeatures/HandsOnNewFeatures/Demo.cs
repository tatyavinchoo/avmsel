﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnNewFeatures
{
    class Demo
    {
        static void Main()
        {
            //Anonymous Object
            var obj = new { Eid = 100, Ename = "Roshan" };
            Console.WriteLine(obj.Eid);
            Console.WriteLine(obj.Ename);
            var stu = new { Sid = 1, Sname = "Rohan", age = 12 };
        }
    }
}
