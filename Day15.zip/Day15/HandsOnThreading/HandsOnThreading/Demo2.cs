﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
namespace HandsOnThreading
{
    class Demo2
    {
        public static void M()
        {
            for (int i = 1; i < 10000; i++)
            {
                Console.Write(Thread.CurrentThread.ThreadState);
                if (i == 50)
                    Thread.CurrentThread.Abort();
                Console.Write(i + " ");
            }
        }
        static void Main()
        {
            Thread t = new Thread(M);
            Console.WriteLine(t.ThreadState);
            t.Start();
        }
    }
}
