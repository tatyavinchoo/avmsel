﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
namespace HandsOnThreading
{
    class JoinClass
    {
        public static void Main()
        {
            Thread paramThread = new Thread(new ParameterizedThreadStart(PassParam));
            paramThread.Start("Sachin");
            paramThread.Join();
            Console.WriteLine("end of main");
        }
        private static void PassParam(object o)
        {
            Console.WriteLine("Hello : {0}", o);
           Thread.Sleep(5000);
        }

    }

}

