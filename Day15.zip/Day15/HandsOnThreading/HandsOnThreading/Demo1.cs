﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
namespace HandsOnThreading
{
    class Demo1
    {
        public static void Task1()
        {
            for(byte i=0;i<byte.MaxValue;i++) //print byte values
            {
                Console.Write(i+" ");
                Thread.Sleep(1000);
            }
        }
        public static void Task2()
        {
            //print char of byte value
            for (byte i = 0; i < byte.MaxValue; i++)
            {
                Console.WriteLine(Convert.ToChar(i));
                Thread.Sleep(1000);
            }
        }
        static void Main()
        {
            //Task1();
            //Task2();
            //instatiate thread
            Thread t1 = new Thread(new ThreadStart(Task1));
            Thread t2 = new Thread(Task2);
            //start thread exection
            t1.Start();
            t2.Start();
            Console.ReadKey();
        }
    }
}
