﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
namespace HandsOnThreading
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 1; i <= 5; i++)
            {
                Console.WriteLine("Today's Date & Time " + DateTime.Now);
                //Thread.Sleep(5000);//halt execution 5 secs\
                Thread.Sleep(TimeSpan.FromSeconds(5));
            }
        }
    }
}
