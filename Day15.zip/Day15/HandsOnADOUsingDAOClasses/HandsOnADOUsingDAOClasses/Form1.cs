﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HandsOnADOUsingDAOClasses.DAO;
namespace HandsOnADOUsingDAOClasses
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void SearchById(object sender, EventArgs e)
        {
            int pid = int.Parse(txtId.Text);
            try
            {
                ProductDAO obj = new ProductDAO();
               DataTable dt= obj.GetProductById(pid);
               if (dt.Rows.Count > 0)
               {
                   txtName.Text = dt.Rows[0]["Pname"].ToString();
                   txtPrice.Text = dt.Rows[0]["Price"].ToString();
                   txtStock.Text = dt.Rows[0]["Stock"].ToString();
               }
               else
                   MessageBox.Show("Invalid Id");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void AddProduct(object sender, EventArgs e)
        {
            int id = int.Parse(txtId.Text);
            string pname = txtName.Text;
            int price = int.Parse(txtPrice.Text);
            int stock = int.Parse(txtStock.Text);
            try
            {
                ProductDAO obj = new ProductDAO();
                obj.AddProduct(id, pname, price, stock);
                MessageBox.Show("Record Added");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }
    }
}
