﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnADOUsingDAOClasses.DAO
{
    class Connection
    {
        public static string ConnectionString = @"Data Source=PC232954;Initial Catalog=TrainingDB;User ID=sa;Password=password-1";
    }
}
