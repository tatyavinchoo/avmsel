﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
namespace HandsOnADOUsingDAOClasses.DAO
{
    class ProductDAO
    {
        SqlConnection con = new SqlConnection(Connection.ConnectionString);
        SqlCommand cmd = null;
        SqlDataAdapter da = null;
        string qry;
        public DataTable GetProductById(int pid)
        {
            try
            {
                qry = "Select * from Product where Pid=" + pid;
                da = new SqlDataAdapter(qry, con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
            catch (SqlException ex)
            {
                throw;
            }
            finally
            {
                con.Close();
            }

        }
        public void AddProduct(int pid, string pname, int price, int stock)
        {
            
            try
            {
                qry = "Insert into Product(Pid,Pname,Price,Stock) values("+pid+",'"
                    +pname+"',"+price+","+stock+")";
                cmd = new SqlCommand(qry, con);
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
        public void UpdateProduct(int pid, int price, int stock)
        {
        }
        public void DeleteProduct(int pid)
        {
        }
    }
}
