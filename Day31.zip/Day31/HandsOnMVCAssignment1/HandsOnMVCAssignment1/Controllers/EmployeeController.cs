﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HandsOnMVCAssignment1.Models;
namespace HandsOnMVCAssignment1.Controllers
{
    public class EmployeeController : Controller
    {
        //
        // GET: /Employee/

        public ActionResult Index()
        {
            EmployeeRep repObj = new EmployeeRep();
            List<Employee> list = repObj.GetEmployees();
            return View(list);
        }
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(Employee e)
        {
            EmployeeRep repObj = new EmployeeRep();
            repObj.AddEmployee(e);
            return RedirectToAction("Create");
        }
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(string uname,string pwd)
        {
            EmployeeRep repObj = new EmployeeRep();
            Employee e = repObj.Validate(uname, pwd);
            if(e==null)
            {
                Session["err"] = "Invalid Login Details";
                return View();
            }
            else if(e.Role=="HR")
            {
                Session["usr"] = e.Ename;
                return RedirectToAction("Index");
            }
            else
            {
                Session["usr"] = e.Ename;
                return RedirectToAction("Details", new {eid=e.Eid });
            }
        }
        public ActionResult Details(int eid)
        {
            EmployeeRep repObj = new EmployeeRep();
            Employee e = repObj.GetEmpById(eid);
            return View(e);
        }
        public ActionResult Edit(int eid)
        {
            EmployeeRep repObj = new EmployeeRep();
            Employee e = repObj.GetEmpById(eid);
            return View(e);
        }
        [HttpPost]
        public ActionResult Edit(Employee e)
        {
            return RedirectToAction("Details", new { eid = e.Eid });
        }

    }
}
