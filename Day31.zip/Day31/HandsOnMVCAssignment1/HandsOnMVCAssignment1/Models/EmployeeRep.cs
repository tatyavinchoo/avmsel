﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HandsOnMVCAssignment1.Models
{
    public class EmployeeRep
    {
        static List<Employee> db = new List<Employee>();
        public List<Employee> GetEmployees()
        {
            return db;
        }
        public Employee GetEmpById(int eid)
        {
            Employee e = db.SingleOrDefault(i => i.Eid == eid);
            return e;
        }
        public void AddEmployee(Employee e)
        {
            db.Add(e);
        }
        public Employee Validate(string uname,string pwd)
        {
            Employee e = db.SingleOrDefault(i => i.Uname==uname&&i.Pwd==pwd);
            return e;
        }
    }
}