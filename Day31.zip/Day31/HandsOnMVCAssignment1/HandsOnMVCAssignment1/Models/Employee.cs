﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace HandsOnMVCAssignment1.Models
{
    public class Employee
    {
        public int Eid { get; set; }
        public string Ename { get; set; }
        [DataType(DataType.Date)]
        public DateTime JoinDate { get; set; }
        public string Desig { get; set; }
        public decimal Salary { get; set; }
        public string Uname { get; set; }
        public string Pwd { get; set; }
        public string Role { get; set; }
    }
}