﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
namespace HandsOnMVCUsingModelValidation.Models
{
    public class Employee
    {
        [Required(ErrorMessage="Employee name required")]
        [DisplayName("Employee Name")]
        [StringLength(10,ErrorMessage="Name should be 10 char long only")]
        public string Ename { get; set; }
        [EmailAddress(ErrorMessage="Invalid Email")]
        public string Email { get; set; }
        [RegularExpression(@"[789]\d{9}",ErrorMessage="Invalid MobileNo")]
        public string Mobile { get; set; }
        [DataType(DataType.Date)]
        public DateTime JoinDate { get; set; }
        public string Desig { get; set; }
        [Range(12000,50000,ErrorMessage="Salary between 12 to 500000")]
        public decimal Salary { get; set; }
        [Required(ErrorMessage="Username Requierd")]
        public string Uname { get; set; }
        [Required(ErrorMessage="Password is Required")]
        [DisplayName("Password")]
        [DataType(DataType.Password)]
        [RegularExpression("[a-zA-Z0-9]{6,8}",ErrorMessage="Password should be 6 to 8 alphanumerics")]
        public string Pwd { get; set; }
        [DataType(DataType.Password)]
        [Compare("Pwd",ErrorMessage="Password Mismatch")]
        public string Cpwd { get; set; }
        
    }
}