﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnStrings
{
    class Demo8
    {
        static void Main()
        {
            //string s = null;
            //if(s==null)
            //{
            //}
            string s = "     Good Morning User";
            Console.WriteLine(s.Trim());
        }
    }
}
