﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnStrings
{
    class Demo4
    {
        static void Main()
        {
            //string s = "Good Morning User";
            //Console.WriteLine(s.ToUpper());
            //Console.WriteLine(s.ToLower());
            string[] email = { "gmail.com", "yahoo.com", "yahoo.co.in", "msn.in", "msn.com" };
            foreach (string s in email)
            {
                if (s.EndsWith(".com"))
                {
                    Console.WriteLine(s);
                }
            }
            Console.WriteLine();
            foreach (string s in email)
            {
                if (s.StartsWith("msn"))
                {
                    Console.WriteLine(s);
                }
            }
        }
    }
}
