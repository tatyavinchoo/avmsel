﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnStrings
{
    class Demo5
    {
        static void Main()
        {
            string str = "C#.net,Vb.net Asp.net";
            string[] s = str.Split(',',' ');
            foreach (string k in s)
                Console.WriteLine(k);
            Console.Clear();
            Console.WriteLine("Enter your MailId");
            string email = Console.ReadLine();
            string[] sp = email.Split('@');
            Console.WriteLine("Username " + sp[0]);

        }
    }
}
