﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnStrings
{
    class Demo9
    {
        static void Main()
        {
            string s = "GoodMorning";
            s = "GoodMorning Users";
            s=s.ToUpper();
            Console.WriteLine(s);
        }
    }
}
