﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnStrings
{
    class Demo2
    {
        static void Main()
        {
            //string s = "Hello";
            //string s1 = s;
            //s = "Hello User";
            //Console.WriteLine(s1);
            //string s2 = string.Copy(s);

            string fname = "Rahul";
            string lname = "Dravid";
            string fullname = fname + " " + lname;
            Console.WriteLine(fullname);
            fullname = string.Concat(fname," ", lname);
            Console.WriteLine(fullname);

        }
    }
}
