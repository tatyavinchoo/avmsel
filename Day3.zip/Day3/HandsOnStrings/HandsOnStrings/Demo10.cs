﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnStrings
{
    class Demo10
    {
        static void Main()
        {
            string str = "GoodMorning User";
            //char[] ch = str.ToCharArray();
            //foreach (char c in ch)
            //    Console.WriteLine(c);
            //string s = str.Replace('o', '0');
            //Console.WriteLine(s);
            //s = str.Replace("GoodMorning", "GoodEvening");
            //Console.WriteLine(s);
            double price = 1200;
            Console.WriteLine(string.Format("{0:C}",price));
            Console.WriteLine(DateTime.Now);//current system date and time
            Console.WriteLine(string.Format("{0:D}",System.DateTime.Now));
            Console.WriteLine(string.Format("{0:d}", System.DateTime.Now));
            Console.WriteLine(string.Format("{0:T}", System.DateTime.Now));
            Console.WriteLine(string.Format("{0:t}", System.DateTime.Now));
            Console.WriteLine(string.Format("{0:F2}", 123.4509454590));
        }
    }
}
