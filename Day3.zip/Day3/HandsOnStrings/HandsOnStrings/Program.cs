﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnStrings
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = "Welcome User";
            string path="D:\\Material\\C#\\Day2\\Strings";
            Console.WriteLine(path);
            string path1=@"D:\Downloads\Material\C#\Strings";
            string s = ".Net is a Product of Micorosoft " + "\n" +
                "It some up with Diff versions";
            string s1 = @".Net is a Product of Micorosoft  
                It come up with Diff versions";
            Console.WriteLine(s);
            Console.WriteLine(s1);
            Console.WriteLine(str[1]);//e
            Console.WriteLine(str.Length);

        }
    }
}
