﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnStrings
{
    class Demo6
    {
        static void Main()
        {
            string[] str = { "I", "Am", "Indian" };
            string s = string.Join(" ", str);
            Console.WriteLine(s);
        }
    }
}
