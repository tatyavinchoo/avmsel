﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnStrings
{
    class Demo11
    {
        static void Main()
        {
            //StringBuilder obj = new StringBuilder("GoodMorning");
            //obj.Append(" Users");
            //Console.WriteLine(obj);
            //string s = "GoodMorning Users";
            //obj.Replace("GoodMorning", "GoodEvening");
            //s.Replace("GoodMorning", "GoodEvening");
            //Console.WriteLine(obj);
            //Console.WriteLine(s);
            //Console.WriteLine(obj[3]);
            StringBuilder s = new StringBuilder("Users");
            s.Insert(0, "GoodMorning ");
            Console.WriteLine(s);
        }
    }
}
