﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnStrings
{
    class Demo1
    {
        static void Main()
        {
            Console.WriteLine("Ennter name");
            string name = Console.ReadLine();
            Console.WriteLine("Re Enter name");
            string rname = Console.ReadLine();
            //if (name == rname)
            //{
            //    Console.WriteLine("success");
            //}
            //else
            //{
            //    Console.WriteLine("Mismatch");
            //}
            //if (string.Compare(name, rname,true) == 0)
            //{
            //    Console.WriteLine("Equal");
            //}
            //else
            //    Console.WriteLine("Not Equal");
            if (name.Equals(rname,StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine("Equal");
            }
            else
                Console.WriteLine("Not Equal");
                    
        }
    }
}
