﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnStrings
{
    class Demo7
    {
        static void Main()
        {
            string s = "Hello User GoodMorning";
            //string s1 = s.Substring(0);
            //Console.WriteLine(s1);
            //string s2 = s.Substring(6, 4);
            //Console.WriteLine(s2);
            string s1 = s.Remove(11);
            Console.WriteLine(s1);
            string s2 = s.Remove(11, 4);
            Console.WriteLine(s2);
        }
    }
}
