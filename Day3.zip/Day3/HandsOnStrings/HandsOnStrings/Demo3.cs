﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnStrings
{
    class Demo3
    {
        static void Main()
        {
            string s = "GoodMorning User";
            Console.WriteLine(s.IndexOf('o'));
            Console.WriteLine(s.LastIndexOf('o'));
            Console.WriteLine(s.IndexOf("User"));
            string s1 = null;
            string s2 = string.Empty;
            string s3 = "";
            foreach (char ch in s)
            {
                Console.WriteLine(Convert.ToInt32(ch));
            }
        }
        
    }
}
