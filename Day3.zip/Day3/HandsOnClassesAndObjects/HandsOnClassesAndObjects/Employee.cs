﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnClassesAndObjects
{
    class Employee
    {
        //instance datamembers(variable)
        public int Eid;
        public string Ename;
        public double Salary;
        public DateTime JoinDate;
        //static varialbes
        public static string Organisation;
        public static string DomainName;
        //const variables
        public const double Bonous = 5000;
        public void Show()
        {
            Console.WriteLine("Id " + Eid);
            Console.WriteLine("Name " + Ename);
            Console.WriteLine("Salary " + Salary);
            Console.WriteLine("Bonous " + Bonous);
            Console.WriteLine("JoinDate " + string.Format("{0:d}", JoinDate));
            Console.WriteLine("Orgnaisation " + Organisation);
            Console.WriteLine("DomainName " + DomainName);
           
        }

    }
    class Test_Employee
    {
        static void Main()
        {
            Employee.Organisation = "CTS";
            Employee.DomainName = "Health Care";
            Employee e1 = new Employee();
            e1.Eid = 1;
            e1.Ename = "David";
            e1.Salary = 23000;
            e1.JoinDate = DateTime.Parse("12.2.2017");
            e1.Show();
            Console.WriteLine();
            Employee e2 = new Employee();
            e2.Ename = "Jeson";
            e2.Eid = 2;
            e2.Salary = 34000;
            e2.JoinDate = DateTime.Parse("12.3.2014");
            e2.Show();
            Employee.Organisation = "HCL";
            Employee e3 = new Employee();
            e3.Ename = "Jeson";
            e3.Eid = 3;
            e3.Salary = 34000;
            e3.JoinDate = DateTime.Parse("12.3.2014");
            e3.Show();
            Employee e4 = new Employee() { Eid = 5, 
                Ename = "Charan", Salary = 12000, 
                JoinDate = DateTime.Now }; //Object Initializer
        }
    }
}
