﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnClassesAndObjects
{
    class Student
    {
        //datamembers
       public int SId;
        public string Sname;
        public int Age;
        public string Address;
        public void Details()
        {
            Console.WriteLine("ID " + SId);
            Console.WriteLine("Name " + Sname);
            Console.WriteLine("Age " + Age);
            Console.WriteLine("Address " + Address);
        }
        static void Main()
        {
            //Instantiate Object
            Student s = new Student();
            s.SId = 1000;
            s.Sname = "Rohan";
            s.Age = 10;
            s.Address = "Chennai";
            s.Details();
        }
    }
}
