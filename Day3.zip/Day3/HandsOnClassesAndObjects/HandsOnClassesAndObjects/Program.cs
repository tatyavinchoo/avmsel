﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnClassesAndObjects
{
    class Program
    {
        static void Main(string[] args)
        {
            Student s1 = new Student();
            s1.SId = 101;
            s1.Sname = "Suren";
            s1.Age = 12;
            s1.Address = "Banglore";
            s1.Details();
            Console.WriteLine();
            Student s2 = new Student();
            s2.SId = 102;
            s2.Sname = "Rajan";
            s2.Age = 10;
            s2.Address = "Hyderabad";
            s2.Details();
            Console.WriteLine();
            Student s3 = new Student();
            s3.Details();
            Student s4 = null;
            s4.Details();
            Object obj = new Student();
           
        }
    }
}
