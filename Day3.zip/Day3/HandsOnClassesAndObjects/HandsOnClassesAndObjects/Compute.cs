﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnClassesAndObjects
{
    class Compute
    {
        public int Result;
        public void Add(int a, int b)
        {
            int c;
            c = a + b;
            Result = c;
        }
        public string Greet(string name)
        {
            return "Hello " + name;
        }
    }
    class Test_Compute
    {
        static void Main()
        {
            Compute obj = new Compute();
            obj.Add(12, 23);
            Console.WriteLine(obj.Result);
            string msg = obj.Greet("Sachin");
            Console.WriteLine(msg);
        }
    }
}
