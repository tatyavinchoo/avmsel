﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Ex1
    {
        public string GreetName(string name)
        {
            return "Hello " + name;
        }
    }
}
