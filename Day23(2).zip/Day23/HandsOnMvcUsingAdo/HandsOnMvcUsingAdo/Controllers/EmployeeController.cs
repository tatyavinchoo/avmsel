﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HandsOnMvcUsingAdo.Models;
namespace HandsOnMvcUsingAdo.Controllers
{
    public class EmployeeController : Controller
    {
        //
        // GET: /Employee/

        [ActionName("GetAll")]
        public ActionResult Index()
        {
            EmployeeDAO db = new EmployeeDAO();
           List<Employee> list =db.GetEmployees();
            return View(list);
        }
        public ViewResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(FormCollection obj)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    EmployeeDAO db = new EmployeeDAO();
                    int eid = db.Validate(obj["Uname"], obj["Pwd"]); //validating employee
                    if (eid != 0)
                    {
                        Employee e = db.GetEmpById(eid);//return employee using id
                        return RedirectToAction("Details", e);
                    }
                    else
                    {
                        TempData["err"] = "Invalid Login Details";
                        return View();
                    }
                }
                catch(Exception ex)
                {
                    TempData["err"] = ex.Message;
                    return View();
                }
            }
            else
                return View();
        }
        public ViewResult Details(Employee e)
        {
            return View(e);
        }

    }
}
