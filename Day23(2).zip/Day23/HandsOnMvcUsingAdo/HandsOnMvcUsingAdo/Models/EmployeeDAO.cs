﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
namespace HandsOnMvcUsingAdo.Models
{
    public class EmployeeDAO
    {
        public List<Employee> GetEmployees()
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-TAT6UMB\Parsi;Initial Catalog=CTSDB;Integrated Security=True"))
            {
                SqlCommand cmd = new SqlCommand(@"Select * from Employee", con);
                con.Open();//open Connection
                SqlDataReader dr=cmd.ExecuteReader();
                List<Employee> list=null;
               if(dr.HasRows)
               {
                   list=new List<Employee>();
                   while(dr.Read())
                   {
                       Employee eobj = new Employee()
                       {
                           Eid=(int)dr["Eid"],
                           Ename=dr["Ename"].ToString(),
                           Desig=dr["Desig"].ToString(),
                           Salary=(int)dr["Salary"],
                           JoinDate=Convert.ToDateTime(dr["JoinDate"]),
                           Did=dr["Did"].ToString()
                       };
                       list.Add(eobj);//Adding eobj to list
                   }
               }
               return list;
            }
        }
        public int Validate(string uname,string pwd) //Validate employee login
        {
            using(SqlConnection con=new SqlConnection(@"Data Source=DESKTOP-TAT6UMB\Parsi;Initial Catalog=CTSDB;Integrated Security=True"))
            {
                SqlCommand cmd=new SqlCommand("Select Eid from Login where uname='"+uname+"' and pwd='"+pwd+"'",con);
                con.Open();
               int eid=Convert.ToInt32(cmd.ExecuteScalar());
               con.Close();
               return eid;
            }
        }
        public Employee GetEmpById(int id)
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-TAT6UMB\Parsi;Initial Catalog=CTSDB;Integrated Security=True"))
            {
                SqlCommand cmd = new SqlCommand("Select * from Employee where Eid="+id, con);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                Employee e = null;
                if(dr.HasRows)
                {
                    dr.Read();
                    e = new Employee()
                    {
                        Eid = (int)dr["Eid"],
                        Ename = dr["Ename"].ToString(),
                        Desig = dr["Desig"].ToString(),
                        Salary = (int)dr["Salary"],
                        JoinDate = Convert.ToDateTime(dr["JoinDate"]),
                        Did = dr["Did"].ToString()
                    };
                }
                con.Close();
                return e;
               
            }
        }
    }
}