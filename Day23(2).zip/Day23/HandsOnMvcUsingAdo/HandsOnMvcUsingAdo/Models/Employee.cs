﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HandsOnMvcUsingAdo.Models
{
    public class Employee
    {
        public int Eid { get; set; }
        public string Ename { get; set; }
        public string Desig { get; set; }
        public DateTime JoinDate { get; set; }
        public int Salary { get; set; }
        public string Did { get; set; }
    }
}