﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
namespace HandsOnMvcUsingAdo.Models
{
    public class Login
    {
        [Required(ErrorMessage="Username is Required")]
        [DisplayName("Username")]
        public string Uname { get; set; }
        [Required(ErrorMessage="Password is Required")]
        [DisplayName("Password")]
        [DataType(DataType.Password)]
        public string Pwd { get; set; }
        public int Eid { get; set; }
    }
}