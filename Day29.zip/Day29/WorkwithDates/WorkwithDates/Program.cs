﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkwithDates
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime d = DateTime.Now;//system dateandtime
            Console.WriteLine(d);
            Console.WriteLine(d.ToShortDateString());
            Console.WriteLine(d.ToLongDateString());
            Console.WriteLine(d.ToShortTimeString());
            Console.WriteLine(d.ToLongTimeString());
            Console.WriteLine(d.Year);
            Console.WriteLine(d.Month);
            Console.WriteLine(d.Day);
            DateTime d1 = DateTime.Parse("12.2.2017");
            Console.WriteLine(d1);
            int year = d.Year - d1.Year;
            int month = d.Month - d1.Month;
            Console.WriteLine(year);
            Console.WriteLine(month);
            TimeSpan t = d - d1;
            Console.WriteLine("Days: " + t.Days);
            Console.ReadKey();
        }
    }
}
