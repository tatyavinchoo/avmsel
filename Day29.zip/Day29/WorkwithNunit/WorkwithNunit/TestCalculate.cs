﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
namespace WorkwithNunit
{
    [TestFixture]
    class TestCalculate
    {
        [Test]
        public void TestAdd()
        {
            Calculate obj = new Calculate();
            int actual = obj.Add(10, 20);
            int expected = 30;
            Assert.AreEqual(expected, actual);
        }
        [Test]
        public void GreetTest()
        {
            Calculate obj = new Calculate();
            string actual = obj.Greet("Rohan");
            Assert.IsNotNullOrEmpty(actual);
        }
        [Test]
        public void TestMax()
        {
            Calculate obj = new Calculate();
            bool b = obj.Max(12, 15);
            Assert.IsTrue(b);
        }
    }
}
