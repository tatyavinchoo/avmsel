﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkwithNunit
{
    class Calculate
    {
        public int Add(int a,int b)
        {
            return a + b;
        }
        public string Greet(string name)
        {
            return "Hello " + name;
        }
        public bool Max(int a,int b)
        {
            if (a > b)
                return true;
            else
                return false;
        }
    }
}
