﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
namespace WorkwithNunit
{
    [TestFixture]
    class TestProductRep
    {
        [Test]
       public void TestGetListByPrice()
        {
            ProductRep obj = new ProductRep();
            List<Product> list = obj.GetListByPrice(6400);
            int count = list.Count;
            Assert.Greater(count, 0);
        }
        [Test]
        public void TestGetProductById()
        {
            ProductRep obj = new ProductRep();
            Product p= obj.GetProductById(10);
            Assert.IsNotNull(p);

        }
    }
}
