﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkwithNunit
{
    class ProductRep
    {
        public List<Product> list = new List<Product>()
            {
                new Product(){Pid=1,Pname="Mouse",Price=200},
                new Product(){Pid=2,Pname="Keyboard",Price=500},
                new Product(){Pid=3,Pname="Bottle",Price=4200},
                new Product(){Pid=4,Pname="Watch",Price=1200},
                new Product(){Pid=5,Pname="Chain",Price=2300},
            };

        public List<Product> GetListByPrice(int price)
        {
            List<Product> l = list.Where(i => i.Price > price).ToList();
            return l;
        }
        public Product GetProductById(int id)
        {
            Product p = list.SingleOrDefault(i => i.Pid == id);
            return p;
        }
    }
}
