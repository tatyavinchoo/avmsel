﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace FXCalculation
{
    public class Program
    {
        
        static void Main(string[] args)
        {            
         
            FXCalculator fxcalculatorobj = new FXCalculator();
            fxcalculatorobj.ProcessData(@"D:\DotnetAssessment\FXCalculation\Input file\", "TradeOrders_032013.txt",
                @"D:\DotnetAssessment\FXCalculation\ErrorLog\", "InvalidRecords_032013.txt", @"D:\DotnetAssessment\FXCalculation\Archive\", "TradeOrders_032013_Processed.txt");

           /*
           * Pass the file path, file names and connection string in this method alone. 
           * Do not hardcode in any other methods
           */ 
        }
    }
}
