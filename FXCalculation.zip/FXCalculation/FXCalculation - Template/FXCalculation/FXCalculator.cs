﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;
using System.Data.SqlClient;
using System.Globalization;

/*
        * Do not remove the attached FXCalculationTestProject. It is meant for auto evaluation of your source code.
        * Do not attach any test classess to the attached test project.
        * Do not attach any new test projects.
        * You are supposed to write only the code. You are not required to write any automated test cases.
        * * Connection Object is created in  Connection Factory Method .Make Use of It.Don't Create new Object(new sqlconnection()).
        */
namespace FXCalculation
{
    public class FXCalculator
    {
        SqlConnection Connectionstring = ConnectionFactory.GetConnection();

        public void ProcessData(string sourceFolder, string fileName, string errorLogFilePath, string errorLogFileName, string archiveFilePath, string archiveFileName)
        {


            
            List<Trade> trades = new List<Trade>();

            //Do your logic here

            CopyToArchive(sourceFolder + fileName, archiveFilePath + archiveFileName);

        }

        public List<Trade> ReadAllDataFromInputFile(string sourceFolder, string fileName)
        {
            List<Trade> trades = new List<Trade>();
            FileInfo fileIn = new FileInfo(sourceFolder + fileName);
            try
            {
                //Do your logic to read file and storing it into list of trades ..here..
                //Do not hardcode the filename and the file path here
               
            }
            catch (Exception)
            {
                throw new FXCalculatorException();
            }
            return trades;
        }
        public List<Trade> PickValidTradeDetails(List<Trade> trades, string errorLogFilePath, string errorLogFileName)
        {
            // Step 1 : filter the valid trades and invalid trades, save the invalid
            //List<Trade> validTrades = null; //identify all the valid trades and assign.
            //Do not hardcode the filename and the file path here

            // SaveInvalidRecordsToLogFile(List<Trades>); // pass all the invalid trades to log...

            int numericValue;
            DateTime tradeDate;
            DateTime maturityDate;
            List<Trade> validTrades = new List<Trade>();
            List<Trade> inValidTrades = new List<Trade>();

            foreach (var trade in trades)
            {
               if (!DateTime.TryParseExact(trade.TradeDate, "MM/dd/yyyy", CultureInfo.InvariantCulture,
                       DateTimeStyles.None, out tradeDate))
                {
                    inValidTrades.Add(trade);
                }

              else if (string.IsNullOrEmpty(trade.Currency.ToString()) || (!(trade.Currency.Length==3)))
                {
                    inValidTrades.Add(trade);
                }                        
                
               //Do the coding here for trade Validation

                else
                {
                    //Add to valid list
                    validTrades.Add(trade);
                }

            }            
            SaveInvalidRecordsToLogFile(inValidTrades, errorLogFilePath, errorLogFileName);
            return validTrades;
        }
        public bool SaveInvalidRecordsToLogFile(List<Trade> invalidTrades, string errorLogFilePath, string errorLogFileName)
        {

            //The solution for the method is available. Implement NUnit test case for the method
            
            List<FXRate> fxrates = new List<FXRate>();
            double calculatedFXRate = 0;
            double appliedFXRate = 0;
            SqlCommand cmd = Connectionstring.CreateCommand();
            cmd.CommandText = "SELECT TradeId,Currency,Amount,TradeType FROM SBA.Trade_Details";
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            builder.DataAdapter = adapter;
            DataTable data = new DataTable();
            adapter.Fill(data);
            Connectionstring.Close();
            foreach (DataRow dr in data.Rows)
            {
                if (dr["TradeType"].ToString() == "FX")
                {
                    if (dr["Currency"].ToString() == "USD")
                    {
                        appliedFXRate = 0.5;
                        calculatedFXRate = Convert.ToInt32(dr["Amount"]) * appliedFXRate;
                    }
                    else if (dr["Currency"].ToString() == "GBP")
                    {
                        appliedFXRate = 0.6;
                        calculatedFXRate = Convert.ToInt32(dr["Amount"]) * appliedFXRate;
                    }
                    else if (dr["Currency"].ToString() == "EUR")
                    {
                        appliedFXRate = 0.7;
                        calculatedFXRate = Convert.ToInt32(dr["Amount"]) * appliedFXRate;
                    }
                    else if (dr["Currency"].ToString() == "INR")
                    {
                        appliedFXRate = 1;
                        calculatedFXRate = Convert.ToInt32(dr["Amount"]) * appliedFXRate;
                    }

                    fxrates.Add(new FXRate()
                    {
                        TradeId = Convert.ToString(dr[0]),
                        Currency = Convert.ToString(dr[1]),
                        Amount = Convert.ToString(dr[2]),
                        CalculatedFXRate = Convert.ToString(calculatedFXRate),
                        AppliedFXRate = Convert.ToString(appliedFXRate)
                    });
                }

            }
            return true;
        }

        public bool SaveValidRecordsToDB(List<Trade> trades)
        {
            //Do your logic here to upload to DB table                
           
            return true;
        }

        public List<FXRate> CalculateFXRate()
        {
            // Do your logic here to calculate FXRate
            List<FXRate> fxrates = new List<FXRate>();
            double calculatedFXRate = 0;
            double appliedFXRate = 0;
            Connectionstring.Open();
            SqlCommand cmd = Connectionstring.CreateCommand();
            cmd.CommandText = "SELECT TradeId,Currency,Amount,TradeType FROM SBA.Trade_Details";
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            builder.DataAdapter = adapter;
            DataTable data = new DataTable();
            adapter.Fill(data);
            Connectionstring.Close();

            //Perform your calculation here
            
            return fxrates;
        }

        public bool SaveFXRate(List<FXRate> fxRates)
        {
            //The solution for the method is available. Implement NUnit test case for the method

            foreach (var fxrate in fxRates)
            {
                SqlCommand command = new SqlCommand("Insert into SBA.FX_Rate values (@TradeId,@Currency,@Amount,@AppliedFXRate,@CalculatedFXRate)", Connectionstring);
                command.Parameters.Add(new SqlParameter("@TradeId", (fxrate.TradeId)));
                command.Parameters.Add(new SqlParameter("@Currency", fxrate.Currency));
                command.Parameters.Add(new SqlParameter("@Amount", Convert.ToInt16(fxrate.Amount)));
                command.Parameters.Add(new SqlParameter("@AppliedFXRate", Convert.ToDecimal(fxrate.AppliedFXRate)));
                command.Parameters.Add(new SqlParameter("@CalculatedFXRate", Convert.ToDecimal(fxrate.CalculatedFXRate)));
                Connectionstring.Open();
                command.ExecuteNonQuery();
                Connectionstring.Close();
            }
            return true;
        }

        public bool CopyToArchive(string sourcePathWithFileName, string targetPathWithFileName)
        {
            //The solution for the method is available. Implement NUnit test case for the method

            return true;
        }
    }
}
