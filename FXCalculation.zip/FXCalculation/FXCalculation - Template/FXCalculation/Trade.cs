﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FXCalculation
{
    public class Trade
    {
        /*
         * Do not modify the return types of the below properties
         */
        public string TradeId { get; set; }
        public string Isin { get; set; }
        public string TradeDate { get; set; }
        public string MaturityDate { get; set; }
        public string SchemeName { get; set; }
        public string TradeType { get; set; }
        public string Currency { get; set; }
        public string Amount { get; set; }      
    }
}
