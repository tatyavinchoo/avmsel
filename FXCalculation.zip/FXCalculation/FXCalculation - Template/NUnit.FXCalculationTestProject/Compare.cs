﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FXCalculation;



namespace FXCalculation
{
    public class Compare : IEqualityComparer<Trade>
    {

        public bool compareMethod(List<Trade> abc, List<Trade> def)
        {
            bool areEqual = abc.SequenceEqual(def, new Compare());
            if (areEqual == true)
                return true;
            else
                return false;
        }

        public bool Equals(Trade x, Trade y)
        {
            if (x.TradeId == y.TradeId
                && x.Isin == y.Isin
                && x.TradeDate == y.TradeDate
                && x.MaturityDate == y.MaturityDate
                && x.SchemeName == y.SchemeName
                && x.TradeType == y.TradeType
                && x.Currency == y.Currency
                && x.Amount == y.Amount)
                return true;
            else
                return false;
        }

        public int GetHashCode(Trade obj)
        {
            return obj.TradeId.GetHashCode();

        }
    }

    public class CompareFXRate : IEqualityComparer<FXRate>
    {

        public bool compareMethod(List<FXRate> abc, List<FXRate> def)
        {
            bool areEqual = abc.SequenceEqual(def, new CompareFXRate());
            if (areEqual == true)
                return true;
            else
                return false;
        }

        public bool Equals(FXRate x, FXRate y)
        {
            if (x.TradeId == y.TradeId                
                && x.Currency == y.Currency
                && x.Amount == y.Amount
                && x.AppliedFXRate == y.AppliedFXRate
                && x.CalculatedFXRate == y.CalculatedFXRate
                )
                return true;
            else
                return false;
        }

        public int GetHashCode(FXRate obj)
        {
            return obj.TradeId.GetHashCode();

        }
    }
}
