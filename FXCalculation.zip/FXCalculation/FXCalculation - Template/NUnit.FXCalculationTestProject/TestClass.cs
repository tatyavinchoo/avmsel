﻿using NUnit.Framework;
using FXCalculation;
using System;
using System.Collections.Generic;
using System.IO;
using System.Data.SqlClient;
using System.Data;

namespace NUnit.FXCalculationTestProject
{
    [TestFixture]
    public class Nunit_FXCalculatorTest
    {
        SqlConnection sqlConnectionString = ConnectionFactory.GetConnection();      

        string errorLogFilePath = @"D:\DotnetAssessment\FXCalculation\ErrorLog\";      
        string sourcePathWithFileName = @"D:\DotnetAssessment\FXCalculation\Input file\TradeOrders_032013.txt"; // TODO: Initialize to an appropriate value
        string targetPathWithFileName = @"D:\DotnetAssessment\FXCalculation\Archive\TraeDetails_032013_Processed.txt"; // TODO: Initialize to an appropriate value            
        string backupPathWithFileName = @"D:\DotnetAssessment\FXCalculation\Backup\TradeOrders_032013.txt";
        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }
        //Implement your test case here.

        // <summary>
        //A test for SaveFXRate
        //</summary>
        [Test]
        public void SaveFXRateTest_FC()
        {
            //Implement your logic here
        }     


        // <summary>
        //A test for SaveInvalidRecordsToLogFile
        //</summary>
        [Test]
        public void SaveInvalidRecordsToLogFileTest_FC()
        {
            //Implement your logic here
        }

        //<summary>
        //A test for CopyToArchive
        //</summary>
        [Test]
        public void CopyToArchiveTest_FC()
        {
           //Implement your logic here
        }

        //Helper methods
        //Use Helper methods if applicable
        public List<FXRate> GetSavedValuesFromFXRateTable()
        {
            List<FXRate> fxrates = new List<FXRate>();
            DataTable datatable = new DataTable();

            SqlCommand command = new SqlCommand("Select TradeId,Currency,Amount,AppliedFXRate,CalculatedFXRate from SBA.FX_Rate", sqlConnectionString);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            sqlConnectionString.Open();
            adapter.Fill(datatable);
            sqlConnectionString.Close();

            foreach (DataRow dr in datatable.Rows)
            {
                fxrates.Add(new FXRate()
                {
                    TradeId = Convert.ToString(dr[0]),
                    Currency = Convert.ToString(dr[1]),
                    Amount = Convert.ToString(dr[2]),
                    AppliedFXRate = Convert.ToString(dr[3]),
                    CalculatedFXRate = Convert.ToString(dr[4])
                });
            }
            return fxrates;
        }

        //DeleteSavedValuesFromDB
        public bool DeleteSavedValuesFromDB(List<Trade> trades)
        {

            //Do your logic here to upload to DB table
            foreach (var trade in trades)
            {
                SqlCommand command = new SqlCommand("Delete from SBA.Trade_Details", sqlConnectionString);
                sqlConnectionString.Open();
                command.ExecuteNonQuery();
                sqlConnectionString.Close();
            }
            return true;
        }

        public void DeleteSavedValuesFromFXRate()
        {

            //Do your logic here to upload to DB table            
            SqlCommand command = new SqlCommand("Delete from SBA.FX_Rate", sqlConnectionString);
            sqlConnectionString.Open();
            command.ExecuteNonQuery();
            sqlConnectionString.Close();
        }

        public void DeleteSavedValuesFromTradeDetails()
        {

            //Do your logic here to upload to DB table            
            SqlCommand command = new SqlCommand("Delete from SBA.Trade_Details", sqlConnectionString);
            sqlConnectionString.Open();
            command.ExecuteNonQuery();
            sqlConnectionString.Close();

        }

    }
}
