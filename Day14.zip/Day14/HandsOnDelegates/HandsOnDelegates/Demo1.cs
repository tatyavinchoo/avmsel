﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnDelegates
{
    public delegate void delegate3(string name);
    class Demo1
    {
        public void Greet(string name)
        {
            Console.WriteLine("GoodMorning " + name);
        }
    }
    class Sample
    {
        public Sample(delegate3 d3)
        {
            d3("Rahul");
        }
        public Sample(delegate3 d3, string n)
        {
            d3(n);
        }
    }
    class Test_Sample
    {
        static void Main()
        {
            Demo1 d = new Demo1();
            Sample s1 = new Sample(d.Greet);
            Sample s2 = new Sample(d.Greet, "Sachin");
            Sample s3 = new Sample(delegate(string n)
                {
                    Console.WriteLine("Hello " + n);
                },"Suraj");
            Console.ReadKey();
        }
    }
}
