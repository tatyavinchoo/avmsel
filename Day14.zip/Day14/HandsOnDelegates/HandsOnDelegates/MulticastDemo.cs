﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnDelegates
{
    
    class MulticastDemo
    {
        public delegate void Calculate(int a, int b);
        public static void Add(int i, int j)
        {
            Console.WriteLine(i + j);
        }
        public static void Mul(int a, int b)
        {
            Console.WriteLine(a * b);
        }
        public static void Div(int l, int m)
        {
            int k = l / m;
            Console.WriteLine(k);
        }
        static void Main()
        {
            HandsOnDelegates.MulticastDemo.Calculate c = Add;
            //adding multiple method references
            c += Div;
            c += Mul;
            c(12, 2);
        }
        
    }
    public class Test
    {
        
    }
}
