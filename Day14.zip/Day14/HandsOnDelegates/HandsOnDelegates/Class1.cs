﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnDelegates
{
    class Class1
    {
        public static void Task1()
        {
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine(i);
            }
        }
        public static void Task2()
        {
            for (int i = 100; i <= 110; i++)
            {
                Console.WriteLine(i);
            }
        }
        static void Main()
        {
            Task1();
            Task2();
        }
    }
}
