﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnDelegates
{
    public delegate int delegate4(int i);
    class Demo4
    {
        public int cube(int i)
        {
            return i * i * i;
        }
        public void Doit(delegate4 d)
        {
            int a=d(8);
            Console.WriteLine(a);
        }
    }
    class Test_Demo4
    {
        static void Main()
        {
            Demo4 obj = new Demo4();
            delegate4 d4 = obj.cube;
            int k = d4(10);
            Console.WriteLine(k);
            obj.Doit(obj.cube);
            obj.Doit(delegate(int i)
            {
                k = i * i*i;
                return k;
            });
            obj.Doit(j => j * j * j);
            obj.Doit(m =>
            {
                int n = m * m * m;
                return n;
            });
            delegate4 dobj = i => i * i * i;
            Console.WriteLine(dobj(5));//125
         
        }
    }
}
