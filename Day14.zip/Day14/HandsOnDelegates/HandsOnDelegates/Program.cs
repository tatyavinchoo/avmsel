﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnDelegates
{
    //delegate declaration
    public delegate void delegate1();
    public delegate void delegate2(string name);
    class Program
    {
        public void f()
        {
            Console.WriteLine("GoodMornig Users...");
        }
        public void greet(string n)
        {
            Console.WriteLine("Hello " + n);
        }
        static void Main(string[] args)
        {
            Program obj = new Program();
            //instantiate delegate
            delegate1 d1 = new delegate1(obj.f);
            //calling delegate
            d1();
            d1.Invoke();
           
            delegate2 d2 = new delegate2(obj.greet);
            d2("Sachin");
            delegate2 d3 = obj.greet;//delegate infarence
            d3("Rahul");
            Console.ReadKey();
        }
    }
}
