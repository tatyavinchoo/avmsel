﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
namespace HandsOnExceptions.Models
{
    public class CustomHandelError:HandleErrorAttribute
    {
        public override void OnException(ExceptionContext filterContext)
        {
           using(StreamWriter sw=new StreamWriter("D:/errlog.txt",true))
           {
               Exception ex = filterContext.Exception;
               sw.WriteLine(ex.Message + "_" + DateTime.Now.ToShortDateString());
           }
        }
       
    }
}