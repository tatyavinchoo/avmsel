﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HandsOnExceptions.Controllers
{
   [HandleError(ExceptionType=typeof(Exception))]
    public class Demo1Controller : Controller
    {
        //
        // GET: /Demo1/

        [HandleError(ExceptionType=typeof(Exception))]
        public ActionResult Index()
        {
            int a = 10;
            int b = 0;
            int c = 0;
            c = a / b;
            return View();
        }
        public ActionResult Details()
        {
            return View();
        }
        public ActionResult Create()
        {
            return View();
        }

    }
}
