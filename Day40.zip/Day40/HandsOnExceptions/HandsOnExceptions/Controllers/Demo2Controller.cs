﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HandsOnExceptions.Models;
namespace HandsOnExceptions.Controllers
{
    public class Demo2Controller : Controller
    {
        //
        // GET: /Demo2/

       [CustomHandelError]
        public ActionResult Index()
        {
            int a = 10;
            int b = 0;
            int c = 0;
            c = a / b;
            return View();
           
        }

    }
}
