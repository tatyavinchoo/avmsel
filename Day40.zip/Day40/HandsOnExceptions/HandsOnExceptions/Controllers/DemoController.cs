﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HandsOnExceptions.Controllers
{
    public class DemoController : Controller
    {
        //
        // GET: /Demo/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Div()
        {
            try
            {
                int a = 10;
                int b = 0;
                int c = 0;
                c = a / b;
                return View();
            }
            catch(Exception)
            {
                //return View("Error");
                //passing error information to Error view template
                return View("Error", new HandleErrorInfo(new Exception("b value should not be 0"), "Demo", "Div"));
            }
            finally
            {

            }
        }
        protected override void OnException(ExceptionContext filterContext)
        {
            Exception ex = filterContext.Exception;
            var Result=View("Error",new HandleErrorInfo(ex,"",""));
            filterContext.Result = Result;
        }


    }
}
