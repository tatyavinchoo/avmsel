﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace HandsOnXML
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Read Xml file using Dataset
            DataSet ds = new DataSet();
            string path=@"D:\Dotnet\Day13\HandsOnXML\HandsOnXML\Emp.xml";
            ds.ReadXml(path);
            dataGridView1.DataSource = ds.Tables[0];
           

        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection("Data Source=PC232954;Initial Catalog=TrainingDB;User ID=sa;Password=password-1"))
            {
                try
                {
                    SqlDataAdapter da = new SqlDataAdapter("Select * from Employee order by salary desc", con);
                    DataSet ds = new DataSet();
                    da.Fill(ds,"Emp");
                    //store result set data into xml
                    ds.WriteXml(@"D:\emp.xml");
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }
    }
}
