﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using HandsOnMVCUisngCustomValidation.Models.CustomValidator;
namespace HandsOnMVCUisngCustomValidation.Models
{
    public class Customer
    {
        public int Cid { get; set; }
        public string Cname { get; set; }
        [CustomMobileValidator]
        public string Mobile { get; set; }
        [CustomDateValidator]
        public DateTime JoinDate { get; set; }
        [CustomVefifyDateValidator]
        public DateTime VerificationDate { get; set; }
    }
}