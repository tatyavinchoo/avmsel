﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using HandsOnMVCUisngCustomValidation.Models.CustomValidator;
namespace HandsOnMVCUisngCustomValidation.Models
{
    public class Book
    {
        [Required(ErrorMessage="ID is Required")]
        public int BId { get; set; }
        [StringLength(20)]
        public string Bname { get; set; }
        [CustomYearValidator]
        public int PublishYear
        {
            get;
            set;
        }
    }
}