﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;
namespace HandsOnMVCUisngCustomValidation.Models.CustomValidator
{
    public class CustomMobileValidator:ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value != null)
            {
                string mobile = value.ToString();
                if (Regex.IsMatch(mobile, @"^[789]\d{9}$"))
                {
                    return ValidationResult.Success;
                }
                else
                    return new ValidationResult("Pls Enter Valid Mobile no");
            }
            else
                return new  ValidationResult("Enter Mobile no");
        }
    }
}