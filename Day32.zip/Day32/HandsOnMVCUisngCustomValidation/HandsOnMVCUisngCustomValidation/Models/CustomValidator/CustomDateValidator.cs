﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace HandsOnMVCUisngCustomValidation.Models.CustomValidator
{
    public class CustomDateValidator:ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value != null)
            {
                DateTime d = (DateTime)value;
                if (d > DateTime.Now)
                {
                    return new ValidationResult("JoinDate should be grater than current date");
                }
                else
                    return ValidationResult.Success;
            }
            else
                return new ValidationResult("Pls Enter Join Date");
        }
    }
}