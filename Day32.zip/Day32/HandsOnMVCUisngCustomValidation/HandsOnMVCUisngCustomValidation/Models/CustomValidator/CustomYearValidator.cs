﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace HandsOnMVCUisngCustomValidation.Models.CustomValidator
{
    public class CustomYearValidator:ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value != null)
            {
                int year = (int)value;
                if(year<1992)
                {
                    return new ValidationResult("Publish year should not less than 1992");
                }
                else if (year > DateTime.Now.Year)
                {
                    return new ValidationResult("Publish Year should not grater than current year");
                }
                else
                {
                    return ValidationResult.Success;
                }
            }
            else
                return new ValidationResult("Please Enter Publishyear");
        }
    }
}