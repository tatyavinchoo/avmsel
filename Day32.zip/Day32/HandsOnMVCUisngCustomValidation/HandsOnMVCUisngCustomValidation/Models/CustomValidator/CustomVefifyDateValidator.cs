﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace HandsOnMVCUisngCustomValidation.Models.CustomValidator
{
    public class CustomVefifyDateValidator:ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value != null)
            {
                DateTime verificationDate = Convert.ToDateTime(value);
                Customer c = (Customer)validationContext.ObjectInstance;//returns current model(Customer) object
                if(verificationDate<c.JoinDate)
                {
                    return new ValidationResult("Verification Date should not less than joinDate");
                }
                else if(verificationDate>DateTime.Now)
                {
                    return new ValidationResult("Verification Date should not future date.");
                }
                else
                    return  ValidationResult.Success;
            }
            else
                return new ValidationResult("");
        }
    }
}