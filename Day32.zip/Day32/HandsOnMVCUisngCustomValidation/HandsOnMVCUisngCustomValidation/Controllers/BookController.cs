﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HandsOnMVCUisngCustomValidation.Models;
namespace HandsOnMVCUisngCustomValidation.Controllers
{
    public class BookController : Controller
    {
        //
        // GET: /Book/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(Book b)
        {
            if(ModelState.IsValid)
            {
                return RedirectToAction("Details");
            }
            else
            return View();
        }

    }
}
