﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HandsOnMVCUisngCustomValidation.Models;
namespace HandsOnMVCUisngCustomValidation.Controllers
{
    public class CustomerController : Controller
    {
        //
        // GET: /Customer/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(Customer b)
        {
            if (ModelState.IsValid)
            {
                return RedirectToAction("Details");
            }
            else
                return View();
        }

    }
}
