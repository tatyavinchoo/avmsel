﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace HandsOnAdoUsingStoreProcedures
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection("Data Source=PC232954;Initial Catalog=TrainingDB;User ID=sa;Password=password-1");
        SqlCommand cmd = null;
        public Form1()
        {
            InitializeComponent();
        }

        private void Search(object sender, EventArgs e)
        {
            //Serach Record
            try
            {
                cmd = new SqlCommand("GetbyId", con);
                cmd.CommandType = CommandType.StoredProcedure;
                //passing values to parameters
                cmd.Parameters.AddWithValue("@eid", txtId.Text);
               con.Open();
                SqlDataReader dr=cmd.ExecuteReader();
               
                if (dr.HasRows)
                {
                    dr.Read();//read record
                    txtName.Text = dr["Eid"].ToString();
                    txtdesig.Text = dr["designation"].ToString();
                    txtSalary.Text = dr["Salary"].ToString();
                    txtDid.Text = dr["Did"].ToString();
                    txtJoinDate.Text = dr["joindate"].ToString();

                }
                else
                    MessageBox.Show("Invalid Id");
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void Register(object sender, EventArgs e)
        {
            try
            {
                cmd = new SqlCommand("Insert_Emp", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@eid", txtId.Text);
                cmd.Parameters.AddWithValue("@ename", txtName.Text);
                cmd.Parameters.AddWithValue("@desig", txtdesig.Text);
                cmd.Parameters.AddWithValue("@salary", txtSalary.Text);
                cmd.Parameters.AddWithValue("@did", txtDid.Text);
                cmd.Parameters.AddWithValue("@joindate", txtJoinDate.Text);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Added");

            }
            catch (SqlException ex)
            {
            }
            finally
            {
                con.Close();
            }
        }
    }
}
