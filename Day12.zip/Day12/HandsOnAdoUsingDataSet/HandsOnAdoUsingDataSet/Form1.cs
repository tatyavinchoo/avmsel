﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace HandsOnAdoUsingDataSet
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection("Data Source=PC232954;Initial Catalog=TrainingDB;User ID=sa;password=password-1");
        SqlDataAdapter da = null;
        DataSet ds = null;
        int ridx = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Load_Click(object sender, EventArgs e)
        {
            try
            {
                da = new SqlDataAdapter("select * from employee", con);
                //instantiate ds object
                ds = new DataSet();
                //stord result set into ds table
                //da.Fill(ds);
                da.Fill(ds, "Emp"); //Emp is Datatable name
                FillRow(ridx);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void FillRow(int idx)
        {
            DataRow r = ds.Tables["Emp"].Rows[idx];
            txtId.Text = r["Eid"].ToString();
            txtName.Text = r["Ename"].ToString();
            txtDid.Text = r["Did"].ToString();
            txtdesig.Text = r["designation"].ToString();
            txtSalary.Text = r["Salary"].ToString();
            txtJoinDate.Text = r["JoinDate"].ToString();
        }

        private void Next(object sender, EventArgs e)
        {
            //Navigate to Next record
            if (ridx < ds.Tables[0].Rows.Count - 1)
            {
                ridx++;
                FillRow(ridx);
            }
        }

        private void Prev(object sender, EventArgs e)
        {
            //Navigate to Prev record
            if (ridx > 0)
            {
                ridx--;
                FillRow(ridx);
            }
        }
    }
}
