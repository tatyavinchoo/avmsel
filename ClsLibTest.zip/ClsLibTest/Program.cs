﻿using ClsLib;
namespace ClsLibTest
{
    [TestFixture]
    class Program
    {
        [Test]
        public void TestAdd()
        {
            Chingi ch = new Chingi();
            ch.Msg();
        }
    }
}
