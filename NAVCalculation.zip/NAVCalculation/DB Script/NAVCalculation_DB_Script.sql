Use master
go

IF  EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = 'DBNAVCalculation')
DROP DATABASE DBNAVCalculation
GO

CREATE DATABASE DBNAVCalculation
GO

Use DBNAVCalculation
GO
CREATE SCHEMA SBA
GO

CREATE TABLE SBA.NAV_Report (
FundId	varchar(4) Not null,
Assets	float,
Liabilities	float,
OutstandingShares	float,
NAV	float

)
GO

CREATE TABLE SBA.Fund_Details (
FundId	varchar(4) Not null,
SubFundId	varchar(5) ,
Assets	float,
Liabilities	float,
OutstandingShares	float
)

GO

