﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace NAVCalculation
{
    class Program
    {
        static void Main(string[] args)
        {
            SqlConnection connection = new SqlConnection(@"Data Source=PCName\\SQLEXPRESS;Initial Catalog=DBNAVCalculation;Integrated Security=True");
            NAVCalculator navCalculator = new NAVCalculator();
            navCalculator.ProcessData(@"D:\Dotnetcaassessment\NAVCalculation\Input File\", "All_Fund_Details.txt",
                connection, @"D:\Dotnetcaassessment\NAVCalculation\ErroLog\", "Invalid_Fund_Details.txt");
               /*
               * Pass the file path, file names and connection string if any in this method alone. 
               * Do not hardcode in any other methods
               */ 
        }
    }
}
