﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NAVCalculation
{
    public class NAVCalculatorException: Exception
    {
        public NAVCalculatorException () : base()
		{

		}

        public NAVCalculatorException(string message)
             : base(message)
		{

		}
    }
}
