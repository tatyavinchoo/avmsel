﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
/*
        * Do not remove the attached NAVCalculationTestProject. It is meant for auto evaluation of your source code.
        * Do not attach any test classess to the attached test project.
        * Do not attach any new test projects.
        * You are supposed to write only the code. You are not required to write any automated test cases.
        * Do not create the redundant connection Object for SqlConnection, use the conncetion Object (connection) given in the method parameter.
                */
namespace NAVCalculation
{
    public class NAVCalculator
    {

        public void ProcessData(string sourceFolder, string fileName, SqlConnection connection, string errorLogFilePath, string errorLogFileName )
        {
            //Do your logic here
            //Do not create the redundant connection Object for SqlConnection, use the conncetion Object(connection) given in the method parameter.

            //ReadAllDataFromInputFile

                //PickValidFundDetails --> SaveInvalidFundsToLogFile

                //SaveValidFundsToDatabase

                //GetPerFundDetails(validFunds);

                //CalculateNAVAndSaveToDatabase(validFunds);            

        }
        public List<Fund> ReadAllDataFromInputFile(string sourceFolder, string fileName)
        {   
            
            //return all the records from the input file in list

            //Do not hardcode the filename and the file path here
            return null;
        }
        public List<Fund> PickValidFundDetails(List<Fund> funds, string errorLogFilePath,string errorLogFileName)
        {
            //returm pmly valid funds
            List<Fund> validFunds = new List<Fund>();

            //Do not hardcode the filename and the file path here

            //Save the invalid funds to error log file
            List<Fund> invalidFunds = new List<Fund>();
            this.SaveInvalidFundsToLogFile(invalidFunds,errorLogFilePath,errorLogFileName);

            return validFunds;            
        }
        public void SaveInvalidFundsToLogFile(List<Fund> invalidFunds, string errorLogFilePath, string errorLogFileName)
        {
            //Do your logic here to save the invalid funds to error log file

            //Do not hardcode the filename and the file path here
        }
        public void SaveValidFundsToDatabase(List<Fund> validFunds, SqlConnection connection)
        {
            //Do your logic here to save the valid funds to database
            //Do not hardcode the connection string here
            //Do not Prefix Database name in the SQL Query. Query should be "Insert into SBA.TableName"
            //Should not be "Insert into DatabaseName.SBA.TableName"
            //Do not create the redundant connection Object for SqlConnection, use the conncetion Object(connection) given in the method parameter.
        }
        public List<Fund> GetPerFundDetails(List<Fund> funds)
        {            
            //get the per fund details from the valid funds list
            //Do not Prefix Database name in the SQL Query. Query should be "Insert into SBA.TableName"
            //Should not be "Insert into DatabaseName.SBA.TableName"
            return null;
        }        
        public void CalculateNAVAndSaveToDatabase(List<Fund> perFunds,SqlConnection connection)
        {
            //Do your logic here to calculate the NAV and to save it to database
            //Do not hardcode the connection string here
            //Do not Prefix Database name in the SQL Query. Query should be "Insert into SBA.TableName"
            //Should not be "Insert into DatabaseName.SBA.TableName"
            //Do not create the redundant connection Object for SqlConnection, use the conncetion Object(connection) given in the method parameter.

        }
    }
}
