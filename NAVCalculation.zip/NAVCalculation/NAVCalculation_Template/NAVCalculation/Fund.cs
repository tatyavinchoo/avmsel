﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NAVCalculation
{
    //Do not change this class
    public class Fund
    {
        /*
         * Do not modify the return types of the below properties
         */
        public string FundId { get; set; }
        public string SubFundId { get; set; }
        public string Asset { get; set; }
        public string Liability { get; set; }
        public string OutstandingShares { get; set; }
        public string NAV { get; set; }      

        //Do not add new constructors
    }
}
