﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace HandsOnCollections
{
    class HashTableDemo
    {
        static void Main()
        {
           // Hashtable obj = new Hashtable();
            SortedList obj = new SortedList();
            obj.Add(1029, "Rohan");
            obj.Add(1020, "Suren");
            obj.Add(1100, "Monica");
            obj.Add(1230, "Karan");
            obj.Add(1103, "Sachin");
            //obj.Add('a', "America");
            Console.WriteLine(obj[1020]);
            //fech all the key-values
            foreach (object k in obj.Keys)
            {
                Console.WriteLine("{0} {1}", k, obj[k]);
            }
            Console.WriteLine();
            foreach (DictionaryEntry d in obj)
            {
                Console.WriteLine("{0} {1}", d.Key, d.Value);
            }
            obj.Remove(1103); //remove key-value pair
        }
    }
}
