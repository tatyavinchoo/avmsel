﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace HandsOnCollections
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList obj = new ArrayList();
            //add items
            obj.Add(10);
            obj.Add(12.233);
            obj.Add("Jeson");
            obj.Add(true);
            Console.WriteLine(obj[1]);
            int k = (int)obj[0];
            obj.Insert(1, "Raman");
            obj.Remove(12.233);//remove object
            //fetch all the values
            foreach (var i in obj)
            {
                Console.WriteLine(i);
            }
        }
    }
}
