﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace HandsOnCollections
{
    class StackDemo
    {
        static void Main()
        {
            Stack obj = new Stack();
            obj.Push(10);
            obj.Push(23);
            obj.Push(34);
            obj.Push(44);
            obj.Push(49);
            Console.WriteLine("top value " + obj.Peek());
            Console.WriteLine("Poped value " + obj.Pop());
            foreach (var k in obj)
            {
                Console.WriteLine(k);
            }
        }
    }
}
