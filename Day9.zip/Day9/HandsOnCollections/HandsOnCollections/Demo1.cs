﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace HandsOnCollections
{
    class Demo1
    {
        static void Main()
        {
            ArrayList ar = new ArrayList();
            ar.Add("Lilly");
            ar.Add("Rose");
            ar.Add("Daffodil");
            ar.Add("Marigold");
            ar.Add("Jasmine");
            ar.Sort();//sorting elemts
            foreach (var item in ar)
                Console.WriteLine(item);
            Console.WriteLine("Enter a flower name");
            string name = Console.ReadLine();
            //bool flag = false;
            //foreach (string item in ar)
            //{
            //    if (item == name)
            //    {
            //        flag = true;
            //        Console.WriteLine("Valid Flower");
            //        break;
            //    }
            //}
            //if (!flag)
            //{
            //    Console.WriteLine("Not Exist");
            //}
            if (ar.BinarySearch(name) >= 0)
            {
                Console.WriteLine("Valid");
            }
            else
                Console.WriteLine("Invalid");
        }
    }
}
