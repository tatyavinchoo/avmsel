﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace HandsOnCollections
{
    class student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
    }
    class arrDemo
    {
        static void Main()
        {
            student s1 = new student() { Id = 1, Name = "Rohan", Age = 10 };//object initializer
            student s2 = new student() { Id = 2, Name = "Karan", Age = 10 };
            student s3 = new student() { Id = 3, Name = "Suren", Age = 10 };
            student s4 = new student() { Id = 4, Name = "Jeson", Age = 10 };
            student s5 = new student() { Id = 5, Name = "Sachin", Age = 10 };
            student s6 = new student() { Id = 6, Name = "Monica", Age = 10 };
            student s7 = new student() { Id = 7, Name = "Rohan", Age = 10 };
            student s8 = new student() { Id = 8, Name = "Rohan", Age = 10 };
            ArrayList obj = new ArrayList() { s1, s2, s3, s4, s5, s6 };//collection initializer
            obj.Add(s7);
            obj.Add(s8);
            foreach (student s in obj)
            {
                Console.WriteLine("{0} {1} {2}", s.Id, s.Name, s.Age);
            }
            Console.WriteLine("Size " + obj.Count);
            obj.Clear();

        }
    }
}
