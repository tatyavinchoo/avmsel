﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnExceptions
{
    class Program
    {
        public static void Div(byte a, byte b)
        {
            try
            {
                int c = a / b;
                Console.WriteLine("Divison of {0}/{1} is {2}", a, b, c);
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine(ex.Message);//build it message
            }
        }
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter a, b values");
                byte a = byte.Parse(Console.ReadLine());
                byte b = byte.Parse(Console.ReadLine());
                Div(a, b);
            }
           
            catch (FormatException ex)
            {
                //Console.WriteLine(ex.Message);
                Console.WriteLine("pls enter only no's");
            }
            catch (OverflowException ex)
            {
                Console.WriteLine("Pls enter no between 1 to 255");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            
        }
    }
}
