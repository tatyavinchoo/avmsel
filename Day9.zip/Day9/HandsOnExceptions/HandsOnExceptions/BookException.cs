﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnExceptions
{
    class BookException:ApplicationException
    {
        public override string Message
        {
            get
            {
                return "At Max u can book only 3 tickets\n" + "Transaction Failed";
            }
        }
    }
    class TicketBook
    {
        static void Main()

        {
            Console.WriteLine("How many tickets you want to book");
            try
            {
                byte i = byte.Parse(Console.ReadLine());
                if (i > 3)
                    throw new BookException();
                else
                    Console.WriteLine("Transaction Success");
            }
            catch (BookException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
