﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnExceptions
{
    class Demo1
    {
        static void Main()
        {
            int[] a = { 10, 23, 3, 4, 5, 6 };
            try
            {
                for (int i = 0; i < 10; i++)
                {
                    Console.WriteLine(a[i]);
                }
            }
            catch (IndexOutOfRangeException ex)
            {
                Console.WriteLine("Message " + ex.Message);
                Console.WriteLine("Project Name " + ex.Source);//returns assembly or project name
                Console.WriteLine("Method Name " + ex.TargetSite);//return method name
                Console.WriteLine("StactTrace " + ex.StackTrace); //returns full info
            }
            catch (Exception ex)
            {

            }
        }
    }
}
