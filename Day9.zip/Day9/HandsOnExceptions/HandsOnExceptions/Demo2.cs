﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnExceptions
{
    class Demo2
    {
        static void Main()
        {
            try
            {
                int i = 10;
                int j = 0;
                if (j == 0)
                {
                    throw new Exception("j value should not be zerop");
                }
                int k = i / j;
                Console.WriteLine(k);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }
            finally
            {
                Console.WriteLine("Good Morning ");
                //clean up code
            }
        }
    }
}
