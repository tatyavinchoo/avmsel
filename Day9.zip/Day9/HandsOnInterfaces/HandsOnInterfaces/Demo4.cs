﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnInterfaces
{
    interface IComputer
    {
        void Discount();
    }
    interface IMobile
    {
        void Discount();
    }
    class Transaction : IComputer, IMobile
    {
        void IComputer.Discount()
        {
        }
        void IMobile.Discount()
        {
        }
    }
    class Demo4
    {
    }
}
