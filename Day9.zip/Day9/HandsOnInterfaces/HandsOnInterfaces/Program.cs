﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnInterfaces
{
    interface Ishape
    {
        //abstract members
        void Area();
        void shape();
    }
    class Circle : Ishape
    {
        double r;
        public Circle(double r)
        {
            this.r = r;
        }
        public void Area()
        {
            Console.WriteLine("Area of Circle " + Math.PI * r * r);
        }

        public void shape()
        {
            Console.WriteLine("I am a 2d Shape");
        }
        public void Perimeter()
        {
        }
    }
    class Rectangle : Ishape
    {

        public void Area()
        {
            //write logic to fine area of Rectangle
        }

        public void shape()
        {
            Console.WriteLine("I am 2d shaped");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Ishape circle = new Circle(12.3);//access only interface memebers
            circle.shape();
            circle.Area();
            Ishape rect = new Rectangle();
            rect.shape();
            rect.Area();
        }
    }
}
