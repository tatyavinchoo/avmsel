﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnInterfaces
{
    interface IA
    {
        void M1();
    }
    interface IB
    {
        void M2();
    }
    interface IC:IB
    {
    }
    class Demo:IA,IB//multiple inheritance
    {
        public void M1()
        {
        }
        public void M2()
        {
        }
    }
    class Demo1
    {
    }
    class Demo2:Demo1,Ishape//multiple inheritance
    {
    }
}
