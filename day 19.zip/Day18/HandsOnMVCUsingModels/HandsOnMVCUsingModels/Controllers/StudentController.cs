﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HandsOnMVCUsingModels.Entities;
using HandsOnMVCUsingModels.Models;
namespace HandsOnMVCUsingModels.Controllers
{
    public class StudentController : Controller
    {
        //
        // GET: /Student/

        public ActionResult Index()
        {
            StudentRep obj = new StudentRep();
            List<Student> list=obj.GetStudents();
            return View(list);
        }
        public ActionResult Details(int id)
        {
            StudentRep obj = new StudentRep();
            Student s=obj.GetStudentById(id);
            return View(s);//passing student object to view method
        }
        public ActionResult Add(int age,string name,int id)
        {
            Student s = new Student()
            {
                Sid = id,
                Sname = name,
                Age = age,
            };
            StudentRep obj = new StudentRep();
           
            obj.Add(s);
            return RedirectToAction("Index");//redirect to Index Action Method
        }

    }
}
