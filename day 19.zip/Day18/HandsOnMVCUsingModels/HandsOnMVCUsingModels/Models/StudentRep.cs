﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HandsOnMVCUsingModels.Entities;
namespace HandsOnMVCUsingModels.Models
{
    public class StudentRep
    {
        static List<Student> list = new List<Student>()
        {
            new Student(){Sid=1,Sname="Roshan",Age=12},
             new Student(){Sid=2,Sname="Karan",Age=10},
        };
        public List<Student> GetStudents() //return all the student
        {
            return list;
        }
        public Student GetStudentById(int id) //get student by id
        {
            Student s = (from l in list
                        where l.Sid == id
                        select l).SingleOrDefault();
            return s;
        }
        public void Add(Student s)//add student object
        {
            list.Add(s);
        }
    }
}