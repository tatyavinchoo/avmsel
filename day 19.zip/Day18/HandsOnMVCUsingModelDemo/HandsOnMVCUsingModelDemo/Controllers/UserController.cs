﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HandsOnMVCUsingModelDemo.Models.Entities;
using HandsOnMVCUsingModelDemo.Models;
namespace HandsOnMVCUsingModelDemo.Controllers
{
    public class UserController : Controller
    {
        //
        // GET: /User/
        UserRep db = new UserRep();
        public ActionResult Index() //Show all UserData
        {
            List<User> list=db.GetUsers();
            return View(list);
        }
        public ActionResult Details(string name) //Return User by Name
        {
            User obj=db.GetUserById(name);
            return View(obj);
        }
        public ActionResult NewUser(string name,string email,string city)
        {
            User obj = new User()
            {
                Name=name,
                EmailId=email,
                Address=city
            };
            db.AddUser(obj);
            return RedirectToAction("Index");//redirect to index action
        }

    }
}
