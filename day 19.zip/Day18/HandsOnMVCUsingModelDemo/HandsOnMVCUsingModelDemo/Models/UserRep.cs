﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HandsOnMVCUsingModelDemo.Models.Entities;
namespace HandsOnMVCUsingModelDemo.Models
{
    public class UserRep
    {
        static List<User> user = new List<User>()
        {
            new User(){Name="Rajan",EmailId="Rajan@gmail.com",Address="Chennai"},
            new User(){Name="Karan",EmailId="karan@gmail.com",Address="Banglore"}
        };
        public List<User> GetUsers() //retrun all the users
        {
            return user;
        }
        public User GetUserById(string name)//get userdetails by name
        {
            User obj = (from u in user
                        where u.Name == name
                        select u).SingleOrDefault();
            return obj;
        }
        public void AddUser(User objuser) //add User
        {
            user.Add(objuser);
        }
    }
}