﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HandsOnMVCUsingModelDemo.Models.Entities
{
    public class User
    {
        public string Name;
        public string EmailId;
        public string Address;
    }
}