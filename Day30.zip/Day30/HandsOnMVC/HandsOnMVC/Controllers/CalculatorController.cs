﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HandsOnMVC.Models;
namespace HandsOnMVC.Controllers
{
    public class CalculatorController : Controller
    {
        //
        // GET: /Calculator/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Addition()
        {
            return View();
        }
       [HttpPost]
        public ViewResult Addition(int no1,int no2)
        {
            Calculator obj = new Calculator();
            int res=obj.Add(no1,no2);
            ViewData["n"] = res;
            return View();
        }



    }
}
