﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HandsOnMVC.Models
{
    public class Calculator
    {
        public int Add(int a,int b)
        {
            return a + b;
        }
        public int Sub(int a,int b)
        {
            return a - b;
        }
        public int Mul(int a,int b)
        {
            return a * b;
        }
        public int Div(int a,int b)
        {
            if (b != 0)
                return a / b;
            else
                return 0;
        }
        public string Greet(string name)
        {
            return "Hello " + name;
        }
    }
}