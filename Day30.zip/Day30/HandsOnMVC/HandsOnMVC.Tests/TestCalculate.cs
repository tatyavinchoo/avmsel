﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using HandsOnMVC.Models;
namespace HandsOnMVC.Tests
{
    [TestFixture]
    class TestCalculate
    {
        [Test]
        public void TestAdd()
        {
            Calculator obj = new Calculator();
            int actual = obj.Add(10, 20);
            Assert.AreEqual(90, actual);
        }
    }
}
