﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace ClaimProcessing
{
    public class Program
    {
        static void Main(string[] args)

        {

            SqlConnection connection = new SqlConnection(@"Data Source=PC250312;Initial Catalog=DBClaimProcessing;Integrated Security=True");

            ClaimProcessor cpobject = new ClaimProcessor();

            cpobject.ProcessData(@"D:\AVM\Mission Quest 2\ClaimProcessing - Template\Input File\",

                                @"D:\AVM\Mission Quest 2\ClaimProcessing - Template\Report\",

                                "ReportOfRejectedClaims.txt", connection, @"D:\AVM\Mission Quest 2\ClaimProcessing - Template\Archive\");

 

        }

    }
}
