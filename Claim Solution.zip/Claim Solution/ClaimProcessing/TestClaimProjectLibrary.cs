using System;

using System.Collections.Generic;

using System.Linq;

using System.Text;

using System.Threading.Tasks;

using NUnit.Framework;

using ClaimProcessing;

using System.Data.SqlClient;

using System.Data;

 

 

namespace TestClaimProjectLibrary

{

    [TestFixture]

    class TestClaimProcessor

    {

        SqlConnection con = new SqlConnection(@"Data Source=PC250312;Initial Catalog=DBClaimProcessing;Integrated Security=True");

       

        [Test]

        public void TestReadAllDataFromInputFiles()

        {

            ClaimProcessor c = new ClaimProcessor();

            List<Claim> cl = c.ReadAllDataFromInputFiles(@"D:\AVM\Mission Quest 2\ClaimProcessing - Template\Input File\");

            int act = cl.Count;

            int exp = 6;

            Assert.AreEqual(exp,act);

        }

        [Test]

        public void TestUpdateStatusFlag()

        {

            ClaimProcessor c = new ClaimProcessor();

            List<Claim> cl = c.ReadAllDataFromInputFiles(@"D:\AVM\Mission Quest 2\ClaimProcessing - Template\Input File\");

            List<Claim> cl2 = c.UpdateStatusFlag(cl);

            int act = cl2.Count;

            int exp = 6;

            Assert.AreEqual(exp, act);

        }

        [Test]

        public void TestGetRejectedClaimsFromDatabase()

        {

          ClaimProcessor c = new ClaimProcessor();

          List<Claim> cl = c.GetRejectedClaimsFromDatabase(con);

          int act = cl.Count;

          int exp = 4;

          Assert.AreEqual(exp, act);

        }

 

    }

}
