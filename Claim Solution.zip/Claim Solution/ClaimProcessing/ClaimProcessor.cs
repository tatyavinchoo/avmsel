﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Data.Linq;

namespace ClaimProcessing
{
    public class ClaimProcessor
    {
        public void ProcessData(string inputFilePath,string reportFilePath, string reportFileName, SqlConnection connection,string archivePath)
        {
            List<Claim> c = ReadAllDataFromInputFiles(inputFilePath);

 

            List<Claim> sts = UpdateStatusFlag(c);

 

            SaveClaimsToDatabase(sts, connection);

 

            List<Claim> rej = GetRejectedClaimsFromDatabase(connection);

 

            SaveReportAsTextFile(rej, reportFilePath, reportFileName);

 

           MoveToArchive(inputFilePath, archivePath);

        }
        /*
         * Do not modify the method signatures
         * */
        public List<Claim> ReadAllDataFromInputFiles(string inputFilePath)
        {List<Claim> cl = new List<Claim>();

            try

            {

                DirectoryInfo df = new DirectoryInfo(inputFilePath);

                FileInfo[] f = df.GetFiles("CP*.txt");

                foreach (var v in f)

                {

                  FileInfo fname = v;

                  string  path = inputFilePath + @"\" + fname.ToString();

                    string[] a = File.ReadAllLines(path);

                    foreach (var k in a)

                    {

                        string[] l = k.Split('|');

                        {

                            cl.Add(new Claim() { ClaimId = l[0], ClaimDate = l[1], InsuredDate = l[2], InsuredAmountPerYear = l[3], EmailId = l[4], ClaimAmount = l[5], DateOfAdmission = l[6], DateOfDischarge = l[7], BoardingCharges = l[8], SurgeonFees = l[9], Othercharges = l[10] });

                        } 

 

                    }

                }

                foreach (var v in cl)

                {

                    Console.WriteLine(v.ClaimId);

                }

            }

            catch(Exception ex)

            {

                throw new ClaimProcessorException(ex.Message);

            }

            return cl;

        }

        }
        public List<Claim> UpdateStatusFlag(List<Claim> claims)
        {
            List<Claim> sts = new List<Claim>();

            foreach(Claim k in claims )

            {

                Convert.ToDateTime(k.ClaimDate).ToShortDateString();

                Convert.ToDateTime(k.InsuredDate).ToShortDateString();

                Convert.ToDateTime(k.DateOfAdmission).ToShortDateString();

                Convert.ToDateTime(k.DateOfDischarge).ToShortDateString();

                Regex id = new Regex(@"^CP[0-9]{3}$");

                Regex cdate = new Regex(@"^[0-9]{2}\[0-9]{2}\[0-9]{4}$");

                Regex Insdate = new Regex(@"^[0-9]{2}\[0-9]{2}\[0-9]{4}$");

                Regex Insamnt = new Regex(@"^[0-9]+$");

                Regex Email = new Regex(@"^[a-zA-Z][a-zA-Z0-9]+@[a-z]+[.]+[a-z]{3}$");

                Regex camt = new Regex(@"^[0-9]+$");

                Regex dofadm = new Regex(@"^[0-9]{2}\[0-9]{2}\[0-9]{4}$");

                Regex dofdis = new Regex(@"^[0-9]{2}\[0-9]{2}\[0-9]{4}$");

                int sum = int.Parse(k.BoardingCharges) + int.Parse(k.SurgeonFees) + int.Parse(k.Othercharges);

                if (k.ClaimId != null && k.ClaimDate != null &&  k.InsuredDate != null && k.InsuredAmountPerYear != null && k.EmailId != null && k.ClaimAmount != null && k.DateOfAdmission != null && k.DateOfDischarge != null && k.BoardingCharges != null && k.SurgeonFees != null && k.Othercharges != null)

                {

                    int clamt = int.Parse(k.ClaimAmount);

                    int insamt = int.Parse(k.InsuredAmountPerYear);

                    DateTime cdte = Convert.ToDateTime(k.ClaimDate);

                    DateTime insdate = Convert.ToDateTime(k.InsuredDate);

                    DateTime DOAdm = Convert.ToDateTime(k.DateOfAdmission);

                    DateTime DOdis = Convert.ToDateTime(k.DateOfDischarge);

                    int n=DOAdm.Month-DOdis.Month;

 

                    if (id.IsMatch(k.ClaimId) && Insamnt.IsMatch(k.InsuredAmountPerYear) && Email.IsMatch(k.EmailId) && camt.IsMatch(k.ClaimAmount) && Insamnt.IsMatch(k.InsuredAmountPerYear) && clamt <= insamt && n <= 3 && cdte > insdate && DOAdm > insdate && DOdis > insdate && DOdis >= DOAdm && sum == clamt)

                    {

                            sts.Add(new Claim() { ClaimId = k.ClaimId, ClaimDate = k.ClaimDate, InsuredDate = k.InsuredDate, InsuredAmountPerYear = k.InsuredAmountPerYear, EmailId = k.EmailId, ClaimAmount = k.ClaimAmount, DateOfAdmission = k.DateOfAdmission, DateOfDischarge = k.DateOfDischarge, BoardingCharges = k.BoardingCharges, SurgeonFees = k.SurgeonFees, Othercharges = k.Othercharges, ClaimStatus = "Approved" });

                    }

                    else

                    {

                            sts.Add(new Claim() { ClaimId = k.ClaimId, ClaimDate = k.ClaimDate, InsuredDate = k.InsuredDate, InsuredAmountPerYear = k.InsuredAmountPerYear, EmailId = k.EmailId, ClaimAmount = k.ClaimAmount, DateOfAdmission = k.DateOfAdmission, DateOfDischarge = k.DateOfDischarge, BoardingCharges = k.BoardingCharges, SurgeonFees = k.SurgeonFees, Othercharges = k.Othercharges, ClaimStatus = "Rejected" });

                   }

                    

                   }

            }

            foreach (Claim t in sts)

            {

                Console.WriteLine(t.ClaimId + " " + t.ClaimStatus);

            }

            return sts;

        }
        
        public void SaveClaimsToDatabase(List<Claim> claims, SqlConnection sqlConnectionString)
        {
           foreach(Claim c in claims)

           {

               SqlCommand cmd = new SqlCommand(@"Insert into SBA.Claim_Requests(ClaimId,ClaimDate,InsuredDate,InsuredAmountPerYear,EmailId,ClaimAmount,DateOfAdmission,DateOfDischarge,BoardingCharges,SurgeonFees,Othercharges,ClaimStatus)

               values('"+c.ClaimId+"','"+c.ClaimDate+"','"+c.InsuredDate+"','"+c.InsuredAmountPerYear+"','"+c.EmailId+"','"+c.ClaimAmount+"','"+c.DateOfAdmission+"','"+c.DateOfDischarge+"','"+c.BoardingCharges+"','"+c.SurgeonFees+"','"+c.Othercharges+"','"+c.ClaimStatus+"')", sqlConnectionString);

               sqlConnectionString.Open();

               cmd.ExecuteNonQuery();

               sqlConnectionString.Close();

        }
        public List<Claim> GetRejectedClaimsFromDatabase(SqlConnection connectionString)
        {
           List<Claim> c = new List<Claim>();

            try

            {

                DataSet ds = new DataSet();

                SqlDataAdapter da = new SqlDataAdapter(@"Select ClaimId,ClaimDate,ClaimAmount,EmailId from SBA.Claim_Requests where ClaimStatus='Rejected'", connectionString);

                connectionString.Open();

                da.Fill(ds);

                connectionString.Close();

                foreach (DataRow dr in ds.Tables[0].Rows)

                {

                        Claim c1 = new Claim()

                        {

                            ClaimId = dr["ClaimId"].ToString(),

                            ClaimDate = dr["ClaimDate"].ToString(),

                            ClaimAmount = dr["ClaimAmount"].ToString(),

                            EmailId = dr["EmailId"].ToString(),

                        };

                        c.Add(c1);

                }

            }

            catch (SqlException ex)

            {

                throw new Exception(ex.Message);

            }

        return c;

        }
        public void SaveReportAsTextFile(List<Claim> claims, string reportFilePath, string reportFileName)
        {
            string path = reportFilePath + @"\" + reportFileName;

 

                string[] a = new string[claims.Count];

                int i = 0;

                foreach (var v in claims)

                {

               v.ClaimDate = Convert.ToDateTime(v.ClaimDate).ToShortDateString();

                    a[i] = v.ClaimId + "," + v.ClaimDate + "," + v.ClaimAmount + "," + v.EmailId;

                    i++;

                }

                File.WriteAllLines(path, a);

        }    
        public void MoveToArchive(string inputFilePath, string archiveFilePath)
        {
            DirectoryInfo dinfo = new DirectoryInfo(inputFilePath);

                FileInfo[] Files = dinfo.GetFiles("CP*.txt");

                foreach (FileInfo f in Files)

                {  

                        string[] a = File.ReadAllLines(inputFilePath + f.Name);

                        File.WriteAllLines(archiveFilePath + f.Name.Substring(0,17)+"__Processed.txt", a);

                   

                } 

        }
    }
}
