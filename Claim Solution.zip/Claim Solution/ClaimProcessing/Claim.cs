﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClaimProcessing
{
    public class Claim
    {
        public string ClaimId { get; set; }
        public string ClaimDate { get; set; }        
        public string InsuredDate { get; set; }
        public string InsuredAmountPerYear { get; set; }
        public string EmailId { get; set; }        
        public string ClaimAmount { get; set; }
        public string DateOfAdmission { get; set; }
        public string DateOfDischarge { get; set; }        
        public string BoardingCharges { get; set; }        
        public string SurgeonFees { get; set; }
        public string Othercharges { get; set; }
        public string ClaimStatus { get; set; } 
    }
}
