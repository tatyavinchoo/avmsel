﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HandsOnMVCUsingRoutes.Controllers
{
    public class StudentController : Controller
    {
        //
        // GET: /Student/

        public ActionResult Show()
        {
            return View();
        }
        public ActionResult Details(int Id)
        {
            return View();
        }

    }
}
