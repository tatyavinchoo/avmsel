﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HandsOnMVCUsingActionResults.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
            //return Json(new string[] { "Rose", "Lilly" }, JsonRequestBehavior.AllowGet);
            //return File("~/Web.config", ".xml");
            //return Content("<h1>Hello</h1");
            //return Redirect("http://www.google.co.in");
            //return RedirectToAction("Index", "Demo");
        }

    }
}
