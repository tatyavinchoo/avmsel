﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HandsOnMVCUsingActionResults.Controllers
{
    public class DemoController : Controller
    {
        //
        // GET: /Demo/

        public ViewResult Index() //return viewtemplate as response
        {
            return View();
        }
        public RedirectResult View1()
        {
            //return Redirect("Index");
            //return Redirect("/Home/Index");
            return Redirect("http://www.google.co.in"); //crose-domine request
        }
        public RedirectToRouteResult View2()
        {
            //return RedirectToAction("Index"); //redirect to action with in the same controller
            return RedirectToAction("Index", "Home"); //redirect to action from other controller
        }
        public ContentResult Content() //rendor any content as html response
        {
            //return Content("Hello world...");
            //return Content("<h1>Hello World </h1>"); //return html content
            return Content("<script>alert('Hello World')</script>"); //return javascript content
        }
        public JsonResult SendJson() //JsonResult return data in Json Format
        {
            List<string> list = new List<string>(){
                "Rose",
                "Lilly",
                "Jasmine",
                "Tulips"
            };
            return Json(list, JsonRequestBehavior.AllowGet);
        }
        public FileResult File() //return file content
        {
            //return File("~/Web.config", ".xml");
            return File("~/errlog.txt", ".txt");
        }
    }
}
