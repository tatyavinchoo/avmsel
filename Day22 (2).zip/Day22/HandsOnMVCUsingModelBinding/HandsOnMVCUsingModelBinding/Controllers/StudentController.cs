﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HandsOnMVCUsingModelBinding.Models;
namespace HandsOnMVCUsingModelBinding.Controllers
{
    public class StudentController : Controller
    {
        //
        // GET: /Student/
        StudentRep repObj = new StudentRep();
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Create()
        {
            return View();
        }
        //[HttpPost]
        //public ActionResult Create(Student obj)
        //{
        //    repObj.Add(obj);
        //    TempData["msg"] = "Record Added";
        //    return View();
        //}
        [HttpPost]
        public ActionResult Create(FormCollection obj) //FormCollected Reads Posted form data
        {
            Student s = new Student()
            {
                Sid=int.Parse(obj["Sid"]),
                Sname=obj["Sname"].ToString(),
                Age=int.Parse(obj["Age"]),
                DOB=DateTime.Parse(obj["DOB"])
            };
            repObj.Add(s);
            TempData["msg"] = "Record Added";
            return View();
        }
        public ActionResult Search(int id)
        {
            Student s = repObj.Details(id);
            return RedirectToAction("Details", s);
        }
        public ActionResult Details([Bind(Exclude="Age,DOB")]Student s)
        {
            return View(s);
        }

    }
}
