﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HandsOnMVCUsingModelBinding.Models
{
    public class StudentRep
    {
        static List<Student> db = new List<Student>();
        public void Add(Student s)
        {
            db.Add(s);
        }
        public Student Details(int id)
        {
            return db.SingleOrDefault(i => i.Sid == id);
        }
    }
}