﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace HandsOnMVCUsingModelBinding.Models
{
    public class Student
    {
        public int Sid { get; set; }
        public string Sname { get; set; }
        public int Age { get; set; }
        [DataType(DataType.Date)]
        public DateTime DOB { get; set; }
    }
}