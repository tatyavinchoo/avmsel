--get max sal record
select * from Employee where Salary=(select MAX(salary) from Employee)
select * from Employee where Salary<
(select Salary from Employee where Ename='Karan')
select * from Employee where JoinDate=(select MIN(joindate) from Employee)
select Eid,Ename,DATEDIFF(yy,joindate,getdate()) as Exp 
from Employee where JoinDate=(select MIN(joindate) from Employee)
select * from Employee

select * from Employee where Salary
>all(select salary from Employee where Did='Admn')