select max(salary) from Employee
select * from Employee where salary=(select max(salary) from Employee)
select * from Employee where Salary=(select max(salary) from Employee where Salary<(
select max(salary) from Employee))
select Ename from employee where did=(select did from dept where dname='BFS')
select * from Employee
select * from Employee where did in(select did from Employee where ename in('Rohan','Roshan'))
select * from Employee where Salary>all(select Salary from Employee where did=2)