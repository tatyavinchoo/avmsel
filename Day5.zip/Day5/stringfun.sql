select upper(Ename) as Ename from employee
select lower(Ename) as Ename from Employee
select len('hello goodmornig users')
select len(ename) as length from employee
select left('goodmorning',3)
select RIGHT('goodmorning',3)
select SUBSTRING('goodmorning',1,4)
select ename,SUBSTRING(ename,1,2) from Employee