select count(*) from Employee
select count(*) as 'no of records' from employee
select count(*) from Employee where did=1
select count(did) from Employee
select count(distinct(did)) as DeptCount from employee

--Avg()
select * from Student
select avg(age) from student
select avg(salary) from employee

--Max()
select max(age) from Student
select min(age) from Student
select max(salary) from Employee
select min(salary) as 'min' from Employee
select max(salary) as 'maxsal',min(salary) as 'minsalary' from Employee
select * from Employee
insert into Employee(Eid,Ename,CreationDate) values(7,'David','12.2.2010')

select min(CreationDate) from Employee

--Sum
select sum(salary) from Employee