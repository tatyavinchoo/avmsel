select * into emp_bfs_backup from Employee where did=1
select * from emp_bfs_backup