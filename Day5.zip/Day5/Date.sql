select getdate()
select year(getdate())
select month(getdate())
select day(getdate())
sp_rename 'employee.creationdate','joindate'
sp_rename 'student.signeddate','dob'
select Ename,year(joindate) as year from employee
select * from Student
select month(dob) from student
select datepart(yy,'12.2.2000')
select datepart(mm,getdate())
select datepart(dy,getdate())
select datepart(wk,getdate())
select datepart(dw,getdate())
select datepart(hh,getdate())
select DATENAME(dw,getdate())
select datename(dw,'12.2.2000')
select datename(mm,getdate())
select DATEDIFF(yy,'12.2.1990','12.3.2010')
select datediff(yy,'12.2.1990',getdate())
select datediff(mm,'12.2.1990',getdate())
select datediff(dd,'12.2.1990',getdate())
select Ename,datediff(yy,joindate,getdate()) as Exp from Employee
update Employee set joindate=DATEADD(yy,-2,joindate) from employee where Ename!='David'
select * from Employee
select datename(dw,dateadd(yy,1,'12.2.2017'))
select dateadd(yy,1,getdate())
select dateadd(mm,1,getdate())
select isdate('20.2.2000')

select '12'+'12' as sum
select cast('12' as int)+cast('12' as int) as sum
select CONVERT(int,'12')+Convert(int,'12') as sum