use CTSDB
select * from Employee
select AVG(salary) from Employee
select MAX(salary) from Employee
select MIN(salary) from Employee
select MAX(salary) from Employee where Did='IT'
select SUM(salary) from Employee
select COUNT(*) from Employee
select COUNT(*) as 'No of Employees' from Employee where Did='Admn'