select * from employee
--Order by caluse
select * from Employee order by Salary
select * from Employee order by Ename
select * from Employee where Did=1 order by Salary
select * from Employee order by Ename,Salary
select * from Employee order by Salary,Ename
select * from Employee order by Salary desc
select * from Employee order by Salary asc
sp_rename 'employee.desig', 'designation' --rename column name
sp_rename 'person','personoinfo' --rename table name