--group by
--display no of employee workingin each dept
select did,count(did) as 'No' from Employee group by Did
select did,count(did) as 'No' from Employee where did is not null 
group by Did
select salary,count(salary) from employee group by salary
select did,sum(salary) as 'TotalSalary' from Employee
group by did
select did,sum(salary) as 'TotalSalary' from Employee
group by did having sum(salary)>50000
select year(joindate) as 'Year',count(joindate) 
as 'EmpCount' from employee group by joindate
select year(joindate) as 'Year',count(joindate) 
as 'EmpCount' from employee group by joindate having count(joindate)>1