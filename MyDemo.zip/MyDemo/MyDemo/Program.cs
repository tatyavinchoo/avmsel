﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace MyDemo
{
    class Program
    {
        static void Main(string[] args)
        {

           EmpDAO db = new EmpDAO();
           db.AddEmp();
           SqlDataReader dr = db.GetEmp("HR");
           if (dr.HasRows)
           {
               while (dr.Read())
               {
                   Console.WriteLine(dr["id"] + " " + dr["name"] + " " + dr["desig"] + " " + dr["sal"]);
               }

           }

           //System.Data.DataSet ds = db.GetProductsUsingDataSet();
           //DataTable dt = db.GetProductsUsingDataTable();
           //List<Product> list = db.GetProductsUsingList();
            //foreach(DataRow dr in dt.Rows)
            //{
            //    Console.WriteLine(dr["Pid"] + " " + dr["Pname"] + " " + dr["Price"] + dr["Stock"]);
            //}
            //foreach(Product p in list)
            //{
            //    Console.WriteLine(p.Pid + " " + p.Pname + " " + p.Price + " " + p.Stock);
            //}
            
        }
    }
}
