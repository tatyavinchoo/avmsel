﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace MyDemo
{
    class EmpDAO
    {
        public void AddEmp()
        {
            string connetionString = null;
            SqlConnection cnn;
            SqlDataAdapter adapter = new SqlDataAdapter();
            string sql = null;
            connetionString = @"Data Source=PC123125\SQLEXPRESS;Initial Catalog=MyDB;User ID=sa;Password=Password123;";

            cnn = new SqlConnection(connetionString);
            sql = "insert into employii values(6,'Radhika','Assis',40000)";
            try
            {
                cnn.Open();
                adapter.InsertCommand = new SqlCommand(sql, cnn);
                adapter.InsertCommand.ExecuteNonQuery();
               Console.WriteLine("Row inserted !! ");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }
       
        public SqlDataReader GetEmp(string desig)
        {
            SqlConnection con = null;
            SqlCommand cmd = null;
            try
            {
                con = new SqlConnection(@"Data Source=PC123125\SQLEXPRESS;Initial Catalog=MyDB;User ID=sa;Password=Password123;");
                cmd = new SqlCommand("Select * from Employii where desig='"+desig+"'", con);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                return dr;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                throw;
            }
            
        }
    }
}
