﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnConditionalStatements
{
    class Demo1
    {
        static void Main()
        {
            int a = 10;
            int b = 20;
            int c = 15;
            if (a > b)
            {
                if (a > c)
                {
                    Console.WriteLine("a is Max " + a);
                }
                else
                {
                    Console.WriteLine("c is Max " + c);
                }
            }
            else
            {
                if (b > c)
                {
                    Console.WriteLine("b is Max " + b);
                }
                else
                    Console.WriteLine("c is Max " + c);

            }
        }
    }
}
