﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnConditionalStatements
{
    class Demo2
    {
        static void Main()
        {
            double m1 = 78.5;
            double m2 = 90.5;
            double m3 = 38;
            double m4 = 89;
            double tol = m1 + m2 + m3 + m4;
            double avg = tol / 4;
            if (m1 < 40 || m2 < 40 || m3 < 40 || m4 < 40)
            {
                Console.WriteLine("Result:Fail");
            }
            else if (avg >= 70)
            {
                Console.WriteLine("Result:Distinction");
                Console.WriteLine("Marks %" + avg);
            }
            else if (avg >= 60 && avg < 70)
            {
                Console.WriteLine("Result:FirstClass");
                Console.WriteLine("Marks %" + avg);
            }
            else if (avg >= 50 && avg < 60)
            {
                Console.WriteLine("Result:Second Class");
                Console.WriteLine("Marks %" + avg);
            }
            else
            {
                Console.WriteLine("Result:Third Class");
                Console.WriteLine("Marks %" + avg);
            }
        }
    }
}
