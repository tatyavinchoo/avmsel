﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnConditionalStatements
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 10;
            int b = 20;
            if (a > b)
            {
                Console.WriteLine("Max " + a);
            }
            else
                Console.WriteLine("Max " + b);
        }
    }
}
