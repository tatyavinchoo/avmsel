﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnDataTypes
{
    class Program
    {
        int sal = 12234324;
        string name = null;
        static void Main(string[] args)
        {
            //local variable 
            //integer types
            int a = 10;
            byte b = 12;
            short s = 123;
            long l = 123;

            //unsigned types
            uint ui = 233;
            ushort us = 32434;
            ulong ul = 98327032;
            sbyte sb = -12;

            //decimal type
            double d = 12.345;
            float f = 12.34f;
            decimal dm = 12.23432434m;

            //char type
            char ch = 'a';

            //bool types
            bool res = true;

            //reference types
            string str = "Hello";
            object o = 12;
            object o1 = 12.23;
            object o2 = true;
            object o3 = "Welcome";
        }
    }
}
