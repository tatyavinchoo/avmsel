﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;
using UniversityapplicationFaculty.Models;

namespace UniversityapplicationFaculty.UI
{
    public partial class stu1 : Form
    {
        SqlConnection con = null;
        SqlCommand cmd = null;
        public stu1()
        {
            InitializeComponent();
        }

        private void UpdateCLk(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            stu1 s = new stu1();
            this.Hide();
            s.ShowDialog();
            s.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Login d = new Login();
            this.Hide();
            d.ShowDialog();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StudentDao db = new StudentDao();

            db.Sid = textBox1.Text;
            db.Sname = textBox2.Text;
            db.Batch = textBox3.Text;

            try
            {

                con = new SqlConnection(@"Data Source=pc250265;Initial Catalog=University;User ID=sa;Password=password-1");

                string qry = "update Student set Sname='" + db.Sname + "',Batch='" + db.Batch + "' where Sid=" + db.Sid;
                cmd = new SqlCommand(qry, con);

                con.Open();
                cmd.ExecuteNonQuery();
                //  label8.Text = "Record Updated";
                MessageBox.Show("Record Updated");


            }
            catch (SqlException ex)
            {
                // label8.Text = ex.Message;
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
    }
}
