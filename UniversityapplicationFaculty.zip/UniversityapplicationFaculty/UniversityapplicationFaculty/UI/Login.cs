﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace UniversityapplicationFaculty.UI
{
    public partial class Login : Form
    {
        SqlConnection con = null;
        SqlCommand cmd = null;
        
        public Login()
        {
            InitializeComponent();
        }

        //private void Login(object sender, EventArgs e)
        //{

           
        //}

        private void Cancel(object sender, EventArgs e)
        {

        }

        //private void Login(object sender, EventArgs e)
        //{

        //}

        private void Loginclk(object sender, EventArgs e) 
        {
            string Uname ;
            string Pwd;
            Uname = txtName.Text;
            Pwd = txtPwd.Text;
            if (Uname == "admin" && Pwd == "Pwd") //Login as admin
            {
                Details d = new Details();
                
                d.ShowDialog();
                this.Close();
            }
            else if (Uname == "faculty" && Pwd == "Pwd") //Login as faculty
            {
                Details1 faculty = new Details1();
                this.Hide();
                faculty.ShowDialog();
                this.Close();
                
            }
           
                else
                {
                    label3.Text = "Invalid Credentials";
                }

               

            }
            
        }
    }
