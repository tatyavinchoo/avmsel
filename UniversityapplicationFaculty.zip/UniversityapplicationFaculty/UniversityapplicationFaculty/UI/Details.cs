﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UniversityapplicationFaculty.UI
{
    public partial class Details : Form
    {
        public Details()
        {
            InitializeComponent();
        }

        //private void insertCLk(object sender, EventArgs e)
        //{
        //    Form1 f = new Form1();
        //    this.Hide();
        //    f.Show();
        //}

        private void facultyclk(object sender, EventArgs e) 
        {
            if (radioButton1.Checked)            //Faculty Details Display                   
            {
                Form1 f = new Form1();
                this.Hide();
                f.ShowDialog();
                this.Close();
            }
        }

        private void BackClk(object sender, EventArgs e)
        {
            Login d = new Login();              //Back to Login 
            this.Hide();
            d.ShowDialog();
            this.Close();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)            //Student Details Display   
            {
                Student f = new Student();
                this.Hide();
                f.ShowDialog();
                this.Close();
            }
        }

       

        
    }
}
