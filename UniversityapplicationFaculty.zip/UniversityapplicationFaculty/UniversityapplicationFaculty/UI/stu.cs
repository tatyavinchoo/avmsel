﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using UniversityapplicationFaculty.Models;

namespace UniversityapplicationFaculty.UI
{
    public partial class stu : Form
    {
        SqlConnection con = null;
        SqlCommand cmd = null;
        
        public stu()
        {
            InitializeComponent();
        }

        private void stu_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)  //add student details by faculty
        {
            StudentDao db = new StudentDao();
            db.Sid =    textBox1.Text;                
            db.Sname = textBox2.Text;     
            db.Batch = textBox3.Text;     
            db.YearOfPassing = textBox4.Text;
            db.Did = textBox5.Text;     
           
        
            try
            {
                con = new SqlConnection(@"Data Source=pc250265;Initial Catalog=University;User ID=sa;Password=password-1");
                string qry = "insert into Student values(" + db.Sid + ",'" + db.Sname + "','" + db.Batch + "','" + db.YearOfPassing + "','"  + db.Did + "')";
                cmd = new SqlCommand(qry, con);

                con.Open();
                cmd.ExecuteNonQuery();
                label6.Text = "Record Added";


            }
            catch (SqlException ex)
            {
                label5.Text = ex.Message;
            }
            finally
            {
                con.Close();
            }

        }

        private void button2_Click(object sender, EventArgs e)  //Back to Faculty Control Form
        {
            Details1 f = new Details1();
            this.Hide();
            f.ShowDialog();
            f.Close();
        }

        private void searchCLk(object sender, EventArgs e)      //Search student details by faculty with Id using stored procedure
        {
            try
            {
                con = new SqlConnection(@"Data Source=pc250265;Initial Catalog=University;User ID=sa;Password=password-1");
                cmd = new SqlCommand("GetStudentId", con);
                cmd.CommandType = CommandType.StoredProcedure;
             
                cmd.Parameters.AddWithValue("@Sid", textBox1.Text);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                  
                    textBox2.Text = dr["Sname"].ToString();
                   textBox3.Text = dr["Batch"].ToString();
                    textBox4.Text = dr["YearOfPassing"].ToString();
                     textBox5.Text = dr["Did"].ToString();
                  
                }
                else
                    MessageBox.Show("invalid id");
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
            }

        }

        private void button4_Click(object sender, EventArgs e)  //Display entire  student details by faculty
        {
            StudentDao obj1 = new StudentDao();
         
            try
            {
                DataTable dt = obj1.SearchbYId();
                if (dt.Rows.Count > 0)
                {
                    
                    dataGridView1.DataSource = dt;

                }
                else
                    MessageBox.Show("invalid id");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Cancel_Click(object sender, EventArgs e)   //Refersh the form
        { 
            stu s = new stu();
            this.Hide();
            s.ShowDialog();
            s.Close();
        }

        
    }
}
