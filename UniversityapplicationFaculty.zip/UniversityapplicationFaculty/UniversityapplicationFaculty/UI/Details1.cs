﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UniversityapplicationFaculty.UI
{
    public partial class Details1 : Form
    {
        public Details1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)                   // Faculty Details Display by Faculty
            {
                FacultyaddStu f = new FacultyaddStu();
                this.Hide();
                f.ShowDialog();
                this.Close();
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)            // Student Details Display by Faculty
            {
                stu f = new stu();
                this.Hide();
                f.ShowDialog();
                this.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Login f = new Login();   //Back to Login
            this.Hide();
            f.ShowDialog();
            this.Close();
        }
    }
}
