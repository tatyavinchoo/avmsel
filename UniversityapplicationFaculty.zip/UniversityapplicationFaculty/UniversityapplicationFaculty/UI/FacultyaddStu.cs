﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using UniversityapplicationFaculty.Models;
namespace UniversityapplicationFaculty.UI
{
    public partial class FacultyaddStu : Form
    {
        SqlConnection con = null;
        SqlCommand cmd = null;
        public FacultyaddStu()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)  //Update faculty details by faculty
        {
            FacultyDao db = new FacultyDao();
            db.Fid = txtFid.Text;                   
            db.Fname = txtFname.Text;
            db.FType = txtFType.Text;
            db.Designation = txtDesg.Text;
            db.JoinDate = txtDate.Text;
            db.Qualification = txtQualf.Text;
            db.Did = txtDid.Text;
        
            try
            {
                con = new SqlConnection(@"Data Source=pc250265;Initial Catalog=University;User ID=sa;Password=password-1");
             
                string qry = "update Faculty set Fname='" + db.Fname + "',FType='" + db.FType + "',Designation='" + db.Designation + "',JoinDate='" + db.JoinDate + "',Qualification='" + db.Qualification + "',Did='" + db.Did + "' where Fid=" + db.Fid;
                cmd = new SqlCommand(qry, con);

                con.Open();
                cmd.ExecuteNonQuery();
                label5.Text = "Record Updated";


            }
            catch (SqlException ex)
            {
                label5.Text = ex.Message;
            }
            finally
            {
                con.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)      //select faculty and details by faculty using join
        {
            FacultyDao db = new FacultyDao();
            db.Fid = txtFid.Text;

            try
            {
                con = new SqlConnection(@"Data Source=pc250265;Initial Catalog=University;User ID=sa;Password=password-1");
                string qry = "select Fname,FType,Designation,JoinDate,Qualification,Did  from faculty  where Fid=" + db.Fid;
                con.Open();
                cmd = new SqlCommand(qry, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {

                    dr.Read();
                    txtFname.Text = dr["Fname"].ToString();
                    txtFType.Text = dr["FType"].ToString();
                    txtDesg.Text = dr["Designation"].ToString();
                    txtDate.Text = dr["JoinDate"].ToString();
                    txtQualf.Text = dr["Qualification"].ToString();
                    txtDid.Text = dr["Did"].ToString();


                }
                else
                {
                    label5.Text = "Invalid ID";
                }
            }
            catch (SqlException ex)
            {
                label5.Text = ex.Message;
            }
            finally
            {
                con.Close();
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            stu s = new stu();
            this.Hide();
            s.ShowDialog();
            s.Close();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Details1 d = new Details1();
            this.Hide();
            d.ShowDialog();
            d.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {

            //FacultyDao db = new FacultyDao();
            //txtFid.Text = " ";                    
            //txtFname.Text = " ";
            //txtFType.Text = " ";
            //txtDesg.Text = " ";
            //txtDate.Text = " ";
            //txtQualf.Text = " ";
            //txtDid.Text = " ";
            FacultyaddStu f=new FacultyaddStu();
            this.Hide();
            f.ShowDialog();
            f.Close();
           
        }
    }
}
