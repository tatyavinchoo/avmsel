﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using UniversityapplicationFaculty.Models;

namespace UniversityapplicationFaculty.UI
{
    public partial class Student : Form
    {
        SqlConnection con = null;
        SqlCommand cmd = null;
        public Student()
        {
            InitializeComponent();
        }

        private void detailsclk(object sender, EventArgs e)  //View student details by Admin
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=pc250265;Initial Catalog=University;User ID=sa;Password=password-1"))
            {
                try
                {
                    SqlDataAdapter da = null;
                    DataSet ds = new DataSet();
                    da = new SqlDataAdapter("select * from Student", con);
                    da.Fill(ds, "stu");

                    dataGridView1.DataSource = ds.Tables[0];


                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void updateclk(object sender, EventArgs e)  //update student details by Admin
        {
            StudentDao db = new StudentDao();
                          
            db.Sid = textBox1.Text;
            db.Sname = textBox2.Text;
            db.Batch = textBox3.Text;
         
            try
            {
                con = new SqlConnection(@"Data Source=pc250265;Initial Catalog=University;User ID=sa;Password=password-1");
            
                string qry = "update Student set Sname='" + db.Sname + "',Batch='" + db.Batch + "' where Sid=" + db.Sid;
                cmd = new SqlCommand(qry, con);

                con.Open();
                cmd.ExecuteNonQuery();
                label8.Text = "Record Updated";


            }
            catch (SqlException ex)
            {
                label8.Text = ex.Message;
            }
            finally
            {
                con.Close();
            }

        }

        private void deleteclk(object sender, EventArgs e)          //delete student details by Admin
        {
            StudentDao db = new StudentDao();
            db.Sid = textBox1.Text;

            try
            {
                con = new SqlConnection(@"Data Source=pc250265;Initial Catalog=University;User ID=sa;Password=password-1");
                string qry = "delete Student where Sid=" + db.Sid;
                cmd = new SqlCommand(qry, con);
                con.Open();
                cmd.ExecuteNonQuery();
                label5.Text = "Record Deleted";
            }
            catch (SqlException ex)
            {
                label5.Text = ex.Message;
            }
            finally
            {
                con.Close();
            }

        }

        private void cancelclk(object sender, EventArgs e)
        {
            Student s = new Student();
            this.Hide();
            s.ShowDialog();
            s.Close();
        }

        private void backclk(object sender, EventArgs e)        //Back to AdminControl page
        {
            Details d = new Details();
            this.Hide();
            d.ShowDialog();
            this.Close();
        }

        private void Student_Load(object sender, EventArgs e)
        {

        }

        private void Searchclk(object sender, EventArgs e)      //search student details by Admin with ID
        {
            StudentDao db = new StudentDao();
            db.Sid = textBox1.Text;

            try
            {
                con = new SqlConnection(@"Data Source=pc250265;Initial Catalog=University;User ID=sa;Password=password-1");
              //  string qry = "select Sname,Batch,Fee_status  from Student s join S_Account sa on s.Sid=sa.Sid where Sid=" + db.Sid;
                string qry = "select Sname,Batch,YearOfPassing,Did  from Student  where Sid=" + db.Sid;
                con.Open();
                cmd = new SqlCommand(qry, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {

                    dr.Read();
                textBox2.Text = dr["Sname"].ToString();
                textBox3.Text = dr["Batch"].ToString();
                textBox4.Text = dr["YearOfPassing"].ToString();
                textBox5.Text = dr["Did"].ToString();
               // textBox7.Text = dr["Fee_status"].ToString();
                   


                }
                else
                {
                    label5.Text = "Invalid ID";
                }
            }
            catch (SqlException ex)
            {
                label5.Text = ex.Message;
            }
            finally
            {
                con.Close();
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void addclk(object sender, EventArgs e)
        {
            StudentDao db = new StudentDao();
            db.Sid = textBox1.Text;                 //string name=textname(RHMCpropertiesname).Text;
            db.Sname = textBox2.Text;
            db.Batch = textBox3.Text;
            db.YearOfPassing = textBox4.Text;
            db.Did = textBox5.Text;
           
            //Add Record
            try
            {
                con = new SqlConnection(@"Data Source=pc250265;Initial Catalog=University;User ID=sa;Password=password-1");
                string qry = "insert into Student values(" + db.Sid + ",'" + db.Sname + "','" + db.Batch + "','" + db.YearOfPassing + "','" + db.Did + "')";
                cmd = new SqlCommand(qry, con);

                con.Open();
                cmd.ExecuteNonQuery();
                label5.Text = "Record Added";


            }
            catch (SqlException ex)
            {
                label5.Text = ex.Message;
            }
            finally
            {
                con.Close();
            }

        }
    }
}
