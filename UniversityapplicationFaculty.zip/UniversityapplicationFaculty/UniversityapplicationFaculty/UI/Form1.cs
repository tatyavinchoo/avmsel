﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UniversityapplicationFaculty.Models;
using UniversityapplicationFaculty.UI;


using System.Data.SqlClient;
namespace UniversityapplicationFaculty
{
    public partial class Form1 : Form
    {
         SqlConnection con = null;
                SqlCommand cmd = null;
              
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Register(object sender, EventArgs e)   //Addfaculty details by Admin
        {
            FacultyDao db = new FacultyDao();
           db.Fid = txtFid.Text;                   
           db. Fname = txtFname.Text;
           db. FType = txtFType.Text;
           db.Designation  = txtDesg.Text;
            db.JoinDate=txtDate.Text;
            db.Qualification=txtQualf.Text;
            db.Did=txtDid.Text;
            db.Aid=textBox1.Text;
            db.SalStatus=textBox2.Text;
                
            
            //Add Record
            try
            {
                string qry;
                con = new SqlConnection(@"Data Source=pc250265;Initial Catalog=University;User ID=sa;Password=password-1");
                con.Open();
                qry = "insert into Faculty values(" + db.Fid + ",'" + db.Fname + "','" + db.FType + "','" + db.Designation + "','" + db.JoinDate + "','" + db.Qualification + "','" + db.Did + "')";
                cmd = new SqlCommand(qry, con);
                cmd.ExecuteNonQuery();
                qry = "insert into F_Account values('" + db.Aid + "','" + db.Fid + "','" + db.SalStatus + "')";
                cmd = new SqlCommand(qry, con);
                cmd.ExecuteNonQuery();
         
               

                label5.Text = "Record Added";
                
                
            }
            catch (SqlException ex)
            {
                label5.Text = ex.Message;
            }
            finally
            {
                con.Close();
            }

        }

        private void Cancel(object sender, EventArgs e)
        {
            FacultyDao db = new FacultyDao();
    
            Form1 f = new Form1();
            this.Hide();
            f.ShowDialog();
            f.Close();

        }

        private void UpdateCLk(object sender, EventArgs e)                  //UpdateFaculty details by Admin
        {
            FacultyDao db = new FacultyDao();
            db.Fid = txtFid.Text;                   
            db.Fname = txtFname.Text;
            db.FType = txtFType.Text;
            db.Designation = txtDesg.Text;
            db.JoinDate = txtDate.Text;
            db.Qualification = txtQualf.Text;
            db.Did = txtDid.Text;
            db.Aid = textBox1.Text;
            db.SalStatus = textBox2.Text;
            //Add Record
            try
            {
                string qry = null;
                con = new SqlConnection(@"Data Source=pc250265;Initial Catalog=University;User ID=sa;Password=password-1");
                con.Open();
               qry="update Faculty set Fname='"+db.Fname+"',FType='"+db.FType+"',Designation='" + db.Designation + "',JoinDate='" + db.JoinDate + "',Qualification='" + db.Qualification + "',Did='" + db.Did + "' where Fid="+db.Fid;
                cmd = new SqlCommand(qry, con);
                cmd.ExecuteNonQuery();
             

                qry = "update F_Account set Salary_status='" + db.SalStatus + "' where Fid=" + db.Fid;
                cmd = new SqlCommand(qry, con);
                cmd.ExecuteNonQuery();
                label5.Text = "Record Updated";


            }
            catch (SqlException ex)
            {
                label5.Text = ex.Message;
            }
            finally
            {
                con.Close();
            }
        }

        private void SearchById(object sender, EventArgs e) //Search Faculty details by Admin with ID
        { 
            FacultyDao db = new FacultyDao();
             db.Fid= txtFid.Text;

           
            try
            {
                con = new SqlConnection(@"Data Source=pc250265;Initial Catalog=University;User ID=sa;Password=password-1");
                string qry = "select f.Fname,f.FType,f.Designation,f.JoinDate,f.Qualification,f.Did,d.A_id,d.Salary_status from faculty f join F_Account d on f.Fid=d.Fid  where f.Fid=" + db.Fid;
                con.Open();
                cmd = new SqlCommand(qry, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {

                    dr.Read();
                    txtFname.Text = dr["Fname"].ToString();
                    txtFType.Text = dr["FType"].ToString();
                    txtDesg.Text = dr["Designation"].ToString();
                    txtDate.Text = dr["JoinDate"].ToString();
                    txtQualf.Text = dr["Qualification"].ToString();
                    txtDid.Text = dr["Did"].ToString();
                    textBox1.Text = dr["A_id"].ToString();
                    textBox2.Text = dr["Salary_status"].ToString();
                    

                }
                else
                {
                    label5.Text = "Invalid ID";
                }
            }
            catch (SqlException ex)
            {
                label5.Text = ex.Message;
            }
            finally
            {
                con.Close();
            }

        }

        private void backclk(object sender, EventArgs e)
        {
            Details d = new Details();
            this.Hide();
            d.ShowDialog();
            this.Close();
        }

        private void Delclk(object sender, EventArgs e)     //Deletefaculty details by Admin
        {
            FacultyDao db = new FacultyDao();
            db.Fid = txtFid.Text;
           
            try
            {
                string qry = null;
                con = new SqlConnection(@"Data Source=pc250265;Initial Catalog=University;User ID=sa;Password=password-1");
                con.Open();
                qry = "delete from F_Account where Fid=" + db.Fid;
                cmd = new SqlCommand(qry, con);



                cmd.ExecuteNonQuery();
                qry = "delete from faculty where Fid=" + db.Fid;
                cmd = new SqlCommand(qry, con);
                cmd.ExecuteNonQuery();
               
                label5.Text = "Record Deleted";
            }
            catch (SqlException ex)
            {
                label5.Text = ex.Message;
            }
            finally
            {
                con.Close();
            }

        }

        private void DetailsClk(object sender, EventArgs e) //View Faculty details by admin
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=pc250265;Initial Catalog=University;User ID=sa;Password=password-1"))
            {
                try
                {
                    SqlDataAdapter da = null;
                    DataSet ds = new DataSet();
                    da = new SqlDataAdapter("select * from Faculty", con);
                    da.Fill(ds, "fac");

                    dataGridView1.DataSource = ds.Tables[0];


                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

    }
}
