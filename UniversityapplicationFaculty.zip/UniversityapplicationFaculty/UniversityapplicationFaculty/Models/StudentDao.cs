﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace UniversityapplicationFaculty.Models
{
    class StudentDao
    {
        SqlConnection con = null;
        SqlCommand cmd = null;

        public string Sid { get; set; }
        public string Sname { get; set; }
        public string Batch { get; set; }
        public string YearOfPassing { get; set; }
        public string Did { get; set; }
        public string A_id { get; set; }
        public string Fee_status { get; set; }
        public DataTable SearchbYId()
        {
            try
            {

                con = new SqlConnection(@"Data Source=pc250265;Initial Catalog=University;User ID=sa;Password=password-1");
                SqlDataAdapter da = new SqlDataAdapter(@"select * from Student", con);
                con.Open();
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
            catch
            {
                throw;
            }
            finally
            {

            }


        }


       
    }
}
