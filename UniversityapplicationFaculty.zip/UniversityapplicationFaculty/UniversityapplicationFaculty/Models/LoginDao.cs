﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace UniversityapplicationFaculty.Models
{
    class LoginDao
    {
        string Uname { get; set; }
        string Pwd { get; set; }
           SqlConnection con=null ;
        SqlCommand cmd=null;
        public static SqlDataReader validate(string uname, string pwd)
        {

            SqlConnection con = new SqlConnection(@"Data Source=pc250265;Initial Catalog=University;User ID=sa;Password=password-1");
          
DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand("select uname,pwd,type from Login where uname=@uname and pwd=@pwd", con);
            con.Open();
            cmd.Parameters.AddWithValue("@uname", uname);
            cmd.Parameters.AddWithValue("@pwd", pwd);

            SqlDataReader s = cmd.ExecuteReader();
            return s;

        }
    }

    }

