﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UniversityapplicationFaculty.Models
{
    class FacultyDao
    {
        public string Fid;
       public  string Fname;
        public string FType;
     public  string Designation;
        public string JoinDate;
        public string Qualification;
        public string Did;
        public string Aid;
        public string SalStatus;


 
    }
}
