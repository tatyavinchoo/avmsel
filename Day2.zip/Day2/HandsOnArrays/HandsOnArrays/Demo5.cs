﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnArrays
{
    class Demo5
    {
        static void Main()
        {
            string[] str ={"Rohan",
                             "Karan",
                             "Jeson",
                             "Suren",
                             "Sachin"
                         };
            Console.WriteLine("Enter the name");
            string name = Console.ReadLine();
            System.Array.Sort(str);
            if (System.Array.BinarySearch(str, name) >= 0)
            {
                Console.WriteLine("Valid Name");
            }
            else
                Console.WriteLine("Invalid name");
        }
    }
}
