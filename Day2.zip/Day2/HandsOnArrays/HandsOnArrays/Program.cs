﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnArrays
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = new int[5];
            a[0]=12;
            a[1] = 23;
            a[2] = 34;
            a[3] = 45;
            a[4] = 90;
            int sum = 0;
            //a[5] = 22; exception
            //access array value
            Console.WriteLine(a[2]);
            //access all the values
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine(a[i]);
            }
            Console.WriteLine();
            
            foreach (int k in a)
            {
                sum = sum + k;
               //if(k%2!=0)
               // Console.WriteLine(k);
            }
        }
    }
}
