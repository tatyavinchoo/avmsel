﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnArrays
{
    class Demo2
    {
        static void Main()
        {
            char[] ch = new char[5] { 'a', 'b', 'c', 'd', 'e' };
            double[] d = new double[4] { 12.23, 23.4, 22.3, 45.5 };
            string[] str = new string[2] { "Rohan", "Karan" };
            object[] obj = new object[3] { 1, 12.2, true };
        }
    }
}
