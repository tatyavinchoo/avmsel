﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace HandsOnArrays
{
    class Demo7
    {
        static void Main()
        {
            string[,] logins =new string[3,2]{
                                  {"Rohan","12345"},
                                  {"Suren","12345"},
                                  {"Karan","12345"}
                             };
            Console.WriteLine("Enter Login Details");
            string uname = Console.ReadLine();
            string pwd = Console.ReadLine();
            bool flag = false;
            for (int i = 0; i < 3; i++)
            {
                if (logins[i, 0] == uname && logins[i, 1] == pwd)
                {
                    flag = true;
                    Console.WriteLine("Valid User");
                    break;
                }
            }
            if (!flag)
            {
                Console.WriteLine("Invalid Login Details");
            }
        }
    }
}
