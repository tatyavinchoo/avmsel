﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnArrays
{
    class Demo3
    {
        static void Main()
        {
            string[] str ={"Rohan",
                             "Karan",
                             "Jeson",
                             "Suren",
                             "Sachin"
                         };
            Console.WriteLine("Enter the name");
            string name = Console.ReadLine();
            bool flag = false;
            foreach (string s in str)
            {
                if (s == name)
                {
                    flag = true;
                    Console.WriteLine("Valid Name");
                    break;
                }     
            }
            if (!flag)
            {
                Console.WriteLine("Invalid Name");
            }
        }
    }
}
