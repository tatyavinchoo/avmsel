﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnArrays
{
    class Demo6
    {
        static void Main()
        {
            int[,] twod = new int[3, 2];
            twod[0, 0] = 98;
            twod[0, 1] = 67;
            twod[1, 0] = 23;
            twod[1, 1] = 33;
            twod[2, 0] = 34;
            twod[2, 1] = 66;
            //foreach (int k in twod)
            //    Console.WriteLine(k);
            //display elements in matrix format
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    Console.Write(twod[i, j] + " ");
                }
                Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
}
