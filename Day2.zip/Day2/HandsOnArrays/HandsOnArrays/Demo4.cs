﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnArrays
{
    class Demo4
    {
        static void Main()
        {
            int[] a = { 12, 43, 11, 45, 21, 89, 55, 19 };
            Console.WriteLine("Size " + a.Length);
            Console.WriteLine("Dimension " + a.Rank);
            System.Array.Sort(a);
            System.Array.Reverse(a);
            foreach (int k in a)
                Console.WriteLine(k);
            Console.WriteLine();
            int[] b = new int[4];
            System.Array.Copy(a, b, 4);
            foreach (int k in b)
                Console.WriteLine(k);
        }
    }
}
