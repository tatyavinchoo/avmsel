﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnArrays
{
    class Demo8
    {
        static void Main()
        {
            int[][] j_array = new int[3][];
            j_array[0] = new int[] { 1, 2, 3, 4 };
            j_array[1] = new int[] { 5, 6, 7 };
            j_array[2] = new int[] { 8, 9 };
            for (int i = 0; i < j_array.Length; i++)
            {
                foreach (int k in j_array[i])
                {
                    Console.Write(k);
                }
                Console.WriteLine();
            }

        }
    }
}
