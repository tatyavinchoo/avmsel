﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnIterativeStatements
{
    class Demo8
    {
        static void Main()
        {
            //Print event numbers between 1 to 100
            int i = 1;
            for (; i <= 100; i++)
            {
                if (i % 2 != 0)
                    continue;
                Console.WriteLine(i);
            }
            Console.ReadKey();
        }
    }
}
