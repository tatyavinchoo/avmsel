﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnIterativeStatements
{
    class Demo5
    {
        static void Main()
        {
            //Print math table
            Console.WriteLine("enter no");
            int no = int.Parse(Console.ReadLine());
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine("{0}*{1}={2}", no, i, (no * i));
            }
        }
    }
}
