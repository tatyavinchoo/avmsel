﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnIterativeStatements
{
    class Demo2
    {
        static void Main()
        {
            Console.WriteLine("Enter name");
            string name = Console.ReadLine();
            //print name given no of times
            Console.WriteLine("How many times you want to print");
            int no = int.Parse(Console.ReadLine());
            int f=1;
            do
            {
                Console.WriteLine("Good Morning " + name);
                f++;
            } while (f <= no);
        }
    }
}
