﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnIterativeStatements
{
    class Demo3
    {
        public static void Main()
        {
            Console.WriteLine("Enter name");
            string name = Console.ReadLine();
            for (int f = 1; f <= 10; f++)
            {
                Console.WriteLine("Good Morning " + name);
            }
        }
    }
}
