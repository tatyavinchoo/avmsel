﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnIterativeStatements
{
    class Demo1
    {
        static void Main()
        {
            //print nos from 1 to given no
            Console.WriteLine("Enter no");
            int no = int.Parse(Console.ReadLine());
            int f = 1;
            while (f <= no)
            {
                Console.Write(f + "\t");
                f++;
            }
        }
    }
}
