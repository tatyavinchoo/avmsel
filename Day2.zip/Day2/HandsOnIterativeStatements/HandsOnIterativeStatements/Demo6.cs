﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnIterativeStatements
{
    class Demo6
    {
        static void Main()
        {
            //Print even nos between 1 to 100
            Console.WriteLine("Enter no");
            int no = int.Parse(Console.ReadLine());
            for (int i = 1; i <= no; i++)
            {
                if (i % 2 == 0)
                    Console.WriteLine(i);
            }
        }
    }
}
