﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnIterativeStatements
{
    class Demo7
    {
        static void Main()
        {
            //for (int i = 1; i <= 10; i++)
            //{
            //    Console.WriteLine(i);
            //}
            //int i = 1;
            //for (; i <= 10; i++)
            //{
            //    Console.WriteLine(i);
            //}
            //int i = 1;
            //for (; i <= 10; )
            //{
            //    Console.WriteLine(i);
            //    i++;
            //}
            int i = 1;
            for(;i<=10000;)
            {
                if (i >= 10)
                {
                    break;//terminate loop
                }
                Console.WriteLine(i);
                i++;
            }
        }
    }
}
