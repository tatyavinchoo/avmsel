﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnIterativeStatements
{
    class Demo4
    {
        static void Main()
        {
            //find factorial of given no
            Console.WriteLine("Enter no");
            int no = int.Parse(Console.ReadLine());
            int fact = 1;
            for (int i = no; i > 0; i--)
            {
                fact = fact * i;
            }
            Console.WriteLine("Factorial of {0} is {1}", no, fact);
        }
    }
}
