﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnIterativeStatements
{
    class Demo9
    {
        static void Main()
        {
            Console.WriteLine("Enter a no");
            int no = int.Parse(Console.ReadLine());
            do
            {
                Console.WriteLine("1.Even/Odd");
                Console.WriteLine("2.Print Natual no's");
                Console.WriteLine("3.Print Math Table");
                Console.WriteLine("4.Exit");
                Console.WriteLine("Enter your choice");
                int ch = int.Parse(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        if (no % 2 == 0)
                            Console.WriteLine("Event no");
                        else
                            Console.WriteLine("Odd no");
                        break;
                    case 2:
                        int f = 1;
                        while (f <= no)
                        {
                            Console.WriteLine(f);
                            f++;
                        }
                        break;
                    case 3:
                        for (int i = 1; i <= 10; i++)
                        {
                            Console.WriteLine("{0}*{1}={2}", no, i, (no * i));
                        }
                        break;
                    case 4:
                        return;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }

            } while (true);
        }
    }
}
