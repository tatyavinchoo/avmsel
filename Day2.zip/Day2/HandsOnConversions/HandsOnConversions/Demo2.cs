﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnConversions
{
    class Demo2
    {
        static void Main()
        {
            //casting
            int i = 100;
            byte b = (byte)i;
            short s = (short)i;
            double d = 12.34;
            int k = (int)d;
             s = (short)d;
             long l = 1234;
             int k1 = (int)l;
        }
    }
}
