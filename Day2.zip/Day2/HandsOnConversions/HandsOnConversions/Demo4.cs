﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnConversions
{
    class Demo4
    {
        static void Main()
        {
            //convert string to valuetypes
            string s="123AVC";
            int i = Convert.ToInt32(s);
            short s1 = Convert.ToInt16(s);
            long l = Convert.ToInt64(s);
            byte b = Convert.ToByte(s);
            double d = Convert.ToDouble(s);
            float f = Convert.ToSingle(s);
            //convert value types to string
            string s2 = Convert.ToString(12);
            s2 = Convert.ToString(12.23);
            s2 = Convert.ToString('a');
            s2 = Convert.ToString(true);

            //convert value type to value type
            int i2 = Convert.ToInt32(12.34);
            byte b1 = Convert.ToByte(i2);
            short sh1 = Convert.ToInt16(i2);

        }
    }
}
