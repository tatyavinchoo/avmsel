﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnConversions
{
    class Program
    {
        static void Main(string[] args)
        {
            //Direct Conversion
            int i = 10;
            int j = i;
            //implicit convertsion
            byte b = 100;
            int a = b;
            short sh = b;
            double d = a;
            char ch = 'a';
            int k = ch;
            Console.WriteLine(k);
        }
    }
}
