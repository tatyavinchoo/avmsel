﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnConversions
{
    class Demo5
    {
        static void Main()
        {
            //Object Conversion
            //Boxing:Process of Converting value types to object type
            //Boxing is Implicit conversion
            int i = 100;
            object o1 = i;
            double d = 23.34;
            object o2 = d;
            //Unboxing:Process of Converting object type value into value types
            //Unboxing in explicit use casting
            object o = 12;
            int k = (int)o;//explicit
            object o3 = 12.34;
            double d1 = (double)o3;
            d1 = Convert.ToDouble(o3);

            //Ojbect to string conversion
            object o4 = 12345;
            string s = o4.ToString();
        }
    }
}
