﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnConversions
{
    class Demo3
    {
        static void Main()
        {
            //string to value type  conversion
            string s = "123";
            int i = int.Parse(s);
            byte b = byte.Parse(s);
            double d = double.Parse(s);
            long l = long.Parse(s);
            s = "a";
            char ch = char.Parse(s);

            //value types to string conversion
            int j = 100;
            string s1 = j.ToString();
            double d1 = 12.345;
            s1 = d1.ToString();
            byte b1 = 123;
            s1 = b1.ToString();
        }
    
    }
}
