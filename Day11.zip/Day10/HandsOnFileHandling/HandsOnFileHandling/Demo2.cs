﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace HandsOnFileHandling
{
    class ErrorLog
    {
        public static void WriteLog(Exception ex)
        {
            if (new FileInfo(@"D:\Dotnet\Day10\errlog.txt").Exists)
            {

                using (StreamWriter sw = new StreamWriter(@"D:\Dotnet\Day10\errlog.txt", true))
                {
                    string error = "Project: " + ex.Source + " Error: " + ex.Message + "_"
                        + "Date: " + DateTime.Now.ToShortDateString();
                    sw.WriteLine(error);
                }
            }
            else
            {
                Console.WriteLine("File not exist");
            }
        }
    }
    class Demo2
    {
        public static void Div(int a, int b)
        {
            int c = a / b;
            Console.WriteLine(c);
        }
        static void Main()
        {
            try
            {
                Div(1000, 0);
            }
            catch (Exception ex)
            {
                ErrorLog.WriteLog(ex);
            }
        }
    }
}
