﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace HandsOnFileHandling
{
    class Demo
    {
        public static void Read(string path)
        {
            try
            {
                using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read))
                {
                    byte[] data = new byte[fs.Length];
                    fs.Read(data, 0, data.Length);
                    string content = new UTF8Encoding().GetString(data);
                    Console.WriteLine(content);
                }
            }
            catch (IOException ex)
            {
            }
        }
        public static void Write(string path)
        {
            try
            {
                using (FileStream fs = new FileStream(path, FileMode.OpenOrCreate, FileAccess.Write))
                {
                    string content = Environment.NewLine+"GoodMorning";
                    byte[] data = new byte[content.Length];
                    data = new UTF8Encoding().GetBytes(content);
                    //set seek position
                    fs.Seek(1, SeekOrigin.End);
                    fs.Write(data, 0, data.Length);
                }
            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        static void Main()
        {
            //Read(@"D:\Dotnet\Day10\2.txt");
            Write(@"D:\Dotnet\Day10\3.txt");
        }
    }
}
