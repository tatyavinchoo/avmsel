﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace HandsOnFileHandling
{
    class Program
    {
        public static void Read(string path)
        {
            try
            {
                using (StreamReader sr = new StreamReader(path))
                {
                    string content=string.Empty;
                   //content= sr.ReadLine();//reads first line
                    //content = sr.ReadToEnd();
                   // content = sr.Read().ToString();
                    char []ch=new char[10];
                    sr.Read(ch, 0, 10);
                    content = new string(ch);//return char array into string
                    Console.WriteLine(content);
                }
            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void Write(string path)
        {
            StreamWriter sw = null;
            try
            {
                sw = new StreamWriter(path,true);
                //string content = "Welcome User";
                //sw.WriteLine(content);
                List<string> list = new List<string>() { "Rose", "Lilly", "Jasmine", "Marigold" };
                foreach (string s in list)
                {
                    sw.WriteLine(s);

                }
            }
            catch (IOException ex)
            {
            }
            catch (Exception ex)
            {
            }
            finally
            {
                sw.Flush();
                sw.Close();
                
            }
        }
        static void Main(string[] args)
        {
           // Read(@"D:\Dotnet\Day10\1.txt");
            Write(@"D:\Dotnet\Day10\2.txt");
        }
    }
}
