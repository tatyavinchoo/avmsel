﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace HandsOnAdo
{
    public partial class Form2 : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=PC232954;Initial Catalog=TrainingDB;User ID=sa;Password=password-1");
        SqlCommand cmd = null;
        string qry;
        string pid;
        string pname;
        string price;
        string stock;
        public Form2()
        {
            InitializeComponent();
        }

        private void Add(object sender, EventArgs e)
        {
            pid = txtId.Text;
            pname = txtName.Text;
            price = txtPrice.Text;
            stock = txtStock.Text;
            //Add Record
            try
            {
                qry = "Insert into Product values("+pid+",'"+pname+"',"+price+","+stock+")";
                cmd = new SqlCommand(qry, con);
                con.Open();
                cmd.ExecuteNonQuery();
                label5.Text = "Record Added";
            }
            catch (SqlException ex)
            {
                label5.Text = ex.Message;
            }
            finally
            {
                con.Close();
            }
        }
    }
}
