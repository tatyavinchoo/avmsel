﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace HandsOnAdo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void GetEmployee(object sender, EventArgs e)
        {
            label1.Text = string.Empty;
             SqlConnection con=null;
            try
            {
               con = new SqlConnection("Data Source=PC232954;Initial Catalog=TrainingDB;User ID=sa;Password=password-1");
               con.Open();//open connection
               SqlCommand cmd = new SqlCommand("select * from Employee", con);
               SqlDataReader dr=cmd.ExecuteReader();
               if (dr.HasRows)
               {
                   while (dr.Read())
                   {
                       label1.Text += dr["Eid"].ToString() +" "+
                           dr[1] +" "+
                           dr["designation"] + " " + dr["Salary"] + " " +
                           dr["Did"] + " " + dr["joindate"] + "\n";
                   }
               }
               else
               {
                   label1.Text = "Reader is Empty";
               }
            }
            catch (SqlException ex)
            {
                label1.Text = ex.Message;
            }
            catch (Exception ex)
            {
            }
            finally
            {
                con.Close();//close connection
            }
        }
    }
}
