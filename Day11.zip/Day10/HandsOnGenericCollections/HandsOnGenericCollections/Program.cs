﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnGenericCollections
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> l1 = new List<int>();
            l1.Add(10);
            l1.Add(23);
            l1.Add(34);
            l1.Add(45);
            l1.Add(55);
            int k = l1[2];
            l1.Sort();
            l1.Reverse();
            l1.Remove(23);
            foreach (int i in l1)
                Console.WriteLine(i);

        }
    }
}
