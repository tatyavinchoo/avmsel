﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnGenericCollections
{
    class Student
    {
        public int Sid{get;set;}
        public string Sname{get;set;}
        public int Age{get;set;}
    }
    class Demo1
    {
        static void Main()
        {
            List<string> flowers = new List<string>() { "Rose", "Lilly", "Jasmine", "Marigold" };
            List<char> l2 = new List<char>() { 'a', 'b', '3', '2' };
            List<double> l3 = new List<double>() { 12.2, 34.3, 44.5 };
            Student s1 = new Student() { Sid = 1, Sname = "Rohan", Age = 10 };
            Student s2 = new Student() { Sid = 2, Sname = "Charan", Age = 10 };
            Student s4 = new Student() { Sid = 3, Sname = "Suren", Age = 10 };
            Student s3 = new Student() { Sid = 4, Sname = "Jeson", Age = 10 };
            List<Student> list = new List<Student>() { s1, s3, s2, s4 };
            list.Add(new Student() { Sid = 5, Sname = "Monica", Age = 12 });
            foreach (Student s in list)
            {
                Console.WriteLine("{0} {1} {2}", s.Sid, s.Sname, s.Age);
            }
        }
    }
}
