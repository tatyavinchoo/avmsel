﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnGenericCollections
{
    class Demo2
    {
        static void Main()
        {
            //Dictionary<int, string> obj = new Dictionary<int, string>();
           // SortedList<int, string> obj = new SortedList<int, string>();
            SortedDictionary<int, string> obj = new SortedDictionary<int, string>();
            obj.Add(1003, "Rohan");
            obj.Add(1232, "Karan");
            obj.Add(1090, "Jeson");
            obj.Add(2313, "Monica");
            obj.Add(2345, "Karan");
            string name = obj[1232];
            obj.Remove(1003);//remove key pair
            foreach (KeyValuePair<int, string> kv in obj)
            {
                Console.WriteLine("{0} {1}", kv.Key, kv.Value);
            }
        }
    }
}
