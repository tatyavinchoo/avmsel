﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HandsonControllerAndViews.Controllers
{
    public class SampleController : Controller
    {
        //
        // GET: /Sample/

        public string Index()
        {
            return "Hello World from MVC";
        }
        public string Greet(string name)
        {
            return "Hello " + name;
        }
        public string Msg(string msg, string name)
        {
            return msg + " " + name;
        }

    }
}
