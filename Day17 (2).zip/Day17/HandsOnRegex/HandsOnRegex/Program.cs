﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
namespace HandsOnRegex
{
    class Program
    {
        public static void Validate(string value,string pattern)
        {
            Regex rgx = new Regex(pattern);
            if (rgx.IsMatch(value))
            {
                Console.WriteLine("Pass");
            }
            else
                Console.WriteLine("Fail");
        }
        static void Main(string[] args)
        {
           
            //Regex rgx = new Regex(@"^\d{3}$");
            //string no = "111";
            //bool res = rgx.IsMatch(no);
            //if (res)
            //    Console.WriteLine("Pass");
            //else
            //    Console.WriteLine("Fail");
            //Validate("rohan_kumar@abc.com", @"^[a-z][a-z0-9._]+@[a-z][a-z]+[.][a-z]{2,3}$");
            Validate("rohan13@", @"^[a-z0-9A-Z!@#$%^&]{5,8}$");
            //validate integer
            Validate("12", "^[+]?[0-9]{2}$");
            Validate("12", "^[+-][0-9]{2}$|^[0-9]{2}$");
            Regex.IsMatch("12",@"^\d+$");
            
        }
    }
}
