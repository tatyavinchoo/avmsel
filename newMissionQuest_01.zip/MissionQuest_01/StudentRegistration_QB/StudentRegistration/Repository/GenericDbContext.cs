﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using StudentRegistration.Models;

namespace StudentRegistration.Repository
{
    public class GenericRepoContext : DbContext
    {
        public GenericRepoContext() : base("StudentEntities") { }

        public DbSet<Student> student { get; set; }
    
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {

        }
    }
}