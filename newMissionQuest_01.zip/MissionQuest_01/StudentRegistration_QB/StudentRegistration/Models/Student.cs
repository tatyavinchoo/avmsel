﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace StudentRegistration.Models
{     
    public class Student
    {
        //Code here for Requirement -3
        [Key]
        [ScaffoldColumn(false)]
        public int StudentId { get; set; }

        [Display(Name = "User name")]
        public string UserName { get; set; }

        
        public string Password { get; set; }

        
        [Display(Name = "Confirm Password")] 
        public string ConfirmPassword { get; set; }


        [Display(Name = "Email address")]
        public string EmailId { get; set; }


        public string FirstName { get; set; }
        public string LastName { get; set; }

       
        [DisplayName("Date of Birth")]          
        public DateTime DateOfBirth { get; set; }


        public string Gender { get; set; }


        [StringLength(500)]
        public string Address { get; set; }

        public string AreasOfInterest { get; set; }

    }
}