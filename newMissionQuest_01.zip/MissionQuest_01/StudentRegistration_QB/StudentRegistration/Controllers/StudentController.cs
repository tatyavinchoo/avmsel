﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using StudentRegistration.Models;
using System.Data.Entity.Infrastructure;
using System.Web.Routing;
using System.Web.Security;
using StudentRegistration.Repository;

namespace StudentRegistration.Controllers
{ 
    public class StudentController : Controller
    {
        
      private IGenericRepository<Student> IStudentRepository = null;

      public StudentController()
        {
            this.IStudentRepository = new GenericRepository<Student>();
        }

        public Student Student { get; private set; }
        
        public ViewResult Index()
        {
            return View(IStudentRepository.SelectAll().ToList());
        }

        public ViewResult Details(int id)
        {
            Student student = IStudentRepository.SelectByID(id);
            return View(student);
        }
        [HttpPost]
        
        public ViewResult Index(string searchTextBox)
        {
            List<Student> students;
            if (string.IsNullOrEmpty(searchTextBox))
            {
                students = IStudentRepository.SelectAll().ToList();
            }
            else
            {
                students = IStudentRepository.SelectAll().Where(x => x.UserName.StartsWith(searchTextBox)).ToList();
            }
            return View(students);
        }

       
        public ActionResult Create()
        {          
            
            return View();
        }
  
        [HttpPost]
        public ActionResult Create(Student student)
        {
            if (ModelState.IsValid)
            {
                IStudentRepository.Insert(student);
                IStudentRepository.Save();
                return RedirectToAction("Index");  
                
            }
            ViewBag.AreasOfInterest = new SelectList(IStudentRepository.SelectAll(), "AreasOfInterest", "AreasOfInterest", student.AreasOfInterest);            
            return View(student);
        }        
        
        public ActionResult Edit(int id)
        {
            Student student = IStudentRepository.SelectByID(id);        
            return View(student);
        }       
             
        [HttpPost]
        public ActionResult Edit(Student student)
        {
            if (ModelState.IsValid)
            {
                IStudentRepository.Update(student);
                IStudentRepository.Save();
                return RedirectToAction("Index");

            }
            return View(student);
        }

        public ActionResult Delete(int id)
        {
            Student student = IStudentRepository.SelectByID(id);
            return View(student);
        }

        
        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            Student student = IStudentRepository.SelectByID(id);
            IStudentRepository.Delete(student);
            IStudentRepository.Save();
            return RedirectToAction("Index");
        }

       
    }

}