﻿using StudentRegistration.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using StudentRegistration.Repository;

namespace StudentRegistration.Controllers
{
    public class HomeController : Controller
    {
        private StudentEntities db = new StudentEntities();
        public Student Student { get; private set; }
        private IGenericRepository<Student> IStudentRepository = null;

        public HomeController()
        {
            this.IStudentRepository = new GenericRepository<Student>();
        }

         public ActionResult Index()
        {
            ViewBag.Message = "Welcome to Student Registration System!";

            return View(IStudentRepository.SelectAll().ToList());
        }
        
    }
}
