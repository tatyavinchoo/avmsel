﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace StudentRegistration.Areas.Staff.Controllers
{
    public class StaffController : Controller
    {
        //
        // GET: /Staff/Staff/

        public ActionResult Index()
        {
            return View();
        }
        //GetStaffView
        public ActionResult GetStatus()
        {

            return View();
            //return View();
        }

    }
}
