﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
namespace HandsOnAdo
{
    class ProductDAO
    {
        SqlConnection con = null;
        SqlCommand cmd = null;
        public SqlDataReader GetProducts()
        {
            SqlConnection con = null;
            SqlCommand cmd = null;
            try
            {
                con = new SqlConnection(@"Data Source=DESKTOP-TAT6UMB\Parsi;Initial Catalog=CTSDB;Integrated Security=True");
                cmd = new SqlCommand("Select * from Product", con);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                return dr;
            }
            catch (SqlException ex)
            {
                throw;
            }
            finally
            {
                //con.Close();
            }
        }
        public DataSet GetProductsUsingDataSet()
        {
            try
            {
                con = new SqlConnection(@"Data Source=DESKTOP-TAT6UMB\Parsi;Initial Catalog=CTSDB;Integrated Security=True");
                SqlDataAdapter da = new SqlDataAdapter("Select * from Product", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                return ds;
            }
            catch (SqlException ex)
            {
                throw;
            }
            finally
            {
                con.Close();
            }
        }
        public DataTable GetProductsUsingDataTable()
        {
            try
            {
                con = new SqlConnection(@"Data Source=DESKTOP-TAT6UMB\Parsi;Initial Catalog=CTSDB;Integrated Security=True");
                SqlDataAdapter da = new SqlDataAdapter("Select * from Product", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
            catch (SqlException ex)
            {
                throw;
            }
            finally
            {
                con.Close();
            }
        }
        public List<Product> GetProductsUsingList()
        {
            try
            {
                con = new SqlConnection(@"Data Source=DESKTOP-TAT6UMB\Parsi;Initial Catalog=CTSDB;Integrated Security=True");
                SqlDataAdapter da = new SqlDataAdapter("Select * from Product", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                List<Product> list = new List<Product>();
                Product p = null;
                foreach (DataRow dr in dt.Rows)
                {
                    p = new Product()
                    {
                        Pid = (int)dr[0],
                        Pname = dr["Pname"].ToString(),
                        Price = (int)dr["Price"],
                        Stock = (int)dr["Stock"]
                    };
                    list.Add(p);
                }
                return list;
            }
            catch (SqlException ex)
            {
                throw;
            }
            finally
            {
                con.Close();
            }
        }
        public void AddProduct(int id,string pname,int price,int stock)
        {
            try
            {
                con = new SqlConnection(@"Data Source=DESKTOP-TAT6UMB\Parsi;Initial Catalog=CTSDB;Integrated Security=True");
                cmd = new SqlCommand(@"Insert into Product(Pid,Pname,Price,Stock) 
                            values("+id+",'"+pname+"',"+price+","+stock+")", con);
                con.Open();
                cmd.ExecuteNonQuery();//execute all the dml queries
            }
            catch(SqlException ex)
            {
                throw;
            }
            catch(Exception ex)
            {
                throw;
            }
            finally
            {
                con.Close();
            }
        }
        public void Add(Product p)
        {
            try
            {
                con = new SqlConnection(@"Data Source=DESKTOP-TAT6UMB\Parsi;Initial Catalog=CTSDB;Integrated Security=True");
                cmd = new SqlCommand(@"Insert into Product(Pid,Pname,Price,Stock) 
                            values(" + p.Pid + ",'" + p.Pname + "'," + p.Price + "," + p.Stock + ")", con);
                con.Open();
                cmd.ExecuteNonQuery();//execute all the dml queries
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                con.Close();
            }
        }
        public void UpdateProduct(int id,int price, int stock)
        {
            try
            {
                con = new SqlConnection(@"Data Source=DESKTOP-TAT6UMB\Parsi;Initial Catalog=CTSDB;Integrated Security=True");
                cmd = new SqlCommand(@"Update Product set price="+price+",stock="+stock+" where Pid="+id, con);
                con.Open();
                cmd.ExecuteNonQuery();//execute all the dml queries
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                con.Close();
            }
        }
        public void DeleteProduct(int id)
        {
            try
            {
                con = new SqlConnection(@"Data Source=DESKTOP-TAT6UMB\Parsi;Initial Catalog=CTSDB;Integrated Security=True");
                cmd = new SqlCommand(@"Delete from Product where Pid="+id, con);
                con.Open();
                cmd.ExecuteNonQuery();//execute all the dml queries
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                con.Close();
            }
        }
        public DataTable Search(int id)
        {
            try
            {
                con = new SqlConnection(@"Data Source=DESKTOP-TAT6UMB\Parsi;Initial Catalog=CTSDB;Integrated Security=True");
                SqlDataAdapter da = new SqlDataAdapter("Select * from Product where Pid="+id, con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
            catch (SqlException ex)
            {
                throw;
            }
            finally
            {
                con.Close();
            }
        }

    }
}
