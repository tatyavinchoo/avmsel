﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace HandsOnAdo
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                ProductDAO db = new ProductDAO();
                //System.Data.SqlClient.SqlDataReader dr=db.GetProducts();
                //if(dr.HasRows)
                //{
                //    while(dr.Read())
                //    {
                //        Console.WriteLine(dr["Pid"] + " " + dr["Pname"] + " " + dr["Price"] + dr["Stock"]);
                //    }
          
                //}
                //System.Data.DataSet ds=db.GetProductsUsingDataSet();
                //DataTable dt = db.GetProductsUsingDataTable();
                //List<Product> list = db.GetProductsUsingList();
                ////foreach(DataRow dr in dt.Rows)
                ////{
                ////    Console.WriteLine(dr["Pid"] + " " + dr["Pname"] + " " + dr["Price"] + dr["Stock"]);
                ////}
                //foreach(Product p in list)
                //{
                //    Console.WriteLine(p.Pid + " " + p.Pname + " " + p.Price + " " + p.Stock);
                //}
                //db.AddProduct(3, "Pendrive", 100, 10);
                //db.UpdateProduct(3, 300, 10);
                //db.DeleteProduct(1);
                DataTable dt = db.Search(10);
                if(dt.Rows.Count>0)
                {
                    foreach(DataRow dr in dt.Rows)
                    {
                        Console.WriteLine(dr["Pid"] + " " + dr["Pname"] + " " + dr["Price"] + dr["Stock"]);
                    }
                }
                else
                    Console.WriteLine("Invalid Id");
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
    }
}
