﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestProject
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculate obj = new Calculate();
            Console.WriteLine(obj.Add(12, 21));
            Console.WriteLine(obj.Sub(12, 3));
        }
    }
}
