﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CalculatorLib;
namespace CalculatorUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculate obj = new Calculate();
            Console.WriteLine(obj.Add(12, 23));
            Console.WriteLine(obj.Sub(12, 2));
            Console.WriteLine(obj.Div(10, 2));
            Console.WriteLine(obj.Mul(12, 3));
        }
    }
}
