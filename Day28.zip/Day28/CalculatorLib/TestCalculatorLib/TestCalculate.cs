﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using CalculatorLib;
namespace TestCalculatorLib
{
    [TestFixture]
    class TestCalculate
    {
        [Test]
        public void TestAdd()
        {
            Calculate obj = new Calculate();
            int actual = obj.Add(10, 12);
            int expected = 20;
            Assert.AreEqual(expected, actual);
        }
        [Test]
        public void TestGreet()
        {
            Calculate obj = new Calculate();
            string actual = obj.Greet("Sachin");
            actual = null;
            Assert.IsNotNull(actual);
        }
    }
}
