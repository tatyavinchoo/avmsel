﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnEFUsingCodeFirst
{
    class Program
    {
        static void Main(string[] args)
        {
            //Products p = new Products() { Pid = 3, Pname = "Pendrive", Price = 100, Stock = 20 };
            //ProductRep db = new ProductRep();
            //db.AddProduct(p);
            //foreach(var item in db.GetProduct())
            //{
            //    Console.WriteLine("{0} {1} {2}", item.Pid, item.Pname, item.Price, item.Stock);
            //}
            ProductRep db = new ProductRep();
            Products p = db.GetProductById(1);
            p.Price = 200;
            db.Update(p);
            //Console.ReadKey();
        }
    }
}
