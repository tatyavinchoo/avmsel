﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnEFUsingCodeFirst
{
    class ProductRep
    {
        public List<Products> GetProduct()
        {
            MyContext db = new MyContext();
            return db.Products.ToList();
        }
        public void AddProduct(Products obj)
        {
            MyContext db = new MyContext();
            db.Products.Add(obj);
            db.SaveChanges();
        }
        public Products GetProductById(int Pid)
        {
            MyContext db = new MyContext();
            return db.Products.Find(Pid);
        }
        public void Delete(int Pid)
        {
            MyContext db = new MyContext();
            Products p = db.Products.Find(Pid);
            db.Products.Remove(p);
            db.SaveChanges();
        }
        public void Update(Products p)
        {
            // table.Attach(obj);
            //db.Entry(obj).State = 
            MyContext db = new MyContext();
            db.Products.Attach(p);
            db.Entry(p).State=System.Data.Entity.EntityState.Modified;
            db.SaveChanges();
        }
    }
}
