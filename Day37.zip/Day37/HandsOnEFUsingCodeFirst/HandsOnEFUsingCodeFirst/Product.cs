﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
namespace HandsOnEFUsingCodeFirst
{
    [Table("tblProducts")]
    class Products
    {
        [Key]
        public int Pid { get; set; }
        [StringLength(30)]
        [Column("ProductName",TypeName="Varchar")]
        public string Pname { get; set; }
        public int Price { get; set; }
        public int Stock { get; set; }

    }
}
