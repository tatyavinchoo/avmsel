﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
namespace HandsOnEFUsingCodeFirst
{
    class MyContext:DbContext
    {
        public MyContext()
            : base("name=SampleDBConn")
        {

        }
        public DbSet<Products> Products { get; set; }
    }
}
